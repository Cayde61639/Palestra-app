import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.riccardo.gymapp',
  appName: 'Gym App',
  webDir: 'dist'
};

export default config;
