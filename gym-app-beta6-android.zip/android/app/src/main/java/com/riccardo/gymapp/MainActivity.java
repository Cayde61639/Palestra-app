package com.riccardo.gymapp;

import android.os.Bundle;
import androidx.core.view.WindowCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.graphics.Insets;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Modalità edge-to-edge: il contenuto della WebView può disegnare dietro
        // alla barra di stato (notifiche) e alla barra di navigazione di sistema,
        // così possiamo gestire noi lo spazio con un padding preciso invece che
        // lasciare che Android lo riservi in modo fisso/generico.
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);

        // Ogni volta che il sistema comunica gli spazi occupati (rotazione,
        // comparsa/scomparsa della tastiera, tipo di barra di navigazione:
        // 3 tasti digitali, gesture bar, notch/punch-hole diversi da modello a
        // modello), calcoliamo gli inset REALI in dp per questo specifico
        // dispositivo e li passiamo al JS della WebView, al posto di una stima
        // fissa uguale per tutti i telefoni.
        ViewCompat.setOnApplyWindowInsetsListener(getWindow().getDecorView(), (view, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            float density = getResources().getDisplayMetrics().density;
            float topDp = systemBars.top / density;
            float bottomDp = systemBars.bottom / density;

            if (bridge != null && bridge.getWebView() != null) {
                String js = String.format(
                    java.util.Locale.US,
                    "window.__applyNativeSafeAreaInsets && window.__applyNativeSafeAreaInsets(%f, %f);",
                    topDp, bottomDp
                );
                bridge.getWebView().post(() -> bridge.getWebView().evaluateJavascript(js, null));
            }

            return insets;
        });
    }
}
