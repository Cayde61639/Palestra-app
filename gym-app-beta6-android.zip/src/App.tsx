import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import {
  Exercise,
  ProgressionLog,
  UserProfile,
  WorkoutDay,
  WorkoutRoutine,
  DeloadType,
  WorkoutSortCriterion,
} from './types';
import {
  INITIAL_PROGRESSION_HISTORY,
  INITIAL_ROUTINE,
  INITIAL_USER_PROFILE,
} from './data/mockInitialRoutine';
import { resolveBackSubcategory } from './data/exerciseDataset';
import { WorkoutSortSelector } from './components/WorkoutSortSelector';
import { sortExercisesByCriterion, SORT_OPTIONS } from './utils/sorting';
import { syncDayMetadata, generateDayName } from './utils/dayNaming';
import { WorkoutCarousel } from './components/WorkoutCarousel';
import { ExerciseCard } from './components/ExerciseCard';
import { SupersetGroupCard } from './components/SupersetGroupCard';
import { groupExercisesBySuperset } from './utils/superset';
import { RestTimerModal } from './components/RestTimerModal';
import { OcrModal } from './components/OcrModal';
import { AddExerciseModal } from './components/AddExerciseModal';
import { RankingsView } from './components/RankingsView';
import { ProgressionView } from './components/ProgressionView';
import { OnboardingModal } from './components/OnboardingModal';
import { DeloadModal } from './components/DeloadModal';
import { Toast } from './components/Toast';
import { DELOAD_OPTIONS } from './data/deloadOptions';
import { getEffectiveWeight, calculateVolume, calculateExerciseVolume } from './utils/volume';
import { isAndroid, applySafeAreaInsets } from './utils/platform';
import {
  Dumbbell,
  Trophy,
  TrendingUp,
  Plus,
  Camera,
  Sparkles,
  Settings,
  Flame,
  RotateCcw,
  CheckCheck,
  Target,
  ArrowUpDown,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { UI_RADII, MOTION_PRESETS, SPECULAR_HIGHLIGHT, TAB_SLIDE_VARIANTS, TAB_TRANSITION } from './utils/uiPresets';
import { useAndroidBackGuard } from './hooks/useAndroidBackGuard';

const TAB_ORDER: Array<'workout' | 'rankings' | 'progression'> =
  ['workout', 'rankings', 'progression'];

export default function App() {
  // Rilevamento piattaforma per isolamento layer GPU e ottimizzazione blur su Android
  const isAndroidDevice = useMemo(() => isAndroid(), []);

  // Local storage loading with fallback to clean slate
  const [routine, setRoutine] = useState<WorkoutRoutine>(() => {
    try {
      const saved = localStorage.getItem('gym_app_routine_v3');
      const loaded: WorkoutRoutine = saved ? JSON.parse(saved) : INITIAL_ROUTINE;
      // Auto-migrazione trasparente per dividere 'back' nei nuovi gruppi 'lats' e 'upper_back'
      const updatedDays = loaded.days.map((d) => ({
        ...d,
        exercises: d.exercises.map((ex) => {
          if (ex.targetMuscle === 'back') {
            return {
              ...ex,
              targetMuscle: resolveBackSubcategory(ex.name, (ex as any).italianName),
            };
          }
          return ex;
        }),
      }));
      return { ...loaded, days: updatedDays };
    } catch {
      return INITIAL_ROUTINE;
    }
  });

  const [profile, setProfile] = useState<UserProfile>(() => {
    try {
      const saved = localStorage.getItem('gym_app_profile_v3');
      return saved ? JSON.parse(saved) : INITIAL_USER_PROFILE;
    } catch {
      return INITIAL_USER_PROFILE;
    }
  });

  const [progressionLogs, setProgressionLogs] = useState<ProgressionLog[]>(() => {
    try {
      // Liberazione cache vecchie versioni
      localStorage.removeItem('gym_app_logs_v3');
      localStorage.removeItem('gym_app_logs_v2');
      localStorage.removeItem('gym_app_logs_v1');
      const saved = localStorage.getItem('gym_app_logs_v4');
      return saved ? JSON.parse(saved) : INITIAL_PROGRESSION_HISTORY;
    } catch {
      return INITIAL_PROGRESSION_HISTORY;
    }
  });

  const handleClearLogs = () => {
    try {
      localStorage.removeItem('gym_app_logs_v4');
      localStorage.removeItem('gym_app_logs_v3');
    } catch {}
    setProgressionLogs([]);
  };

  const [selectedDayId, setSelectedDayId] = useState<string>(routine.days[0]?.id || 'day-a');

  // Navigazione e Swipe tra le giornate della scheda (Day A, Day B, Day C...)
  const [daySwipeDirection, setDaySwipeDirection] = useState<1 | -1>(1);

  const handleNextDay = useCallback(() => {
    const currentIdx = routine.days.findIndex((d) => d.id === selectedDayId);
    if (currentIdx < routine.days.length - 1) {
      setDaySwipeDirection(1);
      setSelectedDayId(routine.days[currentIdx + 1].id);
    }
  }, [routine.days, selectedDayId]);

  const handlePrevDay = useCallback(() => {
    const currentIdx = routine.days.findIndex((d) => d.id === selectedDayId);
    if (currentIdx > 0) {
      setDaySwipeDirection(-1);
      setSelectedDayId(routine.days[currentIdx - 1].id);
    }
  }, [routine.days, selectedDayId]);

  const dayTouchStartRef = useRef<{
    startX: number;
    startY: number;
    lastX: number;
    lastY: number;
    time: number;
  } | null>(null);

  const handleWorkoutTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      const touch = e.touches[0];
      dayTouchStartRef.current = {
        startX: touch.clientX,
        startY: touch.clientY,
        lastX: touch.clientX,
        lastY: touch.clientY,
        time: Date.now(),
      };
    }
  };

  const handleWorkoutTouchMove = (e: React.TouchEvent) => {
    if (!dayTouchStartRef.current || e.touches.length !== 1) return;
    const touch = e.touches[0];
    dayTouchStartRef.current.lastX = touch.clientX;
    dayTouchStartRef.current.lastY = touch.clientY;
  };

  const processDaySwipe = (target: HTMLElement | null) => {
    if (!dayTouchStartRef.current) return;
    const { startX, startY, lastX, lastY, time } = dayTouchStartRef.current;
    dayTouchStartRef.current = null;

    if (target && target.closest('input, textarea, select')) return;

    const deltaX = lastX - startX;
    const deltaY = lastY - startY;
    const deltaTime = Math.max(Date.now() - time, 1);
    const absX = Math.abs(deltaX);
    const absY = Math.abs(deltaY);
    const velocityX = absX / deltaTime; // px per ms

    // Condizioni reattive per il rilevamento dello swipe:
    // 1. Flick veloce: velocità >= 0.20 px/ms con spostamento minimo di 20px
    // 2. Swipe standard: spostamento >= 28px in meno di 700ms
    // Rapporto angolare orizzontale/verticale: absX > absY * 0.75 (accetta l'arco naturale del pollice)
    const isHorizontal = absX > absY * 0.75;
    const isQuickFlick = velocityX >= 0.20 && absX >= 20;
    const isStandardSwipe = absX >= 28 && deltaTime < 700;

    if (isHorizontal && (isQuickFlick || isStandardSwipe)) {
      if (window.navigator?.vibrate) {
        try {
          window.navigator.vibrate(10);
        } catch {}
      }
      if (deltaX < 0) {
        handleNextDay();
      } else {
        handlePrevDay();
      }
    }
  };

  const handleWorkoutTouchEnd = (e: React.TouchEvent) => {
    processDaySwipe(e.target as HTMLElement | null);
  };

  const handleWorkoutTouchCancel = (e: React.TouchEvent) => {
    processDaySwipe(e.target as HTMLElement | null);
  };

  const dayMouseStartRef = useRef<{ x: number; y: number; time: number } | null>(null);

  const handleWorkoutMouseDown = (e: React.MouseEvent) => {
    if (e.button !== 0) return;
    const target = e.target as HTMLElement | null;
    if (target && target.closest('input, textarea, select, button, a')) return;
    dayMouseStartRef.current = {
      x: e.clientX,
      y: e.clientY,
      time: Date.now(),
    };
  };

  const handleWorkoutMouseUp = (e: React.MouseEvent) => {
    if (!dayMouseStartRef.current) return;
    const start = dayMouseStartRef.current;
    dayMouseStartRef.current = null;

    const deltaX = e.clientX - start.x;
    const deltaY = e.clientY - start.y;
    const deltaTime = Math.max(Date.now() - start.time, 1);
    const absX = Math.abs(deltaX);
    const absY = Math.abs(deltaY);
    const velocityX = absX / deltaTime;

    const isHorizontal = absX > absY * 0.75;
    const isQuickFlick = velocityX >= 0.20 && absX >= 22;
    const isStandardSwipe = absX >= 32 && deltaTime < 700;

    if (isHorizontal && (isQuickFlick || isStandardSwipe)) {
      if (deltaX < 0) {
        handleNextDay();
      } else {
        handlePrevDay();
      }
    }
  };

  const [currentTab, setCurrentTab] = useState<'workout' | 'rankings' | 'progression'>('workout');
  const [previousTab, setPreviousTab] = useState<typeof currentTab>('workout');
  const [tabDirection, setTabDirection] = useState<1 | -1>(1);

  const handleTabChange = (newTab: typeof currentTab) => {
    if (newTab === currentTab) return;
    // Chiude qualsiasi modale aperto a livello di applicazione al cambio scheda
    setOcrModalOpen(false);
    setAddExerciseModalOpen(false);
    setSupersetSourceExercise(null);
    setOnboardingModalOpen(false);
    setDeloadModalOpen(false);

    const oldIdx = TAB_ORDER.indexOf(currentTab);
    const newIdx = TAB_ORDER.indexOf(newTab);
    setTabDirection(newIdx > oldIdx ? 1 : -1);
    setPreviousTab(currentTab);
    setCurrentTab(newTab);
  };

  // Transizione cross-fade fluida, rilassante ed elegante (nessun movimento orizzontale per evitare vertigini visive).
  // Quando si passa direttamente tra Scheda e Grafici, il pannello Ranking
  // non è coinvolto nell'animazione e resta al 100% invisibile (visibility: hidden, opacity: 0).
  const getTabMotionProps = (tabKey: 'workout' | 'rankings' | 'progression') => {
    const isActive = currentTab === tabKey;
    const isExiting = previousTab === tabKey && !isActive;

    if (isActive) {
      return {
        animate: { opacity: 1 },
        style: {
          zIndex: 2,
          pointerEvents: 'auto' as const,
          visibility: 'visible' as const,
        },
      };
    }

    if (isExiting) {
      return {
        animate: { opacity: 0 },
        style: {
          zIndex: 1,
          pointerEvents: 'none' as const,
          visibility: 'visible' as const,
        },
      };
    }

    return {
      animate: { opacity: 0 },
      style: {
        zIndex: 0,
        pointerEvents: 'none' as const,
        visibility: 'hidden' as const,
      },
    };
  };

  // Modals state
  const [ocrModalOpen, setOcrModalOpen] = useState(false);
  const [addExerciseModalOpen, setAddExerciseModalOpen] = useState(false);
  const [supersetSourceExercise, setSupersetSourceExercise] = useState<Exercise | null>(null);
  const [onboardingModalOpen, setOnboardingModalOpen] = useState(false);
  const [deloadModalOpen, setDeloadModalOpen] = useState(false);
  const [resetNotice, setResetNotice] = useState<string | null>(null);
  const [sortNotice, setSortNotice] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = useCallback((msg: string, durationMs = 2000) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), durationMs);
  }, []);

  const activeDeloadConfig =
    DELOAD_OPTIONS.find((o) => o.id === (routine.deloadType || 'mixed')) || DELOAD_OPTIONS[2];

  // Auto-apri modale profilo all'avvio se il nome utente non è ancora stato inserito
  useEffect(() => {
    if (!profile.name || profile.name.trim() === '') {
      setOnboardingModalOpen(true);
    }
  }, []);

  // Sincronizzazione automatica degli spazi safe-area con il layout di sistema
  useEffect(() => {
    applySafeAreaInsets();
  }, []);

  // Timer state
  const [timerState, setTimerState] = useState<{
    isOpen: boolean;
    seconds: number;
    exerciseName: string;
  }>({
    isOpen: false,
    seconds: 90,
    exerciseName: '',
  });

  // AUTO-RESET DELLE SERIE COMPLETATE AL PASSAGGIO AL GIORNO SUCCESSIVO (dal giorno del telefono)
  useEffect(() => {
    const checkDateAndReset = () => {
      const todayString = new Date().toDateString();
      const lastRecordedDate = localStorage.getItem('gym_app_last_active_date_v1');

      if (lastRecordedDate && lastRecordedDate !== todayString) {
        // Il giorno del telefono è cambiato: azzera tutte le spunte di completamento
        setRoutine((prevRoutine) => ({
          ...prevRoutine,
          days: prevRoutine.days.map((day) => ({
            ...day,
            exercises: day.exercises.map((ex) => ({
              ...ex,
              sets: ex.sets.map((s) => ({ ...s, completed: false })),
            })),
          })),
        }));
        setResetNotice('Nuovo giorno: le spunte delle serie sono state azzerate per la nuova sessione.');
        setTimeout(() => setResetNotice(null), 5000);
      }
      localStorage.setItem('gym_app_last_active_date_v1', todayString);
    };

    checkDateAndReset();

    // Ascolta anche quando l'utente riprende il telefono o riapre l'app
    window.addEventListener('focus', checkDateAndReset);
    document.addEventListener('visibilitychange', checkDateAndReset);
    return () => {
      window.removeEventListener('focus', checkDateAndReset);
      document.removeEventListener('visibilitychange', checkDateAndReset);
    };
  }, []);

  // Save changes to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('gym_app_routine_v3', JSON.stringify(routine));
    } catch {}
  }, [routine]);

  useEffect(() => {
    try {
      localStorage.setItem('gym_app_profile_v3', JSON.stringify(profile));
    } catch {}
  }, [profile]);

  useEffect(() => {
    try {
      localStorage.setItem('gym_app_logs_v4', JSON.stringify(progressionLogs));
    } catch {}
  }, [progressionLogs]);

  const activeDay = useMemo(() => {
    return routine.days.find((d) => d.id === selectedDayId) || routine.days[0];
  }, [routine.days, selectedDayId]);

  // Calcolo memoizzato dei gruppi superset per evitare ricalcoli inutili
  const activeDayGroups = useMemo(() => {
    if (!activeDay || !activeDay.exercises) return [];
    return groupExercisesBySuperset(activeDay.exercises);
  }, [activeDay]);

  // Inserimento tramite OCR
  const handleImportOcrExercises = useCallback((newExercises: Exercise[]) => {
    setRoutine((prevRoutine) => {
      const targetDay = prevRoutine.days.find((d) => d.id === selectedDayId) || prevRoutine.days[0];
      if (!targetDay) return prevRoutine;

      const updatedDays = prevRoutine.days.map((day, idx) => {
        if (day.id === targetDay.id) {
          return syncDayMetadata(
            {
              ...day,
              exercises: [...day.exercises, ...newExercises],
            },
            idx
          );
        }
        return day;
      });
      return { ...prevRoutine, days: updatedDays };
    });
  }, [selectedDayId]);

  // Inserimento manuale esercizio (supporta anche creazione collegata in Superset)
  const handleAddManualExercise = useCallback((exercise: Exercise) => {
    setRoutine((prevRoutine) => {
      const targetDay = prevRoutine.days.find((d) => d.id === selectedDayId) || prevRoutine.days[0];
      if (!targetDay) return prevRoutine;

      if (supersetSourceExercise) {
        const newGroupId = `superset-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
        const sourceIdx = targetDay.exercises.findIndex((e) => e.id === supersetSourceExercise.id);

        const linkedNewEx: Exercise = {
          ...exercise,
          supersetGroupId: newGroupId,
          isSuperset: true,
        };

        const list = targetDay.exercises.map((ex) => {
          if (ex.id === supersetSourceExercise.id) {
            return { ...ex, supersetGroupId: newGroupId, isSuperset: true };
          }
          return ex;
        });

        if (sourceIdx !== -1) {
          list.splice(sourceIdx + 1, 0, linkedNewEx);
        } else {
          list.push(linkedNewEx);
        }

        const updatedDays = prevRoutine.days.map((day, idx) => {
          if (day.id === targetDay.id) {
            return syncDayMetadata({ ...day, exercises: list }, idx);
          }
          return day;
        });

        return { ...prevRoutine, days: updatedDays };
      }

      const updatedDays = prevRoutine.days.map((day, idx) => {
        if (day.id === targetDay.id) {
          return syncDayMetadata(
            {
              ...day,
              exercises: [...day.exercises, exercise],
            },
            idx
          );
        }
        return day;
      });
      return { ...prevRoutine, days: updatedDays };
    });

    if (supersetSourceExercise) {
      setSortNotice(`Superset creato: ${supersetSourceExercise.name} + ${exercise.name}!`);
      setTimeout(() => setSortNotice(null), 3500);
      setSupersetSourceExercise(null);
      setAddExerciseModalOpen(false);
    }
    showToast('Esercizio aggiunto');
  }, [selectedDayId, supersetSourceExercise]);

  // Collega due esercizi già presenti nella scheda di oggi in Superset
  const handleLinkExistingExercises = useCallback((sourceExerciseId: string, targetExerciseId: string) => {
    let sourceName = '';
    let targetName = '';

    setRoutine((prevRoutine) => {
      const targetDay = prevRoutine.days.find((d) => d.id === selectedDayId) || prevRoutine.days[0];
      if (!targetDay) return prevRoutine;

      const sourceIdx = targetDay.exercises.findIndex((e) => e.id === sourceExerciseId);
      const targetIdx = targetDay.exercises.findIndex((e) => e.id === targetExerciseId);
      if (sourceIdx === -1 || targetIdx === -1) return prevRoutine;

      const sourceEx = targetDay.exercises[sourceIdx];
      const targetEx = targetDay.exercises[targetIdx];
      sourceName = sourceEx.name;
      targetName = targetEx.name;

      const newGroupId = `superset-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;

      // Rimuovi target dalla posizione attuale
      const list = targetDay.exercises.filter((e) => e.id !== targetExerciseId);
      const newSourceIdx = list.findIndex((e) => e.id === sourceExerciseId);

      const updatedSource = { ...sourceEx, supersetGroupId: newGroupId, isSuperset: true };
      const updatedTarget = { ...targetEx, supersetGroupId: newGroupId, isSuperset: true };

      list[newSourceIdx] = updatedSource;
      list.splice(newSourceIdx + 1, 0, updatedTarget);

      const updatedDays = prevRoutine.days.map((day) => {
        if (day.id === targetDay.id) {
          return { ...day, exercises: list };
        }
        return day;
      });

      return { ...prevRoutine, days: updatedDays };
    });

    if (sourceName && targetName) {
      setSortNotice(`Superset creato: ${sourceName} + ${targetName}!`);
      setTimeout(() => setSortNotice(null), 3500);
    }
    setSupersetSourceExercise(null);
    setAddExerciseModalOpen(false);
  }, [selectedDayId]);

  // Scollega esercizi dal Superset (tornano singoli)
  const handleUnlinkSuperset = useCallback((groupIdOrExerciseId: string) => {
    setRoutine((prevRoutine) => {
      const targetDay = prevRoutine.days.find((d) => d.id === selectedDayId) || prevRoutine.days[0];
      if (!targetDay) return prevRoutine;

      let targetGroupId = groupIdOrExerciseId;
      const targetEx = targetDay.exercises.find((e) => e.id === groupIdOrExerciseId);
      if (targetEx?.supersetGroupId) {
        targetGroupId = targetEx.supersetGroupId;
      }

      const updatedExercises = targetDay.exercises.map((e) => {
        if (e.supersetGroupId === targetGroupId) {
          return { ...e, supersetGroupId: undefined, isSuperset: false };
        }
        return e;
      });

      const updatedDays = prevRoutine.days.map((day) => {
        if (day.id === targetDay.id) {
          return { ...day, exercises: updatedExercises };
        }
        return day;
      });

      return { ...prevRoutine, days: updatedDays };
    });

    setSortNotice('Superset scollegato: gli esercizi sono ora indipendenti.');
    setTimeout(() => setSortNotice(null), 3000);
  }, [selectedDayId]);

  // Aggiornamento esercizio & sincronizzazione automatica log progressi
  const handleUpdateExercise = useCallback((updatedEx: Exercise) => {
    setRoutine((prevRoutine) => {
      const updatedDays = prevRoutine.days.map((day, idx) => {
        const hasEx = day.exercises.some((ex) => ex.id === updatedEx.id);
        if (hasEx) {
          const updatedExercises = day.exercises.map((ex) => (ex.id === updatedEx.id ? updatedEx : ex));
          return syncDayMetadata(
            {
              ...day,
              exercises: updatedExercises,
            },
            idx
          );
        }
        return day;
      });
      return { ...prevRoutine, days: updatedDays };
    });

    // Ignora esercizi di riscaldamento generico (nessun carico)
    if (updatedEx.category === 'warmup') {
      return;
    }

    // Sincronizza lo storico dei carichi SOLO quando tutte le serie da lavoro sono effettivamente completate (reps > 0)
    const workingSets = updatedEx.sets.filter((s) => s.setType !== 'warmup');
    const isExerciseFullyLogged =
      workingSets.length > 0 && workingSets.every((s) => s.completed && s.reps > 0);

    if (isExerciseFullyLogged) {
      const completedSets = workingSets;
      const todayStr = new Date().toISOString().slice(0, 10);
      let maxWeight = 0;
      let repsAtMax = 0;

      completedSets.forEach((s) => {
        const effectiveLoad = getEffectiveWeight(updatedEx, s.weight, profile);
        const setWeight = effectiveLoad !== null ? effectiveLoad : s.weight;
        if (setWeight > maxWeight) {
          maxWeight = setWeight;
          repsAtMax = s.reps;
        } else if (setWeight === maxWeight && s.reps > repsAtMax) {
          repsAtMax = s.reps;
        }
      });

      const volRes = calculateExerciseVolume({ ...updatedEx, sets: completedSets }, profile, true);
      const totalVolume = volRes.value !== null ? volRes.value : 0;

      const estimated1RM =
        repsAtMax > 0 ? Math.round(maxWeight * (1 + repsAtMax / 30) * 10) / 10 : maxWeight;
      const trimmedExName = updatedEx.name.trim();

      const performedSets = completedSets.map((s, idx) => ({
        setNumber: s.setNumber || idx + 1,
        weight: s.weight,
        reps: s.reps,
        completed: true,
        setType: s.setType,
      }));

      setProgressionLogs((prev) => {
        const existingIdx = prev.findIndex(
          (log) =>
            log.exerciseName.trim().toLowerCase() === trimmedExName.toLowerCase() &&
            log.date === todayStr
        );

        // Calcola se è un nuovo PR rispetto allo storico passato
        const pastLogs = prev.filter(
          (log) =>
            log.exerciseName.trim().toLowerCase() === trimmedExName.toLowerCase() &&
            log.date !== todayStr
        );
        const pastMaxWeight = pastLogs.length > 0 ? Math.max(...pastLogs.map((l) => l.maxWeight)) : 0;
        const pastMax1RM = pastLogs.length > 0 ? Math.max(...pastLogs.map((l) => l.estimated1RM)) : 0;
        const isPR = pastLogs.length > 0 && (maxWeight > pastMaxWeight || estimated1RM > pastMax1RM);

        const newLog: ProgressionLog = {
          id: existingIdx >= 0 ? prev[existingIdx].id : `log-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          date: todayStr,
          exerciseName: trimmedExName,
          targetMuscle: updatedEx.targetMuscle,
          maxWeight,
          repsAtMax,
          estimated1RM,
          totalVolume,
          performedSets,
          isPR,
        };

        if (existingIdx >= 0) {
          const copy = [...prev];
          copy[existingIdx] = newLog;
          return copy;
        }
        return [...prev, newLog];
      });
    } else {
      // Se un log di oggi per questo esercizio esisteva da un completamento precedente ma ora
      // l'esercizio non è più interamente completato (es. serie despuntata), rimuovilo per non lasciare dati incoerenti
      const todayStr = new Date().toISOString().slice(0, 10);
      const trimmedExName = updatedEx.name.trim();
      setProgressionLogs((prev) => {
        const hasStaleLog = prev.some(
          (log) =>
            log.exerciseName.trim().toLowerCase() === trimmedExName.toLowerCase() &&
            log.date === todayStr
        );
        if (!hasStaleLog) return prev; // nessuna modifica, stesso riferimento
        return prev.filter(
          (log) =>
            !(
              log.exerciseName.trim().toLowerCase() === trimmedExName.toLowerCase() &&
              log.date === todayStr
            )
        );
      });
    }
  }, [profile]);

  // Eliminazione esercizio e pulizia del gruppo superset se rimane orfano
  const handleDeleteExercise = useCallback((exerciseId: string) => {
    setRoutine((prevRoutine) => {
      const updatedDays = prevRoutine.days.map((day, idx) => {
        const deletedEx = day.exercises.find((e) => e.id === exerciseId);
        if (!deletedEx) return day;

        let remaining = day.exercises.filter((ex) => ex.id !== exerciseId);

        if (deletedEx.supersetGroupId) {
          const gId = deletedEx.supersetGroupId;
          const groupMembers = remaining.filter((e) => e.supersetGroupId === gId);
          if (groupMembers.length <= 1) {
            remaining = remaining.map((e) =>
              e.supersetGroupId === gId ? { ...e, supersetGroupId: undefined, isSuperset: false } : e
            );
          }
        }

        return syncDayMetadata(
          {
            ...day,
            exercises: remaining,
          },
          idx
        );
      });

      return { ...prevRoutine, days: updatedDays };
    });
  }, []);

  // Spostamento su/giù di un elemento o blocco superset
  const handleMoveGroupItem = useCallback((groupIndex: number, direction: -1 | 1) => {
    setRoutine((prevRoutine) => {
      const currentDay = prevRoutine.days.find((d) => d.id === selectedDayId) || prevRoutine.days[0];
      if (!currentDay) return prevRoutine;

      const groups = groupExercisesBySuperset(currentDay.exercises);
      const targetIdx = groupIndex + direction;
      if (targetIdx < 0 || targetIdx >= groups.length) return prevRoutine;

      const list = [...groups];
      const [moved] = list.splice(groupIndex, 1);
      list.splice(targetIdx, 0, moved);

      const flattened = list.flatMap((g) => g.exercises);

      const updatedDays = prevRoutine.days.map((day, idx) => {
        if (day.id === currentDay.id) {
          return syncDayMetadata({ ...day, exercises: flattened }, idx);
        }
        return day;
      });
      return { ...prevRoutine, days: updatedDays };
    });
  }, [selectedDayId]);

  const handleMoveGroupUp = useCallback((index: number) => {
    handleMoveGroupItem(index, -1);
  }, [handleMoveGroupItem]);

  const handleMoveGroupDown = useCallback((index: number) => {
    handleMoveGroupItem(index, 1);
  }, [handleMoveGroupItem]);

  // Rinomina giorno con supporto al reset del nome automatico se svuotato
  const handleUpdateDayName = useCallback((dayId: string, newName: string) => {
    setRoutine((prev) => ({
      ...prev,
      days: prev.days.map((d, index) => {
        if (d.id !== dayId) return d;
        const trimmed = newName.trim();
        if (!trimmed) {
          const dayLetter = String.fromCharCode(65 + index);
          return {
            ...d,
            name: generateDayName(d.exercises, dayLetter),
            isNameCustom: false,
          };
        }
        return {
          ...d,
          name: trimmed,
          isNameCustom: true,
        };
      }),
    }));
  }, []);

  // Aggiorna i giorni della settimana programmati per un giorno di allenamento
  const handleUpdateDaySchedule = useCallback((dayId: string, scheduledDays: number[]) => {
    setRoutine((prev) => ({
      ...prev,
      days: prev.days.map((d) =>
        d.id === dayId ? { ...d, scheduledDays } : d
      ),
    }));
  }, []);

  // Aggiungi nuovo giorno
  const handleAddDay = useCallback(() => {
    setRoutine((prev) => {
      const nextIndex = prev.days.length;
      const newDay: WorkoutDay = syncDayMetadata(
        {
          id: `day-${Date.now()}`,
          name: '',
          focusMuscles: [],
          exercises: [],
          isNameCustom: false,
        },
        nextIndex
      );
      setSelectedDayId(newDay.id);
      return {
        ...prev,
        days: [...prev.days, newDay],
      };
    });
  }, []);

  // Spostamento giorno a sinistra/destra
  const handleMoveDay = useCallback((fromIndex: number, toIndex: number) => {
    setRoutine((prev) => {
      if (toIndex < 0 || toIndex >= prev.days.length) return prev;
      const list = [...prev.days];
      const [moved] = list.splice(fromIndex, 1);
      list.splice(toIndex, 0, moved);
      return {
        ...prev,
        days: list.map((day, idx) => syncDayMetadata(day, idx)),
      };
    });
  }, []);

  // Elimina giorno
  const handleDeleteDay = useCallback((dayId: string) => {
    setRoutine((prev) => {
      if (prev.days.length <= 1) return prev;
      const remainingDays = prev.days.filter((d) => d.id !== dayId);
      setSelectedDayId((currId) => (currId === dayId ? remainingDays[0].id : currId));
      return {
        ...prev,
        days: remainingDays.map((day, idx) => syncDayMetadata(day, idx)),
      };
    });
  }, []);

  // Riordino selettivo degli esercizi del giorno attivo in base al criterio scelto
  const handleSortWorkout = useCallback((criterion: WorkoutSortCriterion) => {
    setRoutine((prev) => {
      const targetDay = prev.days.find((d) => d.id === selectedDayId) || prev.days[0];
      if (!targetDay || targetDay.exercises.length === 0) return prev;

      const sorted = sortExercisesByCriterion(targetDay.exercises, criterion);

      const updatedDays = prev.days.map((day) => {
        if (day.id === targetDay.id) {
          return { ...day, exercises: sorted };
        }
        return day;
      });
      return { ...prev, days: updatedDays };
    });

    const option = SORT_OPTIONS.find((o) => o.id === criterion);
    const text = option ? option.noticeText : 'Scheda riorganizzata';
    setSortNotice(text);
    setTimeout(() => setSortNotice(null), 3000);
  }, [selectedDayId]);

  // Azzera manualmente le spunte del giorno attivo e il timer di recupero
  const handleResetCurrentDayChecks = useCallback(() => {
    const todayStr = new Date().toISOString().slice(0, 10);

    setRoutine((prev) => {
      const targetDay = prev.days.find((d) => d.id === selectedDayId) || prev.days[0];
      if (!targetDay) return prev;

      // Rimuovi eventuali log creati oggi per gli esercizi di questa giornata
      if (targetDay.exercises.length > 0) {
        const dayExNames = new Set(targetDay.exercises.map((e) => e.name.trim().toLowerCase()));
        setProgressionLogs((prevLogs) => {
          const hasStale = prevLogs.some(
            (l) => l.date === todayStr && dayExNames.has(l.exerciseName.trim().toLowerCase())
          );
          if (!hasStale) return prevLogs;
          return prevLogs.filter(
            (l) => !(l.date === todayStr && dayExNames.has(l.exerciseName.trim().toLowerCase()))
          );
        });
      }

      const updatedDays = prev.days.map((day) => {
        if (day.id === targetDay.id) {
          return {
            ...day,
            exercises: day.exercises.map((ex) => ({
              ...ex,
              sets: ex.sets.map((s) => ({ ...s, completed: false })),
            })),
          };
        }
        return day;
      });
      return { ...prev, days: updatedDays };
    });

    // Azzera anche il timer attivo
    setTimerState({
      isOpen: false,
      seconds: 90,
      exerciseName: '',
    });
    setResetNotice('Timer e serie completate della giornata azzerati!');
    setTimeout(() => setResetNotice(null), 3000);
    showToast('Giornata azzerata');
  }, [selectedDayId, showToast]);

  // Toggle Superset: apre la selezione esercizio in modalità collegamento, oppure scollega se già legato
  const handleToggleSuperset = useCallback((exerciseId: string) => {
    if (!activeDay) return;
    const ex = activeDay.exercises.find((e) => e.id === exerciseId);
    if (!ex) return;

    if (ex.supersetGroupId) {
      handleUnlinkSuperset(ex.supersetGroupId);
    } else {
      setSupersetSourceExercise(ex);
      setAddExerciseModalOpen(true);
    }
  }, [activeDay, handleUnlinkSuperset]);

  // Gestione Settimana di Scarico (Deload): Apertura modale
  const handleToggleDeload = useCallback(() => {
    setDeloadModalOpen(true);
  }, []);

  // Selezione specifica del tipo di Deload (Volume, Intensità, Misto)
  const handleSelectDeload = useCallback((type: DeloadType) => {
    setRoutine((prev) => ({
      ...prev,
      isDeloadWeek: true,
      deloadType: type,
    }));
    const cfg = DELOAD_OPTIONS.find((o) => o.id === type);
    setSortNotice(cfg ? `Attivato ${cfg.name}` : 'Scarico Deload attivato');
    setTimeout(() => setSortNotice(null), 3000);
  }, []);

  // Disattivazione Deload
  const handleDisableDeload = useCallback(() => {
    setRoutine((prev) => ({
      ...prev,
      isDeloadWeek: false,
    }));
    setDeloadModalOpen(false);
    setResetNotice('Settimana di scarico disattivata: ripristinati carichi normali.');
    setTimeout(() => setResetNotice(null), 3000);
  }, []);

  // Start Rest Timer
  const handleStartRestTimer = useCallback((seconds: number, exerciseName: string) => {
    setTimerState({
      isOpen: true,
      seconds: seconds > 0 ? seconds : 90,
      exerciseName,
    });
  }, []);

  // Chiudi Rest Timer
  const handleCloseTimer = useCallback(() => {
    setTimerState((prev) => ({ ...prev, isOpen: false }));
  }, []);

  // Feature 2B: Android Back Guard per intercettare il tasto indietro hardware e chiudere le modali
  const isAnyModalOpen =
    ocrModalOpen || addExerciseModalOpen || onboardingModalOpen ||
    deloadModalOpen || timerState.isOpen;

  const closeTopModal = useCallback(() => {
    if (ocrModalOpen) return setOcrModalOpen(false);
    if (addExerciseModalOpen) { setAddExerciseModalOpen(false); setSupersetSourceExercise(null); return; }
    if (onboardingModalOpen) return setOnboardingModalOpen(false);
    if (deloadModalOpen) return setDeloadModalOpen(false);
    if (timerState.isOpen) return handleCloseTimer();
  }, [ocrModalOpen, addExerciseModalOpen, onboardingModalOpen, deloadModalOpen, timerState.isOpen, handleCloseTimer]);

  useAndroidBackGuard(isAndroidDevice && isAnyModalOpen, closeTopModal);

  // Refs per i 3 pannelli della filmstrip
  const workoutPanelRef = useRef<HTMLDivElement>(null);
  const rankingsPanelRef = useRef<HTMLDivElement>(null);
  const progressionPanelRef = useRef<HTMLDivElement>(null);

  // Feature 3: Scroll-to-Hide Header associato al pannello attivo
  const panelRefs = {
    workout: workoutPanelRef,
    rankings: rankingsPanelRef,
    progression: progressionPanelRef,
  } as const;
  const activeScrollRef = panelRefs[currentTab];
  const headerRef = useRef<HTMLElement>(null);

  // Pattern 4: Misurazione dinamica dell'altezza reale della barra di navigazione inferiore
  const navRef = useRef<HTMLElement>(null);
  const [navHeight, setNavHeight] = useState<number>(64);

  useEffect(() => {
    if (!navRef.current) return;
    const updateNavHeight = () => {
      if (navRef.current) {
        const h = navRef.current.getBoundingClientRect().height;
        if (h > 0) setNavHeight(Math.round(h));
      }
    };
    updateNavHeight();
    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        if (entry.contentRect.height > 0) {
          setNavHeight(Math.round(entry.contentRect.height));
        }
      }
    });
    observer.observe(navRef.current);
    return () => observer.disconnect();
  }, []);

  // Feature 4: Auto-scroll alla prima serie incompleta (solo al cambio di giorno o al mount iniziale)
  const lastScrolledDayRef = useRef<string | null>(null);

  const firstIncompleteExercise = useMemo(() => {
    if (currentTab !== 'workout' || !activeDay) return null;
    return activeDay.exercises.find((ex) => ex.sets.some((s) => !s.completed)) || null;
  }, [currentTab, activeDay]);

  useEffect(() => {
    if (currentTab !== 'workout' || !activeDay || !firstIncompleteExercise) return;

    if (lastScrolledDayRef.current !== selectedDayId) {
      lastScrolledDayRef.current = selectedDayId;
      const timer = setTimeout(() => {
        const el = document.querySelector(`[data-exercise-id="${firstIncompleteExercise.id}"]`);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }, 150);
      return () => clearTimeout(timer);
    }
  }, [selectedDayId, currentTab, activeDay, firstIncompleteExercise]);

  // Feature 4: Visibilità del Floating Target Button basata sull'IntersectionObserver
  const [isCurrentExerciseOutOfView, setIsCurrentExerciseOutOfView] = useState(false);

  useEffect(() => {
    if (currentTab !== 'workout' || !firstIncompleteExercise) {
      setIsCurrentExerciseOutOfView(false);
      return;
    }

    const el = document.querySelector(`[data-exercise-id="${firstIncompleteExercise.id}"]`);
    if (!el) {
      setIsCurrentExerciseOutOfView(false);
      return;
    }

    const observer = new IntersectionObserver(
      ([entry]) => {
        setIsCurrentExerciseOutOfView(!entry.isIntersecting);
      },
      {
        root: workoutPanelRef.current,
        threshold: 0.15,
      }
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, [currentTab, firstIncompleteExercise?.id]);

  const handleScrollToCurrentExercise = useCallback(() => {
    if (!firstIncompleteExercise) return;
    const el = document.querySelector(`[data-exercise-id="${firstIncompleteExercise.id}"]`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }, [firstIncompleteExercise]);

  // Aggiornamento profilo utente
  const handleUpdateProfile = useCallback((p: UserProfile) => {
    setProfile(p);
    showToast('Impostazioni salvate');
  }, []);

  return (
    <div
      className="h-full h-[100dvh] w-full relative bg-[#090d16] text-slate-100 flex flex-col items-center justify-start overflow-hidden select-none"
      onWheel={(e) => {
        // Se il cursore si trova sui margini esterni vuoti (bordi dx/sx), inoltra lo scroll al pannello attivo
        if (activeScrollRef?.current && e.target === e.currentTarget) {
          activeScrollRef.current.scrollTop += e.deltaY;
        }
      }}
    >
      {/* VisionOS / Apple Glass Ambient Luminous Light Orbs (isolati su layer GPU dedicato) */}
      <div className="fixed top-[-10%] left-[15%] w-[450px] h-[450px] rounded-full bg-[radial-gradient(circle,rgba(56,189,248,0.12)_0%,transparent_70%)] pointer-events-none z-0 [transform:translateZ(0)] will-change-transform [contain:layout_paint]" />
      <div className="fixed bottom-[5%] right-[10%] w-[500px] h-[500px] rounded-full bg-[radial-gradient(circle,rgba(99,102,241,0.12)_0%,transparent_70%)] pointer-events-none z-0 [transform:translateZ(0)] will-change-transform [contain:layout_paint]" />

      {/* Main Native Application Canvas (App vera e propria, edge-to-edge nativa) */}
      <main
        style={{
          paddingTop: 'calc(0.75rem + var(--app-safe-top, 0px))',
          // Pattern 4: Spaziatura inferiore calcolata dinamicamente sull'altezza reale del dock (+ 14px margine e safe area)
          paddingBottom: `calc(${navHeight + 14}px + var(--app-safe-bottom, 0px))`,
        }}
        className="w-full max-w-xl md:max-w-2xl lg:max-w-3xl h-full min-h-0 flex-1 flex flex-col relative z-10 mx-auto px-3.5 sm:px-5 overflow-hidden"
      >
        {/* Specular Refraction Accent */}
        <div className="absolute top-0 left-8 right-8 h-[1px] bg-gradient-to-r from-transparent via-white/30 to-transparent pointer-events-none" />

        {/* Top Native App Header Bar */}
        <header
          ref={headerRef}
          className="flex items-center justify-between gap-3 pt-2 pb-3 mb-1 border-b border-white/10 relative z-20 shrink-0 [transform:translateZ(0)]"
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <motion.button
              type="button"
              whileTap={{ scale: 0.92 }}
              onClick={() => setOnboardingModalOpen(true)}
              className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-gradient-to-tr from-sky-500 to-blue-600 flex items-center justify-center text-white shadow-lg shadow-sky-500/30 border border-white/20 shrink-0"
              title="Profilo e Calibrazione"
            >
              <Dumbbell className="w-5 h-5" />
            </motion.button>
            <div className="min-w-0 flex-1">
              <h1 className="text-sm sm:text-base font-black text-white tracking-tight break-words line-clamp-1" title={profile.name}>
                Bentornato{profile.name ? `, ${profile.name}` : ''}
              </h1>
              <p className="text-[10px] sm:text-[11px] text-slate-400 font-medium break-words line-clamp-1">
                {profile.bodyWeightKg ? `${profile.bodyWeightKg} ${profile.unit}` : ''}
                {profile.heightCm ? ` • ${profile.heightCm} cm` : ''}
                {` • ${profile.rankingMode === 'relative' ? 'Rank Relativo' : 'Rank Assoluto'}`}
              </p>
            </div>
          </div>

          {/* Quick Header Actions (Deload, Export Native, Theme, Settings) */}
          <div className="flex items-center gap-1.5 shrink-0">
            <motion.button
              type="button"
              whileTap={{ scale: 0.92 }}
              onClick={handleToggleDeload}
              className={`text-[10px] sm:text-xs font-extrabold px-2.5 sm:px-3 py-1.5 rounded-2xl border transition-all backdrop-blur-md flex items-center gap-1 min-h-[38px] ${
                routine.isDeloadWeek
                  ? 'bg-amber-500/30 text-amber-300 border-amber-400/50 shadow-md shadow-amber-500/20'
                  : 'bg-white/[0.06] text-slate-300 border-white/10 hover:text-white'
              }`}
              title="Gestisci e visualizza i 3 tipi di scarico (Deload)"
            >
              <Flame className={`w-3.5 h-3.5 ${routine.isDeloadWeek ? 'text-amber-400 animate-pulse' : ''}`} />
              <span>
                {routine.isDeloadWeek
                  ? activeDeloadConfig.id === 'volume'
                    ? 'Scarico Volume'
                    : activeDeloadConfig.id === 'intensity'
                    ? 'Scarico Intensità'
                    : 'Scarico Misto'
                  : 'Deload'}
              </span>
            </motion.button>

            <motion.button
              type="button"
              whileTap={{ scale: 0.92 }}
              onClick={() => setOnboardingModalOpen(true)}
              className="p-2 sm:p-2.5 rounded-2xl bg-white/[0.06] hover:bg-white/10 text-slate-300 border border-white/10 backdrop-blur-md transition-all min-w-[38px] min-h-[38px] flex items-center justify-center"
              title="Profilo & Impostazioni"
            >
              <Settings className="w-4 h-4" />
            </motion.button>
          </div>
        </header>

        {/* Date Auto-Reset Notification Alert if day changed */}
        {resetNotice && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="my-2 p-3 rounded-2xl bg-emerald-500/15 border border-emerald-400/30 text-emerald-300 text-xs font-bold flex items-center gap-2 shadow-lg backdrop-blur-md"
          >
            <CheckCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{resetNotice}</span>
          </motion.div>
        )}

        {/* Toast leggero riordino scheda con testo dinamico in base al criterio */}
        {sortNotice && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="my-2 p-3 rounded-2xl bg-sky-500/15 border border-sky-400/30 text-sky-200 text-xs font-bold flex items-center justify-between gap-2 shadow-lg backdrop-blur-md"
          >
            <div className="flex items-center gap-2">
              <ArrowUpDown className="w-4 h-4 text-sky-400 shrink-0" />
              <span>{sortNotice}</span>
            </div>
            <button
              type="button"
              onClick={() => setSortNotice(null)}
              className="text-sky-300/60 hover:text-sky-200 text-xs px-1 font-normal"
            >
              ✕
            </button>
          </motion.div>
        )}

        {/* Deload Week Banner if active - snello e compatto */}
        {routine.isDeloadWeek && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            className={`my-2 bg-gradient-to-r from-amber-500/20 via-orange-500/15 to-amber-500/20 border border-amber-400/40 ${UI_RADII.card} p-2.5 px-3.5 text-amber-200 text-xs flex items-center justify-between gap-2 shadow-lg backdrop-blur-2xl relative overflow-hidden`}
          >
            <div className={SPECULAR_HIGHLIGHT} />
            <div className="flex items-center gap-2.5 min-w-0 flex-1 relative z-10">
              <div className={`w-7 h-7 ${UI_RADII.control} bg-amber-500/30 flex items-center justify-center text-amber-400 border border-amber-400/30 shrink-0 shadow-sm`}>
                <Flame className="w-3.5 h-3.5 animate-pulse" />
              </div>
              <div className="flex items-center gap-2 min-w-0 flex-1">
                <span className="text-[11px] text-amber-300/80 font-bold uppercase tracking-wider shrink-0">
                  Deload:
                </span>
                <span className="font-black text-white text-xs break-words line-clamp-1">
                  {activeDeloadConfig.name}
                </span>
              </div>
            </div>
            <div className="flex items-center gap-1.5 shrink-0 relative z-10">
              <motion.button
                type="button"
                whileHover={MOTION_PRESETS.buttonHover}
                whileTap={MOTION_PRESETS.buttonTap}
                onClick={() => setDeloadModalOpen(true)}
                className={`px-2.5 py-1.5 ${UI_RADII.control} bg-white/[0.08] hover:bg-white/15 text-white font-extrabold text-[10px] border border-white/15 transition-all whitespace-nowrap`}
                title="Visualizza spiegazione e cambia tipo di scarico"
              >
                Cambia
              </motion.button>
              <motion.button
                type="button"
                whileHover={MOTION_PRESETS.buttonHover}
                whileTap={MOTION_PRESETS.buttonTap}
                onClick={handleDisableDeload}
                className={`px-2.5 py-1.5 ${UI_RADII.control} bg-amber-500/25 hover:bg-rose-500/30 text-amber-200 hover:text-rose-200 font-extrabold text-[10px] border border-amber-400/40 transition-all whitespace-nowrap`}
                title="Disattiva settimana di scarico"
              >
                Disattiva
              </motion.button>
            </div>
          </motion.div>
        )}

        {/* Animated Main Tab Content: pannelli sovrapposti con transizione direzionale indipendente */}
        <div className="flex-1 min-h-0 relative overflow-hidden">
          {/* Pannello 1: Workout */}
          {(() => {
            const motionProps = getTabMotionProps('workout');
            return (
              <motion.div
                ref={workoutPanelRef}
                id="workout-panel"
                initial={false}
                animate={motionProps.animate}
                transition={TAB_TRANSITION}
                onAnimationComplete={() => {
                  if (currentTab === 'workout') setPreviousTab('workout');
                }}
                className="absolute inset-0 w-full h-full overflow-y-auto no-scrollbar space-y-4 pt-1 pb-16 workout-panel-scroll touch-auto [transform:translateZ(0)] will-change-opacity"
                aria-hidden={currentTab !== 'workout'}
                style={{
                  ...motionProps.style,
                  touchAction: 'pan-y',
                }}
              >
              {/* Contenitore Unificato: Carrello Giorni + Scheda Esercizi con swipe touch e mouse ultra-reattivo */}
              <div
                onTouchStart={handleWorkoutTouchStart}
                onTouchMove={handleWorkoutTouchMove}
                onTouchEnd={handleWorkoutTouchEnd}
                onTouchCancel={handleWorkoutTouchCancel}
                onMouseDown={handleWorkoutMouseDown}
                onMouseUp={handleWorkoutMouseUp}
                className={`bg-white/[0.05] backdrop-blur-xl border border-white/10 ${UI_RADII.card} shadow-[0_16px_40px_rgba(0,0,0,0.35),inset_0_1px_1px_rgba(255,255,255,0.15)] relative overflow-hidden [transform:translateZ(0)] will-change-transform`}
              >
                <div className={SPECULAR_HIGHLIGHT} />

                {/* Sezione Superiore: Carrello Giorni di Allenamento */}
                <div className="p-4 sm:p-5">
                  <WorkoutCarousel
                    days={routine.days}
                    selectedDayId={selectedDayId}
                    onSelectDay={(id) => setSelectedDayId(id)}
                    onUpdateDayName={handleUpdateDayName}
                    onUpdateDaySchedule={handleUpdateDaySchedule}
                    onAddDay={handleAddDay}
                    onDeleteDay={handleDeleteDay}
                    onMoveDay={handleMoveDay}
                  />
                </div>

                {/* Divider Interno Sottile */}
                <div className="border-b border-white/10" />

                {/* Sezione Inferiore: Scheda Esercizi e Azioni */}
                <div className="p-4 sm:p-5 space-y-4">
                  <motion.div
                    key={selectedDayId}
                    initial={{ opacity: 0, x: daySwipeDirection * 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.14, ease: [0.22, 1, 0.36, 1] }}
                    className="space-y-4"
                  >
                    {/* Workout Actions Bar: Analizza e ordina, Inserisci Manuale, Foto OCR, Azzera Spunte */}
                    <div className="flex items-center justify-between gap-2 flex-wrap">
                      <div className="flex items-center gap-1.5">
                        {/* Selettore Ordinamento Scheda Dinamico (Apple Glass) */}
                        <WorkoutSortSelector
                          onSelectSort={handleSortWorkout}
                          disabled={!activeDay || activeDay.exercises.length === 0}
                        />

                        {/* Reset Rapido Spunte del Giorno e Timer */}
                        <motion.button
                          type="button"
                          whileHover={MOTION_PRESETS.buttonHover}
                          whileTap={MOTION_PRESETS.buttonTap}
                          onClick={handleResetCurrentDayChecks}
                          className={`flex items-center gap-1.5 px-3 py-2 ${UI_RADII.control} bg-white/[0.06] hover:bg-white/[0.1] text-slate-300 font-bold text-xs border border-white/15 backdrop-blur-xl transition-all`}
                          title="Azzera il timer di recupero attivo e le spunte delle serie completate della giornata"
                        >
                          <RotateCcw className="w-3 h-3 text-slate-400" />
                          <span className="text-[11px]">Azzera timer giornata</span>
                        </motion.button>
                      </div>

                      <div className="flex items-center gap-1.5">
                        {/* Foto OCR */}
                        <motion.button
                          type="button"
                          whileHover={MOTION_PRESETS.buttonHover}
                          whileTap={MOTION_PRESETS.buttonTap}
                          onClick={() => setOcrModalOpen(true)}
                          className={`flex items-center gap-1.5 px-3 py-2 ${UI_RADII.control} bg-white/[0.06] hover:bg-white/[0.1] text-slate-200 font-extrabold text-xs border border-white/15 backdrop-blur-xl transition-all shadow-md`}
                          title="Scansiona scheda cartacea tramite Foto OCR"
                        >
                          <Camera className="w-3.5 h-3.5 text-sky-400" />
                          <span>Foto</span>
                        </motion.button>

                        {/* Inserisci Esercizio (Manuale / Catalogo) */}
                        <motion.button
                          type="button"
                          whileHover={MOTION_PRESETS.buttonHover}
                          whileTap={MOTION_PRESETS.buttonTap}
                          onClick={() => {
                            setSupersetSourceExercise(null);
                            setAddExerciseModalOpen(true);
                          }}
                          className={`flex items-center gap-1 px-3.5 py-2 ${UI_RADII.control} bg-sky-500 hover:bg-sky-400 text-white font-extrabold text-xs shadow-sm border border-sky-400/50 transition-all`}
                        >
                          <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
                          <span>Esercizio</span>
                        </motion.button>
                      </div>
                    </div>

                    {/* Lista Esercizi */}
                    <div className="space-y-3">
                  {activeDay && activeDay.exercises.length > 0 ? (
                    <>
                      {activeDayGroups.map((group, grpIdx) => {
                        if (group.isSuperset) {
                          return (
                            <SupersetGroupCard
                              key={group.id}
                              groupId={group.id}
                              exercises={group.exercises}
                              groupIndex={grpIdx}
                              totalGroups={activeDayGroups.length}
                              profile={profile}
                              isDeload={routine.isDeloadWeek}
                              deloadType={routine.deloadType || 'mixed'}
                              onUpdateExercise={handleUpdateExercise}
                              onDeleteExercise={handleDeleteExercise}
                              onMoveGroupUp={handleMoveGroupUp}
                              onMoveGroupDown={handleMoveGroupDown}
                              onStartRestTimer={handleStartRestTimer}
                              onUnlinkSuperset={handleUnlinkSuperset}
                            />
                          );
                        }

                        const singleEx = group.exercises[0];
                        return (
                          <ExerciseCard
                            key={singleEx.id}
                            exercise={singleEx}
                            index={grpIdx}
                            totalExercises={activeDayGroups.length}
                            profile={profile}
                            isDeload={routine.isDeloadWeek}
                            deloadType={routine.deloadType || 'mixed'}
                            onUpdateExercise={handleUpdateExercise}
                            onDeleteExercise={handleDeleteExercise}
                            onMoveUp={handleMoveGroupUp}
                            onMoveDown={handleMoveGroupDown}
                            onStartRestTimer={handleStartRestTimer}
                            onToggleSuperset={handleToggleSuperset}
                            onUnlinkSuperset={handleUnlinkSuperset}
                          />
                        );
                      })}

                      <motion.button
                        type="button"
                        whileHover={MOTION_PRESETS.cardHover}
                        whileTap={MOTION_PRESETS.buttonTap}
                        onClick={() => {
                          setSupersetSourceExercise(null);
                          setAddExerciseModalOpen(true);
                        }}
                        className={`w-full py-3.5 px-4 ${UI_RADII.card} bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 hover:border-sky-400/40 text-slate-300 hover:text-white font-bold text-xs flex items-center justify-center gap-2 transition-all backdrop-blur-xl shadow-sm`}
                      >
                        <Plus className="w-4 h-4 text-sky-400" />
                        <span>Aggiungi un altro esercizio a questa seduta</span>
                      </motion.button>
                    </>
                  ) : (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.96 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={MOTION_PRESETS.modalSpring}
                      className={`bg-white/[0.04] border border-dashed border-white/20 ${UI_RADII.card} p-8 text-center space-y-3 backdrop-blur-xl shadow-xl relative overflow-hidden`}
                    >
                      <div className={SPECULAR_HIGHLIGHT} />
                      <div className={`w-14 h-14 ${UI_RADII.card} bg-white/10 mx-auto flex items-center justify-center text-slate-300 border border-white/15 shadow-sm`}>
                        <Dumbbell className="w-7 h-7" />
                      </div>
                      <h4 className="text-sm font-extrabold text-white">
                        Nessun esercizio per questa seduta
                      </h4>
                      <p className="text-xs text-slate-400 max-w-xs mx-auto leading-relaxed">
                        Aggiungi i tuoi esercizi manualmente specificando nome e zona muscolare, oppure scansiona la scheda cartacea con Foto OCR.
                      </p>
                      <div className="flex items-center justify-center gap-2 pt-2">
                        <motion.button
                          type="button"
                          whileHover={MOTION_PRESETS.buttonHover}
                          whileTap={MOTION_PRESETS.buttonTap}
                          onClick={() => setAddExerciseModalOpen(true)}
                          className={`px-4 py-2 ${UI_RADII.control} bg-sky-500 hover:bg-sky-400 text-white font-extrabold text-xs shadow-sm border border-sky-400/50`}
                        >
                          Crea Esercizio a Mano
                        </motion.button>
                        <motion.button
                          type="button"
                          whileHover={MOTION_PRESETS.buttonHover}
                          whileTap={MOTION_PRESETS.buttonTap}
                          onClick={() => setOcrModalOpen(true)}
                          className={`px-4 py-2 ${UI_RADII.control} bg-white/10 hover:bg-white/15 text-slate-200 font-bold text-xs border border-white/15 backdrop-blur-md`}
                        >
                          Foto OCR
                        </motion.button>
                      </div>
                    </motion.div>
                  )}
                    </div>
                  </motion.div>
                </div>
              </div>
            </motion.div>
        );
      })()}

          {/* Pannello 2: Rankings */}
          {(() => {
            const motionProps = getTabMotionProps('rankings');
            return (
              <motion.div
                ref={rankingsPanelRef}
                initial={false}
                animate={motionProps.animate}
                transition={TAB_TRANSITION}
                onAnimationComplete={() => {
                  if (currentTab === 'rankings') setPreviousTab('rankings');
                }}
                className="absolute inset-0 w-full h-full overflow-y-auto no-scrollbar pt-1 pb-16 touch-pan-y [transform:translateZ(0)] will-change-opacity"
                aria-hidden={currentTab !== 'rankings'}
                style={{
                  ...motionProps.style,
                  touchAction: 'pan-y',
                }}
              >
                <RankingsView
                  routine={routine}
                  profile={profile}
                  onUpdateProfile={handleUpdateProfile}
                  currentTab={currentTab}
                />
              </motion.div>
            );
          })()}

          {/* Pannello 3: Progression */}
          {(() => {
            const motionProps = getTabMotionProps('progression');
            return (
              <motion.div
                ref={progressionPanelRef}
                initial={false}
                animate={motionProps.animate}
                transition={TAB_TRANSITION}
                onAnimationComplete={() => {
                  if (currentTab === 'progression') setPreviousTab('progression');
                }}
                className="absolute inset-0 w-full h-full overflow-y-auto no-scrollbar pt-1 pb-16 touch-pan-y [transform:translateZ(0)] will-change-opacity"
                aria-hidden={currentTab !== 'progression'}
                style={{
                  ...motionProps.style,
                  touchAction: 'pan-y',
                }}
              >
                <ProgressionView
                  logs={progressionLogs}
                  routine={routine}
                  profile={profile}
                  onClearLogs={handleClearLogs}
                  currentTab={currentTab}
                />
              </motion.div>
            );
          })()}
        </div>

        {/* BOTTOM FLOATING APPLE GLASS DOCK / TAB BAR */}
        <nav
          ref={navRef}
          style={{
            bottom: 'calc(0.75rem + var(--app-safe-bottom, 0px))',
          }}
          className="fixed left-0 right-0 z-40 max-w-xl md:max-w-2xl lg:max-w-3xl mx-auto px-3.5 sm:px-5 pointer-events-none [transform:translateZ(0)] will-change-transform [backface-visibility:hidden]"
        >
          <div
            className={`border border-white/[0.18] ${UI_RADII.modal} px-3 py-2 shadow-[0_20px_50px_rgba(0,0,0,0.8),inset_0_1px_1px_rgba(255,255,255,0.25)] pointer-events-auto relative overflow-hidden [transform:translateZ(0)] [contain:layout_paint] ${
              isAndroidDevice
                ? 'bg-slate-900/95'
                : 'bg-slate-900/90 backdrop-blur-lg'
            }`}
          >
            {/* Specular Refraction Top Border */}
            <div className={SPECULAR_HIGHLIGHT} />

            <div className="grid grid-cols-3 gap-1 relative z-10">
              <motion.button
                type="button"
                whileHover={MOTION_PRESETS.iconHover}
                whileTap={MOTION_PRESETS.buttonTap}
                onClick={() => handleTabChange('workout')}
                className={`flex flex-col items-center justify-center min-h-[46px] py-1.5 ${UI_RADII.control} transition-all relative ${
                  currentTab === 'workout'
                    ? 'text-sky-300 font-extrabold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {currentTab === 'workout' && (
                  <motion.div
                    layoutId="activeDockTab"
                    className={`absolute inset-0 bg-white/10 ${UI_RADII.card} border border-white/15`}
                    transition={MOTION_PRESETS.snappySpring}
                  />
                )}
                <Dumbbell className="w-5 h-5 mb-0.5 relative z-10" />
                <span className="text-[10px] tracking-tight relative z-10">Scheda</span>
              </motion.button>

              <motion.button
                type="button"
                whileHover={MOTION_PRESETS.iconHover}
                whileTap={MOTION_PRESETS.buttonTap}
                onClick={() => handleTabChange('rankings')}
                className={`flex flex-col items-center justify-center min-h-[46px] py-1.5 ${UI_RADII.control} transition-all relative ${
                  currentTab === 'rankings'
                    ? 'text-sky-300 font-extrabold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {currentTab === 'rankings' && (
                  <motion.div
                    layoutId="activeDockTab"
                    className={`absolute inset-0 bg-white/10 ${UI_RADII.card} border border-white/15`}
                    transition={MOTION_PRESETS.snappySpring}
                  />
                )}
                <Trophy className="w-5 h-5 mb-0.5 relative z-10" />
                <span className="text-[10px] tracking-tight relative z-10">Ranking</span>
              </motion.button>

              <motion.button
                type="button"
                whileHover={MOTION_PRESETS.iconHover}
                whileTap={MOTION_PRESETS.buttonTap}
                onClick={() => handleTabChange('progression')}
                className={`flex flex-col items-center justify-center min-h-[46px] py-1.5 ${UI_RADII.control} transition-all relative ${
                  currentTab === 'progression'
                    ? 'text-sky-300 font-extrabold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {currentTab === 'progression' && (
                  <motion.div
                    layoutId="activeDockTab"
                    className={`absolute inset-0 bg-white/10 ${UI_RADII.card} border border-white/15`}
                    transition={MOTION_PRESETS.snappySpring}
                  />
                )}
                <TrendingUp className="w-5 h-5 mb-0.5 relative z-10" />
                <span className="text-[10px] tracking-tight relative z-10">Grafici</span>
              </motion.button>
            </div>
          </div>
        </nav>

        {/* Feature 4: Floating FAB Pill: Vai alla serie attuale */}
        <AnimatePresence>
          {currentTab === 'workout' && firstIncompleteExercise && isCurrentExerciseOutOfView && (
            <motion.div
              style={{
                bottom: 'calc(5.5rem + var(--app-safe-bottom, 0px))',
              }}
              className="fixed left-0 right-0 z-30 pointer-events-none flex justify-center px-4"
            >
              <motion.button
                type="button"
                initial={{ opacity: 0, y: 20, scale: 0.9 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 20, scale: 0.9 }}
                transition={MOTION_PRESETS.modalSpring}
                whileHover={MOTION_PRESETS.iconHover}
                whileTap={MOTION_PRESETS.buttonTap}
                onClick={handleScrollToCurrentExercise}
                className={`pointer-events-auto flex items-center gap-2 px-4 py-2 ${UI_RADII.pill} border border-white/[0.18] shadow-[0_20px_50px_rgba(0,0,0,0.8),inset_0_1px_1px_rgba(255,255,255,0.25)] text-sky-300 font-extrabold text-xs cursor-pointer relative overflow-hidden ${
                  isAndroidDevice
                    ? 'bg-slate-900/95'
                    : 'bg-slate-900/90 backdrop-blur-lg'
                }`}
              >
                <div className={SPECULAR_HIGHLIGHT} />
                <Target className="w-4 h-4 text-sky-400 relative z-10" />
                <span className="relative z-10 text-[11px] tracking-tight">Vai alla serie attuale</span>
              </motion.button>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Toast Notification for critical actions */}
      <Toast message={toastMessage} />

      {/* Floating / Active Rest Timer Modal (minimized floating pill sopra il dock, resettabile alla chiusura) */}
      <RestTimerModal
        isOpen={timerState.isOpen}
        initialSeconds={timerState.seconds}
        exerciseName={timerState.exerciseName}
        onClose={handleCloseTimer}
      />

      {/* OCR Camera Routine Scanner Modal */}
      <OcrModal
        isOpen={ocrModalOpen}
        onClose={() => setOcrModalOpen(false)}
        onImportExercises={handleImportOcrExercises}
      />

      {/* Manual Search & Add Exercise Modal with custom exercise creator and superset linker */}
      <AddExerciseModal
        isOpen={addExerciseModalOpen}
        onClose={() => {
          setAddExerciseModalOpen(false);
          setSupersetSourceExercise(null);
        }}
        onAddExercise={handleAddManualExercise}
        profile={profile}
        supersetSourceExercise={supersetSourceExercise}
        currentDayExercises={activeDay ? activeDay.exercises : []}
        onLinkExistingExercise={handleLinkExistingExercises}
      />

      {/* Profile & Onboarding Settings Modal */}
      <OnboardingModal
        isOpen={onboardingModalOpen}
        onClose={() => setOnboardingModalOpen(false)}
        profile={profile}
        onSaveProfile={handleUpdateProfile}
      />

      {/* Deload Strategy & Configuration Modal */}
      <DeloadModal
        isOpen={deloadModalOpen}
        isDeloadActive={routine.isDeloadWeek}
        activeDeloadType={routine.deloadType || 'mixed'}
        onSelectDeload={handleSelectDeload}
        onDisableDeload={handleDisableDeload}
        onClose={() => setDeloadModalOpen(false)}
      />
    </div>
  );
}
