import React, { useState, useEffect } from 'react';
import { UserProfile, VolumeMetric } from '../types';
import {
  User,
  Trophy,
  Dumbbell,
  Check,
  X,
  ChevronLeft,
  ChevronRight,
  Info,
  Sprout,
  Zap,
  TrendingUp,
  Flame,
  Activity,
} from 'lucide-react';
import { motion, AnimatePresence, useDragControls } from 'motion/react';
import { NumericInput } from './NumericInput';
import { UI_RADII, MOTION_PRESETS, SPECULAR_HIGHLIGHT } from '../utils/uiPresets';
import { useScrollLock } from '../hooks/useScrollLock';
import { PortalModal } from './PortalModal';

interface OnboardingModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: UserProfile;
  onSaveProfile: (profile: UserProfile) => void;
}

type SettingsTab = 'profile' | 'rank' | 'training';

const SETTINGS_TABS: { id: SettingsTab; label: string; icon: React.ReactNode }[] = [
  { id: 'profile', label: 'Profilo', icon: <User className="w-3.5 h-3.5" /> },
  { id: 'rank', label: 'Rank', icon: <Trophy className="w-3.5 h-3.5" /> },
  { id: 'training', label: 'Allenamento', icon: <Dumbbell className="w-3.5 h-3.5" /> },
];

const EXPERIENCE_LEVELS = [
  { id: 'beginner', label: 'Base', subtitle: '< 1 anno', icon: <Sprout className="w-4 h-4" /> },
  { id: 'intermediate', label: 'Intermedio', subtitle: '1–3 anni', icon: <Zap className="w-4 h-4" /> },
  { id: 'advanced', label: 'Avanzato', subtitle: '3+ anni', icon: <Trophy className="w-4 h-4" /> },
];

const GOALS = [
  { id: 'hypertrophy', label: 'Ipertrofia', subtitle: 'Massa muscolare', icon: <TrendingUp className="w-5 h-5" /> },
  { id: 'strength', label: 'Forza', subtitle: 'Powerlifting', icon: <Dumbbell className="w-5 h-5" /> },
  { id: 'fat_loss', label: 'Definizione', subtitle: 'Ricomposizione', icon: <Flame className="w-5 h-5" /> },
  { id: 'endurance', label: 'Resistenza', subtitle: 'Condizionamento', icon: <Activity className="w-5 h-5" /> },
];

export const OnboardingModal: React.FC<OnboardingModalProps> = ({
  isOpen,
  onClose,
  profile,
  onSaveProfile,
}) => {
  useScrollLock(isOpen);
  const dragControls = useDragControls();

  const [activeTab, setActiveTab] = useState<SettingsTab>('profile');
  const [name, setName] = useState(profile.name);
  const [bodyWeight, setBodyWeight] = useState(profile.bodyWeightKg || 75);
  const [heightCm, setHeightCm] = useState(profile.heightCm || 175);
  const [unit, setUnit] = useState<'kg' | 'lb'>(profile.unit);
  const [experience, setExperience] = useState(profile.experienceLevel);
  const [rankingMode, setRankingMode] = useState(profile.rankingMode);
  const [volumeMetric, setVolumeMetric] = useState<VolumeMetric>(profile.volumeMetric || 'tonnage');
  const [goal, setGoal] = useState(profile.goal);
  const [weightNotice, setWeightNotice] = useState<string | null>(null);
  const [heightNotice, setHeightNotice] = useState<string | null>(null);

  // Pattern 1: Reset e sincronizzazione dello stato della modale con il profilo reale quando viene aperta o chiusa
  useEffect(() => {
    if (isOpen) {
      setName(profile.name);
      setBodyWeight(profile.bodyWeightKg || 75);
      setHeightCm(profile.heightCm || 175);
      setUnit(profile.unit);
      setExperience(profile.experienceLevel);
      setRankingMode(profile.rankingMode);
      setVolumeMetric(profile.volumeMetric || 'tonnage');
      setGoal(profile.goal);
      setActiveTab('profile');
      setWeightNotice(null);
      setHeightNotice(null);
    }
  }, [isOpen, profile]);

  // Validazione peso su blur: se < 5 reimposta a 50
  const handleWeightBlur = () => {
    setBodyWeight((current) => {
      if (current < 5) {
        setWeightNotice('Valore < 5: impostato automaticamente al valore base di 50');
        setTimeout(() => setWeightNotice(null), 3500);
        return 50;
      }
      return current;
    });
  };

  // Validazione altezza su blur: se < 100 cm reimposta a 170
  const handleHeightBlur = () => {
    setHeightCm((current) => {
      if (current < 100) {
        setHeightNotice('Valore < 100 cm: impostato automaticamente a 170');
        setTimeout(() => setHeightNotice(null), 3500);
        return 170;
      }
      return current;
    });
  };

  const handleSubmit = () => {
    let finalWeight = Number(bodyWeight) || 75;
    if (finalWeight < 5) finalWeight = 50;
    let finalHeight = Number(heightCm) || 170;
    if (finalHeight < 100) finalHeight = 170;

    onSaveProfile({
      name: name.trim(),
      bodyWeightKg: finalWeight,
      heightCm: finalHeight,
      unit,
      experienceLevel: experience,
      rankingMode,
      goal,
      volumeMetric,
    });
    onClose();
  };

  // Calcoli contestuali per riassunto
  const validHeight = heightCm >= 100 ? heightCm : 175;
  const validWeight = bodyWeight >= 5 ? bodyWeight : 75;
  const bmiEstimate = (validWeight / Math.pow(validHeight / 100, 2)).toFixed(1);
  const allometricRatio = Math.pow(validWeight / 75, 0.67).toFixed(2);

  return (
    <PortalModal>
      <AnimatePresence>
        {isOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 pt-safe pb-safe">
          {/* Backdrop glass con animazione di uscita */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.22, ease: 'easeOut' }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-md"
          />

          <motion.div
            drag="y"
            dragControls={dragControls}
            dragListener={false}
            dragConstraints={{ top: 0, bottom: 0 }}
            dragElastic={0.5}
            dragMomentum={false}
            onDragEnd={(_, info) => {
              if (info.offset.y > 120 || info.velocity.y > 500) {
                onClose();
              }
            }}
            initial={{ scale: 0.92, opacity: 0, y: 15 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.92, opacity: 0, y: 15 }}
            transition={MOTION_PRESETS.modalSpring}
            className={`bg-slate-900/90 border border-white/[0.18] ${UI_RADII.modal} w-full max-w-md shadow-[0_25px_60px_rgba(0,0,0,0.85),inset_0_1px_2px_rgba(255,255,255,0.3)] backdrop-blur-3xl overflow-hidden relative max-h-[92dvh] flex flex-col z-10`}
          >
            {/* Specular Refraction Top Border */}
            <div className={SPECULAR_HIGHLIGHT} />

        {/* HEADER FISSO */}
        <div
          onPointerDown={(e) => dragControls.start(e)}
          className="p-4 sm:p-5 px-4 sm:px-6 border-b border-white/10 flex items-center justify-between relative z-10 shrink-0 cursor-grab active:cursor-grabbing"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-sky-500/20 to-blue-500/30 text-sky-300 border border-sky-400/40 flex items-center justify-center shadow-md">
              <User className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white tracking-tight">
                Profilo & Impostazioni
              </h3>
              <p className="text-xs text-slate-400">
                Parametri personali e configurazione dell'app
              </p>
            </div>
          </div>
          <motion.button
            type="button"
            whileTap={{ scale: 0.85 }}
            onClick={onClose}
            className="p-2 rounded-full text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </motion.button>
        </div>

        {/* PROGRESS DOTS */}
        <div className="flex items-center justify-center gap-1.5 py-2 shrink-0">
          {SETTINGS_TABS.map((tab) => (
            <motion.div
              key={tab.id}
              animate={{
                width: activeTab === tab.id ? 20 : 6,
                backgroundColor: activeTab === tab.id ? '#38bdf8' : 'rgba(255,255,255,0.2)',
              }}
              transition={{ duration: 0.2 }}
              className="h-1.5 rounded-full cursor-pointer"
              onClick={() => setActiveTab(tab.id)}
            />
          ))}
        </div>

        {/* TAB BAR FISSA */}
        <div className="px-4 sm:px-6 pb-3 border-b border-white/10 shrink-0">
          <div className="flex gap-1 bg-black/30 p-1 rounded-2xl border border-white/10">
            {SETTINGS_TABS.map((tab) => (
              <motion.button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id)}
                whileTap={MOTION_PRESETS.buttonTap}
                className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-[11px] font-bold transition-all cursor-pointer ${
                  activeTab === tab.id
                    ? 'bg-gradient-to-r from-sky-500 to-blue-600 text-white shadow-md shadow-sky-500/30'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {tab.icon}
                <span>{tab.label}</span>
              </motion.button>
            ))}
          </div>
        </div>

        {/* CONTENUTO SCROLLABILE CON ANIMATEPRESENCE */}
        <div className="flex-1 overflow-y-auto no-scrollbar">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, x: 16 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -16 }}
              transition={MOTION_PRESETS.snappySpring}
              className="p-4 sm:p-6 space-y-4"
            >
              {/* TAB 1: PROFILO */}
              {activeTab === 'profile' && (
                <div className="space-y-4">
                  {/* Nome Atleta */}
                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1">Nome Atleta</label>
                    <input
                      type="text"
                      dir="ltr"
                      placeholder="Inserisci il tuo nome..."
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full bg-black/40 border border-white/15 rounded-2xl px-3.5 py-2.5 text-sm text-white font-bold text-left focus:outline-none focus:border-sky-400 focus:ring-2 focus:ring-sky-400/30 focus:bg-black/60 backdrop-blur-md placeholder:text-slate-500 transition-colors"
                    />
                  </div>

                  {/* Peso e Altezza */}
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-bold text-slate-300 block mb-1">
                        Peso ({unit})
                      </label>
                      <div className="relative">
                        <NumericInput
                          step="0.5"
                          min={0}
                          max={300}
                          allowDecimals
                          fallbackValue={75}
                          value={bodyWeight}
                          onChange={setBodyWeight}
                          onBlur={handleWeightBlur}
                          className="w-full bg-black/40 border border-white/15 rounded-2xl px-3.5 py-2.5 text-sm text-white font-black text-center focus:outline-none focus:border-sky-400 focus:ring-2 focus:ring-sky-400/30 focus:bg-black/60 backdrop-blur-md hover:border-sky-400/50 transition-colors"
                        />
                      </div>
                      {weightNotice && (
                        <p className="text-[10px] text-amber-300 font-bold mt-1 leading-tight animate-pulse">
                          {weightNotice}
                        </p>
                      )}
                    </div>

                    <div>
                      <label className="text-xs font-bold text-slate-300 block mb-1">
                        Altezza (cm)
                      </label>
                      <div className="relative">
                        <NumericInput
                          step={1}
                          min={0}
                          max={250}
                          fallbackValue={175}
                          value={heightCm}
                          onChange={setHeightCm}
                          onBlur={handleHeightBlur}
                          className="w-full bg-black/40 border border-white/15 rounded-2xl px-3.5 py-2.5 text-sm text-white font-black text-center focus:outline-none focus:border-sky-400 focus:ring-2 focus:ring-sky-400/30 focus:bg-black/60 backdrop-blur-md hover:border-sky-400/50 transition-colors"
                        />
                      </div>
                      {heightNotice && (
                        <p className="text-[10px] text-amber-300 font-bold mt-1 leading-tight animate-pulse">
                          {heightNotice}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Unità di misura */}
                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1">
                      Unità di Misura Carichi
                    </label>
                    <div className="grid grid-cols-2 gap-1 bg-black/40 p-1 rounded-2xl border border-white/15 backdrop-blur-md">
                      <button
                        type="button"
                        onClick={() => setUnit('kg')}
                        className={`py-2 rounded-xl text-xs font-extrabold transition-all cursor-pointer ${
                          unit === 'kg'
                            ? 'bg-gradient-to-r from-sky-500 to-blue-600 text-white shadow-md shadow-sky-500/30'
                            : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        Chilogrammi (KG)
                      </button>
                      <button
                        type="button"
                        onClick={() => setUnit('lb')}
                        className={`py-2 rounded-xl text-xs font-extrabold transition-all cursor-pointer ${
                          unit === 'lb'
                            ? 'bg-gradient-to-r from-sky-500 to-blue-600 text-white shadow-md shadow-sky-500/30'
                            : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        Libbre (LB)
                      </button>
                    </div>
                  </div>

                  {/* Riga riassuntiva contestuale */}
                  <div className="flex items-center gap-2 px-3 py-2 bg-sky-500/10 rounded-xl border border-sky-400/20 text-[11px] text-sky-300">
                    <Info className="w-3.5 h-3.5 shrink-0" />
                    <span>
                      BMI stimato: <strong>{bmiEstimate}</strong> • Allometrico:{' '}
                      <strong>{allometricRatio}x</strong>
                    </span>
                  </div>
                </div>
              )}

              {/* TAB 2: RANK & FORZA */}
              {activeTab === 'rank' && (
                <div className="space-y-4">
                  {/* Calcolo Livelli di Forza (Rank) */}
                  <div className={`bg-white/[0.04] p-4 ${UI_RADII.card} border border-white/10 backdrop-blur-md`}>
                    <label className="text-xs font-extrabold text-white block mb-1.5">
                      Calcolo Livelli di Forza (Rank)
                    </label>
                    <div className="grid grid-cols-2 gap-1 bg-black/40 p-1 rounded-2xl border border-white/10 mb-3">
                      <button
                        type="button"
                        onClick={() => setRankingMode('relative')}
                        className={`py-2 rounded-xl text-[11px] font-bold transition-all cursor-pointer ${
                          rankingMode === 'relative'
                            ? 'bg-gradient-to-r from-sky-500 to-blue-600 text-white shadow-md shadow-sky-500/30'
                            : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        Relativa (Peso & Altezza)
                      </button>
                      <button
                        type="button"
                        onClick={() => setRankingMode('absolute')}
                        className={`py-2 rounded-xl text-[11px] font-bold transition-all cursor-pointer ${
                          rankingMode === 'absolute'
                            ? 'bg-gradient-to-r from-sky-500 to-blue-600 text-white shadow-md shadow-sky-500/30'
                            : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        Assoluta (Kg Puri)
                      </button>
                    </div>

                    {/* Descrizione espansa contestuale */}
                    <AnimatePresence mode="wait">
                      <motion.div
                        key={rankingMode}
                        initial={{ opacity: 0, y: 6 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -6 }}
                        transition={{ duration: 0.18 }}
                        className={`p-3 ${UI_RADII.control} border text-[11px] leading-relaxed mb-2 ${
                          rankingMode === 'relative'
                            ? 'bg-sky-500/10 border-sky-400/30 text-sky-200'
                            : 'bg-slate-700/30 border-white/10 text-slate-300'
                        }`}
                      >
                        {rankingMode === 'relative' ? (
                          <>
                            <strong className="block mb-1 text-sky-300">Forza Relativa (Consigliata)</strong>
                            I tuoi benchmark tengono conto del peso{' '}
                            <strong>
                              {bodyWeight} {unit}
                            </strong>{' '}
                            con normalizzazione allometrica (esponente 0.67). Confronto equo tra atleti di taglie diverse.
                          </>
                        ) : (
                          <>
                            <strong className="block mb-1 text-slate-200">Forza Assoluta</strong>
                            Benchmark su carichi fissi standard. Ideale per Powerlifting e confronti raw. Non normalizzato per peso o altezza corporea.
                          </>
                        )}
                      </motion.div>
                    </AnimatePresence>

                    <p className="text-[10px] text-sky-400/90 font-medium block">
                      Si applica a tutta l'app. Cambiala solo da qui.
                    </p>
                  </div>

                  {/* Livello Esperienza — Card Visive */}
                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-2">
                      Livello Esperienza
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {EXPERIENCE_LEVELS.map((lvl) => (
                        <motion.button
                          key={lvl.id}
                          type="button"
                          whileTap={MOTION_PRESETS.buttonTap}
                          onClick={() => setExperience(lvl.id as any)}
                          className={`py-3 px-2 ${UI_RADII.card} border transition-all text-center flex flex-col items-center gap-1.5 cursor-pointer ${
                            experience === lvl.id
                              ? 'bg-sky-500/20 border-sky-400/60 shadow-md shadow-sky-500/20'
                              : 'bg-white/[0.03] border-white/10 hover:bg-white/[0.06]'
                          }`}
                        >
                          <span className={experience === lvl.id ? 'text-sky-300' : 'text-slate-500'}>
                            {lvl.icon}
                          </span>
                          <span
                            className={`text-[11px] font-extrabold ${
                              experience === lvl.id ? 'text-sky-200' : 'text-slate-300'
                            }`}
                          >
                            {lvl.label}
                          </span>
                          <span className="text-[9px] text-slate-500 font-medium">{lvl.subtitle}</span>
                        </motion.button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: ALLENAMENTO */}
              {activeTab === 'training' && (
                <div className="space-y-4">
                  {/* Obiettivo Primario — Card Visive 2x2 */}
                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-2">
                      Obiettivo Primario
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      {GOALS.map((g) => (
                        <motion.button
                          key={g.id}
                          type="button"
                          whileTap={MOTION_PRESETS.buttonTap}
                          onClick={() => setGoal(g.id as any)}
                          className={`py-3 px-3 ${UI_RADII.card} border transition-all text-left flex items-center gap-3 cursor-pointer ${
                            goal === g.id
                              ? 'bg-sky-500/20 border-sky-400/60 shadow-md shadow-sky-500/20'
                              : 'bg-white/[0.03] border-white/10 hover:bg-white/[0.06]'
                          }`}
                        >
                          <div className={`shrink-0 ${goal === g.id ? 'text-sky-400' : 'text-slate-500'}`}>
                            {g.icon}
                          </div>
                          <div>
                            <span
                              className={`text-xs font-extrabold block ${
                                goal === g.id ? 'text-sky-200' : 'text-white'
                              }`}
                            >
                              {g.label}
                            </span>
                            <span className="text-[10px] text-slate-500">{g.subtitle}</span>
                          </div>
                        </motion.button>
                      ))}
                    </div>
                  </div>

                  {/* Metrica Volume */}
                  <div className={`bg-white/[0.04] p-4 ${UI_RADII.card} border border-white/10 backdrop-blur-md`}>
                    <label className="text-xs font-extrabold text-white block mb-1.5">
                      Metrica Volume di Allenamento
                    </label>
                    <div className="grid grid-cols-2 gap-1 bg-black/40 p-1 rounded-2xl border border-white/10 mb-2">
                      <button
                        type="button"
                        onClick={() => setVolumeMetric('tonnage')}
                        className={`py-2 rounded-xl text-[11px] font-bold transition-all cursor-pointer ${
                          volumeMetric === 'tonnage'
                            ? 'bg-gradient-to-r from-sky-500 to-blue-600 text-white shadow-md shadow-sky-500/30'
                            : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        Tonnellaggio
                      </button>
                      <button
                        type="button"
                        onClick={() => setVolumeMetric('effective_sets')}
                        className={`py-2 rounded-xl text-[11px] font-bold transition-all cursor-pointer ${
                          volumeMetric === 'effective_sets'
                            ? 'bg-gradient-to-r from-sky-500 to-blue-600 text-white shadow-md shadow-sky-500/30'
                            : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        Serie Efficaci
                      </button>
                    </div>

                    {/* Descrizione espansa contestuale */}
                    <AnimatePresence mode="wait">
                      <motion.div
                        key={volumeMetric}
                        initial={{ opacity: 0, y: 6 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.18 }}
                        className={`p-3 ${UI_RADII.control} border text-[11px] leading-relaxed mb-2 ${
                          volumeMetric === 'tonnage'
                            ? 'bg-amber-500/10 border-amber-400/30 text-amber-200'
                            : 'bg-purple-500/10 border-purple-400/30 text-purple-200'
                        }`}
                      >
                        {volumeMetric === 'tonnage' ? (
                          <>
                            <strong className="block mb-0.5 text-amber-300">Tonnellaggio</strong>
                            Kg totali sollevati (carico effettivo × reps × serie di lavoro). Ottimo per monitorare il carico assoluto nel tempo.
                          </>
                        ) : (
                          <>
                            <strong className="block mb-0.5 text-purple-300">Serie Efficaci</strong>
                            Conta solo le serie da lavoro (esclude il riscaldamento). Standard scientifico per il volume ipertrofico.
                          </>
                        )}
                      </motion.div>
                    </AnimatePresence>

                    <p className="text-[10px] text-sky-400/90 font-medium block">
                      Si applica a tutta l'app. Cambiala solo da qui.
                    </p>
                  </div>
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* FOOTER FISSO — NAVIGAZIONE TRA TAB + SALVA */}
        <div className="p-4 sm:px-6 border-t border-white/10 flex items-center justify-between gap-3 shrink-0">
          {/* Pulsante Indietro — visibile solo se non al primo tab */}
          {activeTab !== 'profile' ? (
            <motion.button
              type="button"
              whileTap={MOTION_PRESETS.buttonTap}
              onClick={() => setActiveTab(activeTab === 'training' ? 'rank' : 'profile')}
              className={`flex items-center gap-1.5 px-4 py-2.5 ${UI_RADII.control} bg-white/[0.06] border border-white/10 text-slate-300 text-xs font-bold hover:text-white transition-all cursor-pointer`}
            >
              <ChevronLeft className="w-3.5 h-3.5" />
              Indietro
            </motion.button>
          ) : (
            <div />
          )}

          {/* Pulsante Avanti / Salva */}
          {activeTab !== 'training' ? (
            <motion.button
              type="button"
              whileTap={MOTION_PRESETS.buttonTap}
              onClick={() => setActiveTab(activeTab === 'profile' ? 'rank' : 'training')}
              className={`flex items-center gap-1.5 px-5 py-2.5 ${UI_RADII.control} bg-sky-500/20 border border-sky-400/40 text-sky-200 text-xs font-bold hover:bg-sky-500/30 transition-all cursor-pointer`}
            >
              Avanti
              <ChevronRight className="w-3.5 h-3.5" />
            </motion.button>
          ) : (
            <motion.button
              type="button"
              whileHover={MOTION_PRESETS.buttonHover}
              whileTap={MOTION_PRESETS.buttonTap}
              onClick={handleSubmit}
              className={`flex items-center gap-2 px-5 py-2.5 ${UI_RADII.control} bg-gradient-to-r from-sky-500 to-blue-600 text-white text-xs font-extrabold shadow-lg shadow-sky-500/30 border border-sky-400/40 hover:from-sky-400 hover:to-blue-500 transition-all cursor-pointer`}
            >
              <Check className="w-3.5 h-3.5" />
              Salva Impostazioni
            </motion.button>
          )}
        </div>
      </motion.div>
    </div>
      )}
    </AnimatePresence>
    </PortalModal>
  );
};
