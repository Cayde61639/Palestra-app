import React, { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';

interface PortalModalProps {
  children: React.ReactNode;
  container?: Element | DocumentFragment;
}

/**
 * PortalModal
 * Renderizza i modali a schermo intero direttamente in `document.body`
 * isolandoli completamente da eventuali `transform` CSS dei contenitori genitori
 * (come la filmstrip animata w-[300%] tra le schede principali).
 */
export const PortalModal: React.FC<PortalModalProps> = ({ children, container }) => {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    return () => setMounted(false);
  }, []);

  if (!mounted || typeof document === 'undefined') {
    return null;
  }

  return createPortal(children, container || document.body);
};

export default PortalModal;
