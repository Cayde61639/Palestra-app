import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCheck } from 'lucide-react';
import { UI_RADII } from '../utils/uiPresets';

interface ToastProps {
  message: string | null;
}

export const Toast: React.FC<ToastProps> = ({ message }) => (
  <AnimatePresence>
    {message && (
      <motion.div
        initial={{ opacity: 0, y: 30, scale: 0.9 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 20, scale: 0.95 }}
        transition={{ type: 'spring', damping: 22, stiffness: 320 }}
        className={`fixed bottom-28 left-1/2 -translate-x-1/2 z-[999] flex items-center gap-2 px-4 py-2.5 ${UI_RADII.pill} bg-emerald-500/90 backdrop-blur-md text-white text-xs font-extrabold shadow-xl border border-emerald-400/40 pointer-events-none [transform:translateZ(0)] will-change-transform`}
      >
        <CheckCheck className="w-3.5 h-3.5" />
        {message}
      </motion.div>
    )}
  </AnimatePresence>
);
