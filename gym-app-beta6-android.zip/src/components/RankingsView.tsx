import React, { useState, useEffect, useRef, useMemo } from 'react';
import { MuscleZone, RankLevel, UserProfile, WorkoutRoutine } from '../types';
import {
  calculateMuscleRanks,
  RANK_METADATA,
  triggerRankCelebration,
  getExerciseRankProgress,
  ExerciseRankProgress,
} from '../utils/ranking';
import { MUSCLE_LABELS, resolveBackSubcategory } from '../data/exerciseDataset';
import { getEffectiveWeight } from '../utils/volume';
import { HumanBodyMap } from './HumanBodyMap';
import {
  Sparkles,
  Trophy,
  Award,
  Info,
  TrendingUp,
  Target,
  ChevronRight,
  ChevronUp,
  ChevronDown,
  Flame,
  CheckCircle2,
  X,
  Dumbbell,
  Shield,
  AlertTriangle,
  Zap,
  Lightbulb,
  Clock,
} from 'lucide-react';
import { motion, AnimatePresence, useDragControls } from 'motion/react';
import { UI_RADII, MOTION_PRESETS, SPECULAR_HIGHLIGHT } from '../utils/uiPresets';
import { PortalModal } from './PortalModal';

interface RankingsViewProps {
  routine: WorkoutRoutine;
  profile: UserProfile;
  onUpdateProfile: (p: UserProfile) => void;
  currentTab?: string;
}

type MuscleCategoryFilter = 'all' | 'chest' | 'back' | 'shoulders' | 'arms' | 'legs' | 'abs';
type RankFilter = 'all' | RankLevel;
type RankingTab = 'panoramica' | 'obiettivi' | 'focus';

interface CategoryTab {
  id: MuscleCategoryFilter;
  label: string;
  zones: MuscleZone[];
}

const CATEGORY_TABS: CategoryTab[] = [
  { id: 'all', label: 'Tutti', zones: [] },
  { id: 'chest', label: 'Petto', zones: ['chest'] },
  { id: 'back', label: 'Dorso', zones: ['lats', 'upper_back'] },
  { id: 'shoulders', label: 'Spalle', zones: ['shoulders'] },
  { id: 'arms', label: 'Braccia', zones: ['biceps', 'triceps'] },
  { id: 'legs', label: 'Gambe', zones: ['quads', 'hamstrings', 'glutes', 'calves'] },
  { id: 'abs', label: 'Core', zones: ['abs'] },
];

const RANK_FILTER_TABS: { id: RankFilter; label: string }[] = [
  { id: 'all', label: 'Tutti' },
  { id: 'bronze', label: 'Bronzo' },
  { id: 'silver', label: 'Argento' },
  { id: 'gold', label: 'Oro' },
  { id: 'platinum', label: 'Platino' },
  { id: 'diamond', label: 'Diamante' },
];

const RANK_NUMERIC: Record<RankLevel, number> = {
  bronze: 1,
  silver: 2,
  gold: 3,
  platinum: 4,
  diamond: 5,
};

interface MilestoneEntry {
  zone: MuscleZone;
  rank: RankLevel;
  date: string;
}

export const RankingsView = React.memo<RankingsViewProps>(({
  routine,
  profile,
  currentTab,
}) => {
  const dragControls = useDragControls();
  const [selectedMuscle, setSelectedMuscle] = useState<MuscleZone | null>('chest');
  const [activeTab, setActiveTab] = useState<RankingTab>('panoramica');
  const [activeCategory, setActiveCategory] = useState<MuscleCategoryFilter>('all');
  const [activeRankFilter, setActiveRankFilter] = useState<RankFilter>('all');
  const [showMilestones, setShowMilestones] = useState(false);
  const [detailZone, setDetailZone] = useState<MuscleZone | null>(null);
  const [fasceLevelVisible, setFasceLevelVisible] = useState(true);

  // Chiude automaticamente la bottom sheet se l'utente cambia scheda principale
  useEffect(() => {
    setDetailZone(null);
  }, [currentTab]);

  // Metodologia di calcolo collassabile con persistenza in localStorage (nascosta di default)
  const [metodoVisible, setMetodoVisible] = useState<boolean>(() => {
    try {
      return localStorage.getItem('gym_app_metodologia_visible_v1') === 'true';
    } catch {
      return false;
    }
  });

  const toggleMetodo = () => {
    const next = !metodoVisible;
    setMetodoVisible(next);
    try {
      localStorage.setItem('gym_app_metodologia_visible_v1', String(next));
    } catch {}
  };

  // Calcolo centralizzato dei rank leggendo direttamente dal profilo utente (singola fonte di verità)
  const muscleRanks = useMemo(() => calculateMuscleRanks(routine, profile), [routine, profile]);

  // Calcola il rank complessivo più frequente
  const overallRank: RankLevel = useMemo(() => {
    const ranksList = Object.values(muscleRanks);
    const diamondCount = ranksList.filter((r) => r === 'diamond').length;
    const platinumCount = ranksList.filter((r) => r === 'platinum').length;
    const goldCount = ranksList.filter((r) => r === 'gold').length;

    return diamondCount >= 3
      ? 'diamond'
      : platinumCount >= 3
      ? 'platinum'
      : goldCount >= 3
      ? 'gold'
      : 'silver';
  }, [muscleRanks]);

  const overallMeta = RANK_METADATA[overallRank];

  // Gestione Milestones e Cronologia traguardi in localStorage
  const [milestones, setMilestones] = useState<MilestoneEntry[]>(() => {
    try {
      const saved = localStorage.getItem('gym_app_rank_milestones_v1');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Celebrazione automatica al rank-up e aggiornamento cronologia traguardi
  const hasCelebratedRef = useRef(false);

  useEffect(() => {
    const now = new Date();
    const dateFormatted = now.toLocaleDateString('it-IT', { day: 'numeric', month: 'short' });
    let updatedMilestones = [...milestones];
    let hasNewMilestone = false;

    // Controlla ogni distretto per salvare eventuali nuovi record
    (Object.keys(muscleRanks) as MuscleZone[]).forEach((zone) => {
      const currentRank = muscleRanks[zone];
      if (currentRank && currentRank !== 'bronze') {
        const existing = updatedMilestones.find((m) => m.zone === zone);
        if (!existing || RANK_NUMERIC[currentRank] > RANK_NUMERIC[existing.rank]) {
          updatedMilestones = [
            { zone, rank: currentRank, date: dateFormatted },
            ...updatedMilestones.filter((m) => m.zone !== zone),
          ];
          hasNewMilestone = true;
        }
      }
    });

    if (hasNewMilestone) {
      setMilestones(updatedMilestones);
      try {
        localStorage.setItem('gym_app_rank_milestones_v1', JSON.stringify(updatedMilestones));
      } catch {}
    }

    if (hasCelebratedRef.current) return;
    const lastSavedRank = (localStorage.getItem('gym_app_last_celebrated_rank_v1') as RankLevel) || 'bronze';
    const currentScore = RANK_NUMERIC[overallRank];
    const lastScore = RANK_NUMERIC[lastSavedRank] || 1;

    if (currentScore > lastScore && currentScore >= 3) {
      const timer = setTimeout(() => {
        triggerRankCelebration(overallRank, overallMeta.label);
        localStorage.setItem('gym_app_last_celebrated_rank_v1', overallRank);
        hasCelebratedRef.current = true;
      }, 500);
      return () => clearTimeout(timer);
    } else {
      localStorage.setItem('gym_app_last_celebrated_rank_v1', overallRank);
    }
  }, [muscleRanks, overallRank]);

  // Calcolo delle progressioni e del distretto più vicino al traguardo successivo
  const exerciseProgressions = useMemo(() => {
    const list: (ExerciseRankProgress & { targetMuscle: MuscleZone })[] = [];

    routine.days.forEach((day) => {
      day.exercises.forEach((ex) => {
        if (ex.category === 'warmup') return;

        let maxWeight = 0;
        let repsAtMax = 8;
        ex.sets.forEach((s) => {
          if (s.setType === 'warmup') return;
          const eff = getEffectiveWeight(ex, s.weight, profile);
          if (eff !== null && eff > maxWeight) {
            maxWeight = eff;
            repsAtMax = s.reps || 8;
          }
        });

        if (maxWeight > 0) {
          const prog = getExerciseRankProgress(
            ex.name,
            maxWeight,
            repsAtMax,
            profile,
            ex.weightMode,
            ex
          );
          const resolvedTarget =
            ex.targetMuscle === 'back'
              ? resolveBackSubcategory(ex.name, (ex as any).italianName)
              : (ex.targetMuscle as MuscleZone);

          list.push({ ...prog, targetMuscle: resolvedTarget });
        }
      });
    });

    return list;
  }, [routine, profile]);

  // Opportunità di progressione più vicina (miglior candidato da spronare)
  const closestProgressionOpportunity = useMemo(() => {
    const eligible = exerciseProgressions.filter(
      (p) => p.nextRank !== null && p.kgRemaining > 0 && p.progressPercent >= 30
    );
    if (eligible.length === 0) return exerciseProgressions[0] || null;

    // Ordina per percentuale completata decrescente e kg mancanti crescenti
    return eligible.sort((a, b) => {
      if (b.progressPercent !== a.progressPercent) {
        return b.progressPercent - a.progressPercent;
      }
      return a.kgRemaining - b.kgRemaining;
    })[0];
  }, [exerciseProgressions]);

  // Calcola il muscolo più indietro rispetto alla media dell'utente (Focus Consigliato)
  const laggingMuscle = useMemo(() => {
    const activeZones: MuscleZone[] = [
      'chest',
      'lats',
      'upper_back',
      'shoulders',
      'biceps',
      'triceps',
      'quads',
      'hamstrings',
      'glutes',
      'calves',
      'abs',
    ];

    const scores = activeZones.map((z) => ({
      zone: z,
      score: RANK_NUMERIC[muscleRanks[z] || 'bronze'],
      rank: muscleRanks[z] || 'bronze',
    }));

    const avgScore = scores.reduce((acc, s) => acc + s.score, 0) / scores.length;
    // Cerca il gruppo con punteggio più basso rispetto alla media
    const belowAvg = scores.filter((s) => s.score < avgScore).sort((a, b) => a.score - b.score);
    return belowAvg.length > 0 ? belowAvg[0] : null;
  }, [muscleRanks]);

  // Top 3 esercizi più vicini al rank-up (podio opportunità)
  const top3Opportunities = useMemo(() => {
    return exerciseProgressions
      .filter((p) => p.nextRank !== null && p.kgRemaining > 0)
      .sort((a, b) => {
        // Prima per percentuale completata (desc), poi per kg mancanti (asc)
        if (b.progressPercent !== a.progressPercent) return b.progressPercent - a.progressPercent;
        return a.kgRemaining - b.kgRemaining;
      })
      .slice(0, 3);
  }, [exerciseProgressions]);

  // Calcola cosa manca per il prossimo livello globale
  const roadToNextGlobal = useMemo(() => {
    const rankOrder: RankLevel[] = ['bronze', 'silver', 'gold', 'platinum', 'diamond'];
    const currentIdx = rankOrder.indexOf(overallRank);
    if (currentIdx >= rankOrder.length - 1) return null; // Già diamante

    const nextGlobalRank = rankOrder[currentIdx + 1];
    // Per salire di livello globale servono almeno 3 distretti al livello target
    const allZones: MuscleZone[] = ['chest','lats','upper_back','shoulders','biceps','triceps','quads','hamstrings','glutes','calves','abs'];
    
    const zonesAtOrAbove = allZones.filter((z) => RANK_NUMERIC[muscleRanks[z] || 'bronze'] >= RANK_NUMERIC[nextGlobalRank]);
    const zonesBelow = allZones
      .filter((z) => RANK_NUMERIC[muscleRanks[z] || 'bronze'] < RANK_NUMERIC[nextGlobalRank])
      .map((z) => ({
        zone: z,
        currentRank: (muscleRanks[z] || 'bronze') as RankLevel,
        score: RANK_NUMERIC[muscleRanks[z] || 'bronze'],
      }))
      .sort((a, b) => b.score - a.score); // I più vicini prima

    const needed = Math.max(0, 3 - zonesAtOrAbove.length);

    return {
      nextRank: nextGlobalRank,
      achieved: zonesAtOrAbove.length,
      needed,
      candidates: zonesBelow.slice(0, Math.max(needed, 2)), // Mostra almeno i 2 candidati migliori
    };
  }, [overallRank, muscleRanks]);

  // Analisi squilibri tra gruppi muscolari antagonisti
  const imbalances = useMemo(() => {
    const pairs: { name: string; zoneA: MuscleZone; labelA: string; zoneB: MuscleZone; labelB: string }[] = [
      { name: 'Spinta / Tirata', zoneA: 'chest', labelA: 'Petto', zoneB: 'lats', labelB: 'Dorsali' },
      { name: 'Quadricipiti / Femorali', zoneA: 'quads', labelA: 'Quadricipiti', zoneB: 'hamstrings', labelB: 'Femorali' },
      { name: 'Bicipiti / Tricipiti', zoneA: 'biceps', labelA: 'Bicipiti', zoneB: 'triceps', labelB: 'Tricipiti' },
    ];

    return pairs
      .map((pair) => {
        const scoreA = RANK_NUMERIC[muscleRanks[pair.zoneA] || 'bronze'];
        const scoreB = RANK_NUMERIC[muscleRanks[pair.zoneB] || 'bronze'];
        const diff = Math.abs(scoreA - scoreB);
        const weaker = scoreA < scoreB ? { zone: pair.zoneA, label: pair.labelA, rank: (muscleRanks[pair.zoneA] || 'bronze') as RankLevel } : { zone: pair.zoneB, label: pair.labelB, rank: (muscleRanks[pair.zoneB] || 'bronze') as RankLevel };
        const stronger = scoreA >= scoreB ? { zone: pair.zoneA, label: pair.labelA, rank: (muscleRanks[pair.zoneA] || 'bronze') as RankLevel } : { zone: pair.zoneB, label: pair.labelB, rank: (muscleRanks[pair.zoneB] || 'bronze') as RankLevel };
        return { ...pair, diff, weaker, stronger };
      })
      .filter((p) => p.diff >= 2); // Solo squilibri significativi (2+ livelli di differenza)
  }, [muscleRanks]);

  // Genera un suggerimento pratico basato sul muscolo carente
  const trainingSuggestion = useMemo(() => {
    if (!laggingMuscle) return null;

    const zone = laggingMuscle.zone;
    const rank = laggingMuscle.rank as RankLevel;
    const label = MUSCLE_LABELS[zone];

    // Trova gli esercizi dell'utente che colpiscono questa zona
    const zoneExercises = exerciseProgressions.filter((p) => p.targetMuscle === zone);
    const bestExercise = zoneExercises.sort((a, b) => b.current1RM - a.current1RM)[0];

    if (!bestExercise) return { zone, label, rank, text: `Aggiungi un esercizio per ${label} alla tua scheda per iniziare a progredire.`, exercise: null };

    const kgAway = bestExercise.kgRemaining;
    const nextRankLabel = bestExercise.nextRank ? RANK_METADATA[bestExercise.nextRank].label : null;

    if (kgAway <= 5) {
      return { zone, label, rank, text: `Sei a soli ${kgAway} ${profile.unit} dal livello ${nextRankLabel} su ${bestExercise.exerciseName}. Prova a ridurre le ripetizioni e aumentare il carico nella prossima sessione.`, exercise: bestExercise.exerciseName };
    }
    return { zone, label, rank, text: `${label} è il tuo distretto più debole. Concentrati su ${bestExercise.exerciseName} e prova ad aggiungere 1 serie extra o ad applicare una tecnica di intensità (drop set, rest-pause).`, exercise: bestExercise.exerciseName };
  }, [laggingMuscle, exerciseProgressions, profile.unit]);

  // Filtra le zone da visualizzare nella griglia in AND con activeRankFilter
  const displayedZones: MuscleZone[] = useMemo(() => {
    let zones: MuscleZone[] =
      activeCategory === 'all'
        ? [
            'chest',
            'lats',
            'upper_back',
            'shoulders',
            'biceps',
            'triceps',
            'quads',
            'hamstrings',
            'glutes',
            'calves',
            'abs',
          ]
        : (CATEGORY_TABS.find((t) => t.id === activeCategory)?.zones ?? []);

    if (activeRankFilter !== 'all') {
      zones = zones.filter((z) => (muscleRanks[z] || 'bronze') === activeRankFilter);
    }
    return zones;
  }, [activeCategory, activeRankFilter, muscleRanks]);

  return (
    <div className="space-y-4">
      {/* SEGMENTED CONTROL TABS */}
      <div className="flex bg-white/[0.05] border border-white/10 rounded-xl p-1 mb-2 relative">
        {([
          { id: 'panoramica', label: 'Panoramica' },
          { id: 'obiettivi', label: 'Obiettivi' },
          { id: 'focus', label: 'Focus' },
        ] as { id: RankingTab; label: string }[]).map((tab) => (
          <motion.button
            key={tab.id}
            type="button"
            whileHover={MOTION_PRESETS.iconHover}
            whileTap={MOTION_PRESETS.buttonTap}
            onClick={() => setActiveTab(tab.id)}
            className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer relative text-center ${
              activeTab === tab.id
                ? 'text-sky-300 font-extrabold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {activeTab === tab.id && (
              <motion.div
                layoutId="activeRankingSegmentTab"
                className={`absolute inset-0 bg-white/10 ${UI_RADII.control} border border-white/15 shadow-sm`}
                transition={MOTION_PRESETS.snappySpring}
              />
            )}
            <span className="relative z-10">{tab.label}</span>
          </motion.button>
        ))}
      </div>

      {/* CONTENUTO TAB ANIMATO CON AnimatePresence */}
      <AnimatePresence mode="wait">
        {/* TAB 1: PANORAMICA */}
        {activeTab === 'panoramica' && (
          <motion.div
            key="panoramica"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2 }}
            className="space-y-4"
          >
          {/* 1. BANNER LIVELLO GLOBALE (Compatto, non espandibile) */}
          <div
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 ${UI_RADII.card} bg-white/[0.05] border border-white/[0.12] backdrop-blur-2xl shadow-xl ${overallMeta.borderGlow}`}
          >
            <Trophy className="w-4 h-4 text-amber-300 shrink-0" />
            <span className="text-[11px] font-bold text-white/80 flex-1 text-left">
              Livello Globale
            </span>
            <span
              className="text-xs font-black px-2.5 py-0.5 rounded-full"
              style={{
                color: overallMeta.colorHex,
                backgroundColor: `${overallMeta.colorHex}25`,
                border: `1px solid ${overallMeta.colorHex}50`,
              }}
            >
              {overallMeta.label}
            </span>
          </div>

      {/* 2. MAPPA ANATOMICA INTERATTIVA (HumanBodyMap con effetto spotlight) */}
      <motion.div
        animate={{ scale: fasceLevelVisible ? 1 : 1.02 }}
        transition={{ duration: 0.2, ease: 'easeOut' }}
        className="relative"
      >
        <HumanBodyMap
          muscleRanks={muscleRanks}
          selectedMuscle={selectedMuscle}
          onSelectMuscle={(m) => {
            setSelectedMuscle(m);
            // Sincronizza categoria attiva se appropriato
            if (m === 'lats' || m === 'upper_back') setActiveCategory('back');
            else if (m === 'biceps' || m === 'triceps') setActiveCategory('arms');
            else if (['quads', 'hamstrings', 'glutes', 'calves'].includes(m)) setActiveCategory('legs');
            else if (m === 'abs') setActiveCategory('abs');
            else if (m === 'chest') setActiveCategory('chest');
            else if (m === 'shoulders') setActiveCategory('shoulders');
          }}
        />
      </motion.div>

      {/* 3. SEZIONE DETTAGLIO LIVELLI, FILTRI RANK E CATEGORIA */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <Award className="w-4 h-4 text-sky-400" />
            <h4 className="text-xs font-black text-white uppercase tracking-wider">
              Dettaglio Livelli per Muscolo
            </h4>
          </div>
        </div>

        {/* MODIFICA 6: FASCE DI LIVELLO COLLASSABILI CON SPOTLIGHT SUL CORPO */}
        <div className="space-y-1">
          {/* Header Fasce di Livello — sempre visibile */}
          <div className="flex items-center justify-between px-1">
            <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">
              Fasce di Livello
            </span>
            <div className="flex items-center gap-2">
              {activeRankFilter !== 'all' && (
                <button
                  type="button"
                  onClick={() => setActiveRankFilter('all')}
                  className="text-[10px] font-bold text-sky-400 hover:text-sky-300 cursor-pointer"
                >
                  (Azzera filtro)
                </button>
              )}
              <motion.button
                type="button"
                whileTap={MOTION_PRESETS.buttonTap}
                onClick={() => setFasceLevelVisible((v) => !v)}
                className="flex items-center gap-1 text-[10px] font-bold text-slate-500 hover:text-sky-300 transition-colors cursor-pointer"
              >
                <motion.span
                  animate={{ rotate: fasceLevelVisible ? 0 : 180 }}
                  transition={{ duration: 0.2 }}
                  className="inline-flex [transform:translateZ(0)] will-change-transform"
                >
                  <ChevronUp className="w-3.5 h-3.5" />
                </motion.span>
                <span>{fasceLevelVisible ? 'Nascondi' : 'Mostra'}</span>
              </motion.button>
            </div>
          </div>

          {/* Contenitore animato delle pill — OTTIMIZZATA ANDROID con scaleY */}
          <AnimatePresence initial={false}>
            {fasceLevelVisible && (
              <motion.div
                key="fasce-pills"
                initial={{ scaleY: 0.6, opacity: 0 }}
                animate={{ scaleY: 1, opacity: 1 }}
                exit={{ scaleY: 0.6, opacity: 0 }}
                transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
                style={{ transformOrigin: 'top center' }}
                className="[transform:translateZ(0)] will-change-transform [backface-visibility:hidden]"
              >
                <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1 pt-0.5 -mx-1 px-1">
                  {RANK_FILTER_TABS.map((tab) => {
                    const isActive = activeRankFilter === tab.id;
                    const isAll = tab.id === 'all';
                    const meta = !isAll ? RANK_METADATA[tab.id as RankLevel] : null;

                    return (
                      <button
                        key={tab.id}
                        type="button"
                        onClick={() => setActiveRankFilter(tab.id)}
                        className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all duration-200 border shrink-0 flex items-center gap-1.5 cursor-pointer ${
                          isActive
                            ? isAll
                              ? 'bg-sky-500/25 text-sky-300 border-sky-400/50 shadow-sm shadow-sky-500/20'
                              : ''
                            : 'bg-white/[0.04] text-slate-400 hover:text-white border-white/[0.08] hover:bg-white/[0.08]'
                        }`}
                        style={
                          isActive && !isAll && meta
                            ? {
                                backgroundColor: `${meta.colorHex}20`,
                                borderColor: `${meta.colorHex}70`,
                                color: meta.colorHex,
                                boxShadow: `0 0 10px ${meta.colorHex}30`,
                              }
                            : undefined
                        }
                      >
                        {!isAll && meta && (
                          <span
                            className="w-1.5 h-1.5 rounded-full shrink-0"
                            style={{ backgroundColor: meta.colorHex }}
                          />
                        )}
                        <span>{tab.label}</span>
                      </button>
                    );
                  })}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* MODIFICA 5: CHIP CATEGORIA (Resetta activeRankFilter a 'all' al cambio) */}
        <div className="space-y-1">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Gruppi Muscolari
          </span>
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1 pt-0.5 -mx-1 px-1">
            {CATEGORY_TABS.map((tab) => {
              const isActive = activeCategory === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => {
                    setActiveCategory(tab.id);
                    setActiveRankFilter('all'); // Reset contestuale del filtro rank
                  }}
                  className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all duration-200 border shrink-0 cursor-pointer ${
                    isActive
                      ? 'bg-sky-500/25 text-sky-300 border-sky-400/50 shadow-sm shadow-sky-500/20'
                      : 'bg-white/[0.04] text-slate-400 hover:text-white border-white/[0.08] hover:bg-white/[0.08]'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>


        {/* GRIGLIA MUSCOLI CON BORDI COLORATI, SENZA TESTO DEL RANK, PROGRESS BAR SEMPRE PRESENTE */}
        <div className="space-y-2.5">
          {/* STATO VUOTO QUANDO NESSUN MUSCOLO CORRISPONDE AL FILTRO */}
          {displayedZones.length === 0 && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className={`py-10 text-center bg-white/[0.05] border border-white/[0.12] backdrop-blur-2xl shadow-xl ${UI_RADII.card} relative overflow-hidden p-6`}
            >
              <Dumbbell className="w-8 h-8 text-sky-400/80 mx-auto mb-2" />
              <p className="text-sm font-bold text-white/80">
                Nessun muscolo a livello{' '}
                <span style={{ color: activeRankFilter !== 'all' ? RANK_METADATA[activeRankFilter].colorHex : '#38bdf8' }}>
                  {activeRankFilter !== 'all' ? RANK_METADATA[activeRankFilter].label : ''}
                </span>
              </p>
              <p className="text-[11px] text-slate-400 mt-1">
                Continua ad allenarti per sbloccare questo livello!
              </p>
              <button
                type="button"
                onClick={() => setActiveRankFilter('all')}
                className="mt-3 px-3.5 py-1.5 rounded-full text-xs font-bold bg-sky-500/20 text-sky-300 border border-sky-400/40 hover:bg-sky-500/30 transition-all cursor-pointer"
              >
                Mostra tutti i livelli
              </button>
            </motion.div>
          )}

          {/* Griglia unificata per tutti i muscoli ultra-compatta */}
          {displayedZones.length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {displayedZones.map((zone) => {
                const rank = muscleRanks[zone] || 'bronze';
                const meta = RANK_METADATA[rank];
                const isSelected = selectedMuscle === zone;
                const prog = exerciseProgressions.find((p) => p.targetMuscle === zone);

                return (
                  <motion.div
                    key={zone}
                    whileHover={MOTION_PRESETS.cardHover}
                    whileTap={MOTION_PRESETS.buttonTap}
                    onClick={() => {
                      setSelectedMuscle(zone);
                      setDetailZone(zone);
                    }}
                    className={`p-2 ${UI_RADII.control} border transition-all cursor-pointer backdrop-blur-2xl shadow-xl relative overflow-hidden ${
                      isSelected
                        ? 'ring-2 ring-sky-400 bg-white/[0.12] border-[#38bdf8]'
                        : 'bg-white/[0.05] border-white/[0.12] hover:bg-white/[0.08]'
                    }`}
                    style={{
                      borderColor: isSelected ? '#38bdf8' : `${meta.colorHex}60`,
                      boxShadow: isSelected
                        ? '0 0 0 2px #38bdf8'
                        : rank === 'platinum' || rank === 'diamond'
                        ? `0 0 10px ${meta.colorHex}30`
                        : undefined,
                    }}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-[10px] font-bold text-white truncate pr-1">
                        {MUSCLE_LABELS[zone]}
                      </span>
                      <div className="flex items-center gap-1 shrink-0">
                        {/* SE È IL MUSCOLO CARENTE, MOSTRA IL TARGET */}
                        {laggingMuscle && laggingMuscle.zone === zone && (
                          <Target className="w-3 h-3 text-rose-400" />
                        )}
                        {/* PALLINO DEL RANK */}
                        <span
                          className="w-2 h-2 rounded-full shrink-0"
                          style={{
                            backgroundColor: meta.colorHex,
                            boxShadow: `0 0 5px ${meta.colorHex}`,
                          }}
                        />
                      </div>
                    </div>

                    {/* Progress bar compatta - niente testi prolissi */}
                    {prog && prog.nextRank ? (
                      <div className="flex items-center gap-1.5">
                        <div className="flex-1 bg-white/10 h-1 rounded-full overflow-hidden">
                          <div
                            className="h-full rounded-full transition-all duration-500"
                            style={{
                              width: `${prog.progressPercent}%`,
                              backgroundColor: meta.colorHex,
                            }}
                          />
                        </div>
                        <span className="text-[8px] font-mono text-sky-300 font-bold shrink-0">
                          +{prog.kgRemaining}{profile.unit}
                        </span>
                      </div>
                    ) : (
                      <div className="w-full bg-white/10 h-1 rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full"
                          style={{
                            width: rank === 'diamond' ? '100%' : '0%',
                            backgroundColor: meta.colorHex,
                          }}
                        />
                      </div>
                    )}
                  </motion.div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* MODIFICA 7: METODOLOGIA DI CALCOLO — Collassabile con persistenza in localStorage */}
      <div className={`bg-white/[0.05] border border-white/[0.12] backdrop-blur-2xl shadow-xl ${UI_RADII.card} relative overflow-hidden`}>
        {/* Header sempre visibile — tap per espandere/collassare */}
        <motion.button
          type="button"
          whileTap={MOTION_PRESETS.buttonTap}
          onClick={toggleMetodo}
          className="w-full flex items-center justify-between gap-2 px-3.5 py-2.5 text-left cursor-pointer"
        >
          <div className="flex items-center gap-2">
            <Info className="w-3.5 h-3.5 text-sky-400 shrink-0" />
            <span className="text-[11px] font-bold text-slate-300">Metodologia di calcolo</span>
          </div>
          <motion.span
            animate={{ rotate: metodoVisible ? 180 : 0 }}
            transition={{ duration: 0.2 }}
            className="inline-flex shrink-0 [transform:translateZ(0)] will-change-transform"
          >
            <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
          </motion.span>
        </motion.button>

        {/* Contenuto collassabile — OTTIMIZZATO ANDROID con scaleY */}
        <AnimatePresence initial={false}>
          {metodoVisible && (
            <motion.div
              key="metodologia-content"
              initial={{ scaleY: 0, opacity: 0 }}
              animate={{ scaleY: 1, opacity: 1 }}
              exit={{ scaleY: 0, opacity: 0 }}
              transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
              style={{ transformOrigin: 'top center' }}
              className="[transform:translateZ(0)] will-change-transform [backface-visibility:hidden]"
            >
              <div className="px-3.5 pb-3.5 text-[11px] leading-relaxed text-slate-400 border-t border-white/[0.06]">
                <div className="pt-2.5 space-y-1">
                  <p>
                    Il massimale stimato (1RM formula Epley:{' '}
                    <span className="font-mono text-sky-300 font-bold">Peso × (1 + Reps/30)</span>
                    ) è normalizzato{' '}
                    {profile.rankingMode === 'relative'
                      ? 'rispetto al tuo peso corporeo secondo la legge allometrica (0.67).'
                      : 'direttamente sui carichi assoluti sollevati.'}
                  </p>
                  <p>
                    Il rank di ogni muscolo è calcolato con media pesata per l'importanza degli esercizi
                    (i compound multi-articolari hanno maggior peso). Per i rank Platino e Diamante è
                    richiesta una consistenza minima di serie valide.
                  </p>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
          </motion.div>
        )}

        {/* TAB 2: OBIETTIVI (Road to Next Rank, Opportunità di rank-up e Timeline traguardi) */}
        {activeTab === 'obiettivi' && (
          <motion.div
            key="obiettivi"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2 }}
            className="space-y-3"
          >
            {/* ═══════════════════════════════════════════════════════ */}
            {/* SEZIONE 1: ROAD TO NEXT GLOBAL RANK                    */}
            {/* ═══════════════════════════════════════════════════════ */}
            {roadToNextGlobal && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.05 }}
                className={`bg-white/[0.05] border border-white/[0.12] backdrop-blur-2xl shadow-xl ${UI_RADII.card} relative overflow-hidden p-3.5`}
              >
                <div className={SPECULAR_HIGHLIGHT} />
                <div className="relative z-10 space-y-2.5">
                  {/* Header */}
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-white/10 flex items-center justify-center border border-white/20">
                      <TrendingUp className="w-3.5 h-3.5 text-sky-400" />
                    </div>
                    <div>
                      <div className="text-[9px] uppercase tracking-widest text-white/50">Road to</div>
                      <span className="text-sm font-black" style={{ color: RANK_METADATA[roadToNextGlobal.nextRank].colorHex }}>
                        {RANK_METADATA[roadToNextGlobal.nextRank].label}
                      </span>
                    </div>
                  </div>

                  {/* Progress compatto */}
                  <div className="text-[11px] text-slate-300">
                    <span className="font-mono text-sky-300 font-bold">{roadToNextGlobal.achieved}/3</span> distretti al livello richiesto
                    {roadToNextGlobal.needed > 0 && (
                      <span> — te ne mancano <span className="font-bold text-white">{roadToNextGlobal.needed}</span></span>
                    )}
                  </div>

                  {/* Barra 3 segmenti */}
                  <div className="flex gap-1">
                    {[0, 1, 2].map((i) => (
                      <div key={i} className="flex-1 h-1.5 rounded-full overflow-hidden bg-white/10">
                        <div
                          className="h-full rounded-full transition-all duration-500"
                          style={{
                            width: i < roadToNextGlobal.achieved ? '100%' : '0%',
                            backgroundColor: RANK_METADATA[roadToNextGlobal.nextRank].colorHex,
                          }}
                        />
                      </div>
                    ))}
                  </div>

                  {/* Candidati più vicini */}
                  {roadToNextGlobal.candidates.length > 0 && (
                    <div className="space-y-1 pt-1 border-t border-white/[0.06]">
                      <span className="text-[9px] uppercase tracking-wider text-slate-500">Candidati migliori</span>
                      {roadToNextGlobal.candidates.map((c) => (
                        <button
                          key={c.zone}
                          type="button"
                          onClick={() => { setSelectedMuscle(c.zone); setDetailZone(c.zone); setActiveTab('panoramica'); }}
                          className="w-full flex items-center justify-between p-2 rounded-lg bg-white/[0.03] border border-white/[0.06] hover:bg-white/[0.08] cursor-pointer transition-colors text-xs"
                        >
                          <div className="flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: RANK_METADATA[c.currentRank].colorHex }} />
                            <span className="font-bold text-white">{MUSCLE_LABELS[c.zone]}</span>
                          </div>
                          <span className="text-[10px] font-bold" style={{ color: RANK_METADATA[c.currentRank].colorHex }}>
                            {RANK_METADATA[c.currentRank].label}
                          </span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </motion.div>
            )}

            {/* Se già Diamante globale, mostra messaggio di completamento */}
            {!roadToNextGlobal && (
              <div className={`bg-white/[0.05] border border-white/[0.12] backdrop-blur-2xl shadow-xl ${UI_RADII.card} p-3.5 text-center`}>
                <Sparkles className="w-5 h-5 text-sky-300 mx-auto mb-1" />
                <p className="text-xs font-bold text-white">Livello Globale Diamante raggiunto</p>
                <p className="text-[10px] text-slate-400 mt-0.5">Hai raggiunto il massimo. Continua a migliorare i singoli distretti.</p>
              </div>
            )}

            {/* ═══════════════════════════════════════════════════════ */}
            {/* SEZIONE 2: TOP 3 OPPORTUNITA' A BREVE TERMINE          */}
            {/* ═══════════════════════════════════════════════════════ */}
            {top3Opportunities.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className={`bg-white/[0.05] border border-white/[0.12] backdrop-blur-2xl shadow-xl ${UI_RADII.card} relative overflow-hidden p-3.5`}
              >
                {/* Header */}
                <div className="flex items-center gap-2 mb-2.5">
                  <Zap className="w-4 h-4 text-amber-400" />
                  <span className="text-[10px] font-black uppercase tracking-wider text-white">A un passo dal rank-up</span>
                </div>

                {/* Lista top 3 */}
                <div className="space-y-1.5">
                  {top3Opportunities.map((prog, i) => {
                    const nextMeta = prog.nextRank ? RANK_METADATA[prog.nextRank] : null;
                    return (
                      <div
                        key={i}
                        className="flex items-center gap-2.5 p-2 rounded-lg bg-white/[0.03] border border-white/[0.06]"
                      >
                        {/* Posizione podio */}
                        <span className={`text-[10px] font-black w-4 text-center shrink-0 ${
                          i === 0 ? 'text-amber-400' : i === 1 ? 'text-slate-300' : 'text-amber-700'
                        }`}>
                          {i + 1}
                        </span>

                        {/* Info esercizio */}
                        <div className="flex-1 min-w-0">
                          <span className="text-[11px] font-bold text-white truncate block">{prog.exerciseName}</span>
                          <div className="flex items-center gap-1.5 mt-0.5">
                            <div className="flex-1 bg-white/10 h-1 rounded-full overflow-hidden">
                              <div
                                className="h-full rounded-full"
                                style={{ width: `${prog.progressPercent}%`, backgroundColor: RANK_METADATA[prog.currentRank].colorHex }}
                              />
                            </div>
                            <span className="text-[8px] font-mono text-slate-400">{prog.progressPercent}%</span>
                          </div>
                        </div>

                        {/* Kg mancanti e prossimo rank */}
                        <div className="text-right shrink-0">
                          <span className="text-[10px] font-mono font-bold text-sky-300 block">+{prog.kgRemaining}{profile.unit}</span>
                          {nextMeta && (
                            <span className="text-[8px] font-bold" style={{ color: nextMeta.colorHex }}>
                              {nextMeta.label}
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </motion.div>
            )}

            {/* ═══════════════════════════════════════════════════════ */}
            {/* SEZIONE 3: BACHECA TRAGUARDI (TIMELINE)                */}
            {/* ═══════════════════════════════════════════════════════ */}
            {milestones.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.15 }}
                className={`bg-white/[0.05] border border-white/[0.12] backdrop-blur-2xl shadow-xl ${UI_RADII.card} relative overflow-hidden p-3.5`}
              >
                {/* Header */}
                <div className="flex items-center gap-2 mb-2.5">
                  <Clock className="w-4 h-4 text-emerald-400" />
                  <span className="text-[10px] font-black uppercase tracking-wider text-white">
                    Traguardi Raggiunti ({milestones.length})
                  </span>
                </div>

                {/* Timeline verticale */}
                <div className="relative pl-4 space-y-2">
                  {/* Linea verticale */}
                  <div className="absolute left-[5px] top-1 bottom-1 w-px bg-white/10" />

                  {milestones.slice(0, 8).map((m, idx) => {
                    const mMeta = RANK_METADATA[m.rank];
                    return (
                      <div key={idx} className="relative flex items-center gap-2.5">
                        {/* Pallino sulla linea */}
                        <span
                          className="absolute left-[-13px] w-2.5 h-2.5 rounded-full border-2 border-slate-900 shrink-0"
                          style={{ backgroundColor: mMeta.colorHex, boxShadow: `0 0 6px ${mMeta.colorHex}` }}
                        />
                        {/* Contenuto */}
                        <div className="flex items-center justify-between flex-1 py-1">
                          <div className="flex items-center gap-1.5">
                            <span className="text-[11px] font-bold text-white">{MUSCLE_LABELS[m.zone]}</span>
                            <span
                              className="text-[9px] font-black px-1.5 py-0.5 rounded-full"
                              style={{ color: mMeta.colorHex, backgroundColor: `${mMeta.colorHex}20`, border: `1px solid ${mMeta.colorHex}40` }}
                            >
                              {mMeta.label}
                            </span>
                          </div>
                          <span className="text-[9px] text-slate-500 shrink-0">{m.date}</span>
                        </div>
                      </div>
                    );
                  })}

                  {milestones.length > 8 && (
                    <p className="text-[9px] text-slate-500 pl-1">+{milestones.length - 8} traguardi precedenti</p>
                  )}
                </div>
              </motion.div>
            )}

            {/* Stato vuoto se non ci sono dati */}
            {top3Opportunities.length === 0 && milestones.length === 0 && (
              <div className={`bg-white/[0.05] border border-white/[0.12] backdrop-blur-2xl shadow-xl ${UI_RADII.card} p-8 text-center space-y-2`}>
                <Dumbbell className="w-8 h-8 text-slate-500 mx-auto" />
                <p className="text-sm font-bold text-white/60">Nessun obiettivo attivo</p>
                <p className="text-[11px] text-slate-500">Inizia ad allenarti per sbloccare obiettivi di progressione e traguardi.</p>
              </div>
            )}
          </motion.div>
        )}

        {/* TAB 3: FOCUS (Punti deboli, Squilibri antagonisti, Suggerimenti pratici) */}
        {activeTab === 'focus' && (
          <motion.div
            key="focus"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2 }}
            className="space-y-3"
          >
            {/* 1. FOCUS CONSIGLIATO (Distretto più debole) */}
            {laggingMuscle && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.05 }}
                className={`bg-white/[0.05] border border-white/[0.12] backdrop-blur-2xl shadow-xl ${UI_RADII.card} relative overflow-hidden p-3.5`}
              >
                <div className={SPECULAR_HIGHLIGHT} />
                <div className="flex items-center justify-between gap-3 relative z-10">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-8 h-8 rounded-xl bg-amber-500/15 border border-amber-400/30 flex items-center justify-center shrink-0 text-amber-400">
                      <Flame className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <span className="text-[10px] font-black uppercase tracking-wider text-amber-400 block">
                        Priorità Muscolare
                      </span>
                      <p className="text-xs font-bold text-white truncate">
                        {MUSCLE_LABELS[laggingMuscle.zone]}{' '}
                        <span style={{ color: RANK_METADATA[laggingMuscle.rank].colorHex }}>
                          ({RANK_METADATA[laggingMuscle.rank].label})
                        </span>
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedMuscle(laggingMuscle.zone);
                      setDetailZone(laggingMuscle.zone);
                      setActiveTab('panoramica');
                    }}
                    className="text-xs font-bold text-sky-400 hover:text-sky-300 shrink-0 px-2.5 py-1 rounded-lg bg-sky-500/15 border border-sky-400/30 flex items-center cursor-pointer transition-all hover:bg-sky-500/25"
                  >
                    Dettagli <ChevronRight className="w-3.5 h-3.5 ml-0.5" />
                  </button>
                </div>
              </motion.div>
            )}

            {/* 2. SUGGERIMENTO PRATICO DI ALLENAMENTO */}
            {trainingSuggestion && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className={`bg-white/[0.05] border border-white/[0.12] backdrop-blur-2xl shadow-xl ${UI_RADII.card} relative overflow-hidden p-3.5`}
              >
                <div className="flex items-start gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-amber-500/15 border border-amber-400/30 flex items-center justify-center shrink-0 mt-0.5">
                    <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
                  </div>
                  <div className="min-w-0 space-y-1">
                    <div className="text-[9px] uppercase tracking-widest text-amber-400 font-bold">Consiglio Pratico</div>
                    <p className="text-[11px] text-slate-300 leading-relaxed">{trainingSuggestion.text}</p>
                  </div>
                </div>
              </motion.div>
            )}

            {/* 3. ANALISI SQUILIBRI ANTAGONISTI */}
            {imbalances.length > 0 ? (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.15 }}
                className={`bg-white/[0.05] border border-white/[0.12] backdrop-blur-2xl shadow-xl ${UI_RADII.card} relative overflow-hidden p-3.5`}
              >
                <div className="flex items-center gap-2 mb-2.5">
                  <Shield className="w-4 h-4 text-rose-400" />
                  <span className="text-[10px] font-black uppercase tracking-wider text-white">Squilibri Rilevati</span>
                </div>

                <div className="space-y-2">
                  {imbalances.map((imb, i) => (
                    <div key={i} className="p-2.5 rounded-lg bg-rose-500/[0.06] border border-rose-500/20 space-y-1.5">
                      <div className="flex items-center gap-1.5">
                        <AlertTriangle className="w-3 h-3 text-rose-400 shrink-0" />
                        <span className="text-[10px] font-bold text-rose-300">{imb.name}</span>
                      </div>
                      <div className="flex items-center gap-2 text-[10px]">
                        <div className="flex-1 text-right">
                          <span className="font-bold text-white">{imb.stronger.label}</span>
                          <span className="ml-1 font-bold" style={{ color: RANK_METADATA[imb.stronger.rank].colorHex }}>
                            {RANK_METADATA[imb.stronger.rank].label}
                          </span>
                        </div>
                        <span className="text-slate-500 font-black shrink-0">vs</span>
                        <div className="flex-1">
                          <span className="font-bold text-white">{imb.weaker.label}</span>
                          <span className="ml-1 font-bold" style={{ color: RANK_METADATA[imb.weaker.rank].colorHex }}>
                            {RANK_METADATA[imb.weaker.rank].label}
                          </span>
                        </div>
                      </div>
                      <p className="text-[10px] text-slate-400 leading-snug">
                        Aumenta il volume o la frequenza su <strong className="text-white">{imb.weaker.label}</strong> per riequilibrare la forza tra catene opposte.
                      </p>
                    </div>
                  ))}
                </div>
              </motion.div>
            ) : (
              <div className={`bg-white/[0.05] border border-white/[0.12] backdrop-blur-2xl shadow-xl ${UI_RADII.card} p-3.5 flex items-center gap-2.5`}>
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <div className="min-w-0">
                  <span className="text-[11px] font-bold text-white block">Equilibrio Muscolare Ottimale</span>
                  <span className="text-[10px] text-slate-400">Nessuno squilibrio critico tra catene antagoniste rilevato.</span>
                </div>
              </div>
            )}

            {/* Stato vuoto generale se non ci sono dati */}
            {!laggingMuscle && imbalances.length === 0 && (
              <div className={`bg-white/[0.05] border border-white/[0.12] backdrop-blur-2xl shadow-xl ${UI_RADII.card} p-8 text-center space-y-2`}>
                <Dumbbell className="w-8 h-8 text-slate-500 mx-auto" />
                <p className="text-sm font-bold text-white/60">Nessun punto critico</p>
                <p className="text-[11px] text-slate-500">Registra più serie per ricevere analisi personalizzate sui punti deboli.</p>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* MODIFICA 4: BOTTOM SHEET DETTAGLIO GRUPPO MUSCOLARE AL CLICK */}
      <PortalModal>
        <AnimatePresence>
          {detailZone && (
            <>
              {/* Overlay scuro */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setDetailZone(null)}
                className="fixed inset-0 bg-black/60 z-50 backdrop-blur-sm cursor-pointer"
              />

              {/* Bottom Sheet */}
              <motion.div
                initial={{ y: '100%' }}
                animate={{ y: 0 }}
                exit={{ y: '100%' }}
                transition={MOTION_PRESETS.modalSpring}
                drag="y"
                dragListener={false}
                dragControls={dragControls}
                dragConstraints={{ top: 0 }}
                dragElastic={0.2}
                onDragEnd={(_, info) => {
                  if (info.offset.y > 100) setDetailZone(null);
                }}
                className={`fixed bottom-0 left-0 right-0 z-[55] ${UI_RADII.modal} rounded-b-none bg-slate-900/95 border-t border-white/10 backdrop-blur-3xl shadow-[0_-20px_60px_rgba(0,0,0,0.7)] pb-safe [transform:translateZ(0)] will-change-transform [backface-visibility:hidden]`}
                style={{ maxHeight: '75vh', overflowY: 'auto' }}
              >
              {/* Handle */}
              <div
                className="flex justify-center pt-3 pb-2 cursor-grab active:cursor-grabbing touch-none"
                onPointerDown={(e) => dragControls.start(e)}
              >
                <div className="w-10 h-1 rounded-full bg-white/20" />
              </div>

              {/* Contenuto dettaglio */}
              {(() => {
                const zone = detailZone;
                const rank = muscleRanks[zone] || 'bronze';
                const meta = RANK_METADATA[rank];
                const zoneExercises = exerciseProgressions.filter((p) => p.targetMuscle === zone);

                return (
                  <div className="px-4 pb-6 space-y-4">
                    {/* Header */}
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-lg font-black text-white">{MUSCLE_LABELS[zone]}</h3>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          <span
                            className="w-2.5 h-2.5 rounded-full"
                            style={{
                              backgroundColor: meta.colorHex,
                              boxShadow: `0 0 8px ${meta.colorHex}`,
                            }}
                          />
                          <span className="text-xs font-bold" style={{ color: meta.colorHex }}>
                            {meta.label}
                          </span>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => setDetailZone(null)}
                        className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center cursor-pointer transition-colors"
                      >
                        <X className="w-4 h-4 text-white/60" />
                      </button>
                    </div>

                    {/* Lista esercizi */}
                    {zoneExercises.length > 0 ? (
                      <div className="space-y-2">
                        {zoneExercises.map((prog, i) => (
                          <div
                            key={i}
                            className={`p-3 ${UI_RADII.control} bg-white/[0.04] border border-white/[0.08] space-y-1.5`}
                          >
                            <div className="flex items-center justify-between gap-2">
                              <span className="text-xs font-bold text-white truncate">
                                {prog.exerciseName}
                              </span>
                              <span
                                className="w-2 h-2 rounded-full shrink-0"
                                style={{
                                  backgroundColor: RANK_METADATA[prog.currentRank].colorHex,
                                  boxShadow: `0 0 5px ${RANK_METADATA[prog.currentRank].colorHex}`,
                                }}
                              />
                            </div>
                            <div className="text-[10px] text-slate-400">
                              1RM stimato:{' '}
                              <span className="font-mono text-sky-300 font-bold">
                                {prog.current1RM} {profile.unit}
                              </span>
                            </div>
                            {prog.nextRank && (
                              <>
                                <div className="flex items-center justify-between text-[10px] text-slate-400">
                                  <span>Prossimo rank ({RANK_METADATA[prog.nextRank].label})</span>
                                  <span className="font-mono text-sky-300 font-bold">
                                    +{prog.kgRemaining} {profile.unit}
                                  </span>
                                </div>
                                <div className="w-full bg-white/10 h-1.5 rounded-full overflow-hidden">
                                  <div
                                    className="h-full rounded-full transition-all duration-500"
                                    style={{
                                      width: `${prog.progressPercent}%`,
                                      backgroundColor: RANK_METADATA[prog.currentRank].colorHex,
                                    }}
                                  />
                                </div>
                              </>
                            )}
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-sm text-slate-400 text-center py-4">
                        Nessun esercizio registrato per questo muscolo.
                      </p>
                    )}
                  </div>
                );
              })()}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </PortalModal>
    </div>
  );
});
