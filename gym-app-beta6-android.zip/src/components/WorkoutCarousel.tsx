import React, { useState, useEffect } from 'react';
import { WorkoutDay } from '../types';
import { MUSCLE_LABELS } from '../data/exerciseDataset';
import { formatDayDuration } from '../utils/duration';
import {
  Pencil,
  Plus,
  Check,
  Dumbbell,
  Clock,
  Trash2,
  ChevronLeft,
  ChevronRight,
  CalendarDays,
  X,
  ChevronsDownUp,
  ChevronsUpDown,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { UI_RADII, MOTION_PRESETS, SPECULAR_HIGHLIGHT } from '../utils/uiPresets';

// Etichette giorni in italiano (0=Dom, 1=Lun, ..., 6=Sab)
const DAY_LABELS = ['D', 'L', 'M', 'M', 'G', 'V', 'S'];
const DAY_LABELS_FULL = ['Dom', 'Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab'];
// Ordine di visualizzazione: Lun → Dom (1,2,3,4,5,6,0)
const DAY_ORDER = [1, 2, 3, 4, 5, 6, 0];

interface WorkoutCarouselProps {
  days: WorkoutDay[];
  selectedDayId: string;
  onSelectDay: (dayId: string) => void;
  onUpdateDayName: (dayId: string, newName: string) => void;
  onUpdateDaySchedule: (dayId: string, scheduledDays: number[]) => void; // NUOVO
  onAddDay: () => void;
  onDeleteDay: (dayId: string) => void;
  onMoveDay: (fromIndex: number, toIndex: number) => void;
}

export const WorkoutCarousel = React.memo<WorkoutCarouselProps>(({
  days,
  selectedDayId,
  onSelectDay,
  onUpdateDayName,
  onUpdateDaySchedule,
  onAddDay,
  onDeleteDay,
  onMoveDay,
}) => {
  const [isCompact, setIsCompact] = useState<boolean>(() => {
    try {
      return localStorage.getItem('gym_app_carousel_compact_v1') === 'true';
    } catch {
      return false;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('gym_app_carousel_compact_v1', String(isCompact));
    } catch {}
  }, [isCompact]);

  const [editingDayId, setEditingDayId] = useState<string | null>(null);
  const [editNameValue, setEditNameValue] = useState<string>('');
  const [schedulingDayId, setSchedulingDayId] = useState<string | null>(null);

  const cardRefs = React.useRef<Record<string, HTMLDivElement | null>>({});
  const carouselTouchStartRef = React.useRef<{
    startX: number;
    startY: number;
    lastX: number;
    lastY: number;
    time: number;
  } | null>(null);

  // Auto-scroll per centrare la card del giorno selezionato al cambio di selectedDayId
  useEffect(() => {
    if (selectedDayId && cardRefs.current[selectedDayId]) {
      const el = cardRefs.current[selectedDayId];
      if (el) {
        el.scrollIntoView({
          behavior: 'smooth',
          block: 'nearest',
          inline: 'center',
        });
      }
    }
  }, [selectedDayId]);

  // Giorno della settimana attuale (0=Dom, 1=Lun, ...)
  const todayDow = new Date().getDay();

  const currentDayIndex = days.findIndex((d) => d.id === selectedDayId);
  const handlePrevDay = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (currentDayIndex > 0) {
      onSelectDay(days[currentDayIndex - 1].id);
    }
  };

  const handleNextDay = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (currentDayIndex < days.length - 1) {
      onSelectDay(days[currentDayIndex + 1].id);
    }
  };

  // Swipe orizzontale ad altissima reattività sulle card del carosello (flick + swipe normale)
  const handleCarouselTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      const touch = e.touches[0];
      carouselTouchStartRef.current = {
        startX: touch.clientX,
        startY: touch.clientY,
        lastX: touch.clientX,
        lastY: touch.clientY,
        time: Date.now(),
      };
    }
  };

  const handleCarouselTouchMove = (e: React.TouchEvent) => {
    if (!carouselTouchStartRef.current || e.touches.length !== 1) return;
    const touch = e.touches[0];
    carouselTouchStartRef.current.lastX = touch.clientX;
    carouselTouchStartRef.current.lastY = touch.clientY;
  };

  const processCarouselSwipe = (target: HTMLElement | null, e?: React.TouchEvent) => {
    if (!carouselTouchStartRef.current) return;
    const { startX, startY, lastX, lastY, time } = carouselTouchStartRef.current;
    carouselTouchStartRef.current = null;

    if (target && target.closest('input, textarea, button, [data-prevent-swipe]')) return;

    const deltaX = lastX - startX;
    const deltaY = lastY - startY;
    const deltaTime = Math.max(Date.now() - time, 1);
    const absX = Math.abs(deltaX);
    const absY = Math.abs(deltaY);
    const velocityX = absX / deltaTime;

    const isHorizontal = absX > absY * 0.75;
    const isQuickFlick = velocityX >= 0.20 && absX >= 20;
    const isStandardSwipe = absX >= 28 && deltaTime < 700;

    if (isHorizontal && (isQuickFlick || isStandardSwipe)) {
      if (e) e.stopPropagation();
      if (window.navigator?.vibrate) {
        try {
          window.navigator.vibrate(10);
        } catch {}
      }
      if (deltaX < 0 && currentDayIndex < days.length - 1) {
        onSelectDay(days[currentDayIndex + 1].id);
      } else if (deltaX > 0 && currentDayIndex > 0) {
        onSelectDay(days[currentDayIndex - 1].id);
      }
    }
  };

  const handleCarouselTouchEnd = (e: React.TouchEvent) => {
    processCarouselSwipe(e.target as HTMLElement | null, e);
  };

  const handleCarouselTouchCancel = (e: React.TouchEvent) => {
    processCarouselSwipe(e.target as HTMLElement | null, e);
  };

  const startEditing = (day: WorkoutDay, e: React.MouseEvent) => {
    e.stopPropagation();
    if (isCompact) setIsCompact(false);
    setEditingDayId(day.id);
    setEditNameValue(day.name);
  };

  const saveEdit = (dayId: string) => {
    onUpdateDayName(dayId, editNameValue.trim());
    setEditingDayId(null);
  };

  const toggleDayOfWeek = (day: WorkoutDay, dow: number, e: React.MouseEvent) => {
    e.stopPropagation();
    const current = day.scheduledDays ?? [];

    // Regola di esclusività: rimuove quel giorno dagli altri giorni prima di assegnarlo
    const newSchedule = current.includes(dow)
      ? current.filter((d) => d !== dow) // deseleziona
      : [...current, dow]; // aggiunge

    onUpdateDaySchedule(day.id, newSchedule);
  };

  return (
    <div className="w-full">
      {/* Header bar con label di sezione, frecce navigazione rapida e toggle compatto / espanso */}
      <div className="flex items-center justify-between mb-2 px-0.5">
        <div className="flex items-center gap-2">
          <p className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">
            I tuoi giorni
          </p>
          {days.length > 1 && (
            <div className="flex items-center gap-1 bg-white/[0.05] border border-white/10 rounded-full px-1.5 py-0.5 shadow-sm">
              <button
                type="button"
                onClick={handlePrevDay}
                disabled={currentDayIndex <= 0}
                className={`p-0.5 rounded-full transition-all ${
                  currentDayIndex <= 0
                    ? 'text-slate-600 cursor-not-allowed opacity-40'
                    : 'text-slate-300 hover:text-white hover:bg-white/10 active:scale-90'
                }`}
                title="Giorno precedente (o fai swipe a destra)"
              >
                <ChevronLeft className="w-3 h-3" />
              </button>
              <span className="text-[10px] font-bold text-slate-300 min-w-[28px] text-center select-none">
                {currentDayIndex >= 0 ? currentDayIndex + 1 : 1}/{days.length}
              </span>
              <button
                type="button"
                onClick={handleNextDay}
                disabled={currentDayIndex >= days.length - 1}
                className={`p-0.5 rounded-full transition-all ${
                  currentDayIndex >= days.length - 1
                    ? 'text-slate-600 cursor-not-allowed opacity-40'
                    : 'text-slate-300 hover:text-white hover:bg-white/10 active:scale-90'
                }`}
                title="Giorno successivo (o fai swipe a sinistra)"
              >
                <ChevronRight className="w-3 h-3" />
              </button>
            </div>
          )}
        </div>
        <motion.button
          type="button"
          onClick={() => setIsCompact((v) => !v)}
          whileHover={MOTION_PRESETS.iconHover}
          whileTap={MOTION_PRESETS.buttonTap}
          className={`p-1.5 ${UI_RADII.control} bg-white/[0.06] hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 transition-colors`}
          title={isCompact ? 'Espandi il carosello dei giorni' : 'Comprimi il carosello dei giorni'}
        >
          {isCompact ? <ChevronsUpDown className="w-3.5 h-3.5" /> : <ChevronsDownUp className="w-3.5 h-3.5" />}
        </motion.button>
      </div>

      {/* Scrollable Days Carousel con swipe touch integrato */}
      <div
        onTouchStart={handleCarouselTouchStart}
        onTouchMove={handleCarouselTouchMove}
        onTouchEnd={handleCarouselTouchEnd}
        onTouchCancel={handleCarouselTouchCancel}
        className="flex items-center gap-3 overflow-x-auto -mx-4 sm:-mx-5 px-4 sm:px-5 py-1 no-scrollbar scroll-smooth"
      >
        {days.map((day, idx) => {
          const isSelected = day.id === selectedDayId;
          const isEditing = editingDayId === day.id;
          const isScheduling = schedulingDayId === day.id;
          const scheduledDays = day.scheduledDays ?? [];

          // Guardia difensiva: se editing o scheduling sono attivi, mostra sempre la versione espansa
          const showExpanded = !isCompact || isEditing || isScheduling;

          // "Oggi" = il giorno corrente è tra i giorni programmati di questa card
          const isToday = scheduledDays.includes(todayDow);

          // Calcolo completamento serie per la progress bar
          const totalSets = day.exercises.reduce(
            (sum, ex) => sum + ex.sets.filter((s) => s.setType !== 'warmup').length, 0
          );
          const completedSets = day.exercises.reduce(
            (sum, ex) => sum + ex.sets.filter((s) => s.setType !== 'warmup' && s.completed).length, 0
          );
          const completionPct = totalSets > 0 ? Math.round((completedSets / totalSets) * 100) : 0;
          const isDayDone = totalSets > 0 && completedSets === totalSets;

          return (
            <motion.div
              key={day.id}
              ref={(el) => {
                cardRefs.current[day.id] = el;
              }}
              layout
              onClick={() => !isEditing && !isScheduling && onSelectDay(day.id)}
              whileHover={MOTION_PRESETS.cardHover}
              whileTap={MOTION_PRESETS.cardTap}
              transition={MOTION_PRESETS.gentleSpring}
              className={`flex-shrink-0 cursor-pointer select-none relative overflow-hidden backdrop-blur-xl outline-none focus:outline-none [transform:translateZ(0)] will-change-transform [backface-visibility:hidden] transition-colors ${
                showExpanded
                  ? `${UI_RADII.card} p-4 sm:p-5 w-[82vw] min-w-[230px] max-w-[300px] sm:w-[280px] sm:min-w-[280px]`
                  : `${UI_RADII.control} px-3 py-2 min-w-[120px] w-[130px] sm:w-[150px]`
              } ${
                isToday
                  ? 'bg-emerald-500/[0.07] border border-emerald-400/30 text-white shadow-sm'
                  : isSelected
                  ? 'bg-white/10 border border-sky-400/40 text-white shadow-sm'
                  : 'bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 text-slate-400 shadow-sm'
              }`}
            >
              {/* Refraction Sheen */}
              <div className={SPECULAR_HIGHLIGHT} />

              {!showExpanded ? (
                /* RAMO COMPATTO: solo badge + nome + barra progresso serie */
                <>
                  <div className="flex items-center gap-1.5 mb-1.5 relative z-10">
                    <span
                      className={`text-[8px] font-extrabold px-1.5 py-0.5 rounded-full uppercase shrink-0 ${
                        isToday
                          ? 'bg-emerald-500 text-white'
                          : isSelected
                          ? 'bg-sky-500 text-white'
                          : 'bg-white/10 text-slate-300'
                      }`}
                    >
                      {String.fromCharCode(65 + idx)}
                    </span>
                    {isToday && <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0" />}
                    <h3
                      className={`text-[11px] font-bold truncate flex-1 ${
                        isSelected || isToday ? 'text-white' : 'text-slate-300'
                      }`}
                      title={day.name}
                    >
                      {day.name}
                    </h3>
                  </div>

                  {totalSets > 0 && (
                    <div className="h-1 rounded-full bg-white/10 overflow-hidden relative z-10">
                      <motion.div
                        className="h-full rounded-full"
                        initial={{ width: 0 }}
                        animate={{ width: `${completionPct}%` }}
                        transition={{ duration: 0.5, ease: 'easeOut' }}
                        style={{
                          backgroundColor: isDayDone ? '#10b981' : isToday ? '#34d399' : '#38bdf8',
                        }}
                      />
                    </div>
                  )}
                </>
              ) : (
                /* RAMO ESPANSO: layout completo con azioni, programmazione, chip muscoli e metriche */
                <>
                  {/* Top Row: Badge Oggi / Day X + Shift + Edit/Delete + Calendario */}
                  <div className="flex items-center justify-between gap-1.5 mb-2.5 relative z-10">
                    <div className="flex items-center gap-1.5 min-w-0 flex-wrap">
                      {/* Badge "Day A" */}
                      <span
                        className={`text-[10px] font-extrabold px-2.5 py-0.5 rounded-full uppercase tracking-wider backdrop-blur-md transition-all shrink-0 ${
                          isToday
                            ? 'bg-emerald-500 text-white border border-emerald-400/40 shadow-sm'
                            : isSelected
                            ? 'bg-sky-500 text-white border border-sky-400/40 shadow-sm'
                            : 'bg-white/10 text-slate-300 border border-white/10'
                        }`}
                      >
                        Day {String.fromCharCode(65 + idx)}
                      </span>

                      {/* Badge "OGGI" — appare solo se il giorno è programmato per oggi */}
                      {isToday && (
                        <motion.span
                          initial={{ opacity: 0, scale: 0.7 }}
                          animate={{ opacity: 1, scale: 1 }}
                          className="text-[9px] font-extrabold px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/40 uppercase tracking-wider shrink-0"
                        >
                          Oggi
                        </motion.span>
                      )}

                      {/* Pulsanti Sposta Giorno */}
                      {days.length > 1 && !isEditing && !isScheduling && (
                        <div className="flex items-center bg-white/[0.06] rounded-full p-0.5 border border-white/10 backdrop-blur-sm shrink-0">
                          <button
                            type="button"
                            disabled={idx === 0}
                            onClick={(e) => { e.stopPropagation(); onMoveDay(idx, idx - 1); }}
                            className={`p-1 rounded-full transition-all ${idx === 0 ? 'opacity-20 cursor-not-allowed text-slate-500' : 'text-slate-300 hover:text-sky-300 hover:bg-white/15 active:scale-90'}`}
                            title="Sposta giorno a sinistra"
                          >
                            <ChevronLeft className="w-3 h-3" />
                          </button>
                          <button
                            type="button"
                            disabled={idx === days.length - 1}
                            onClick={(e) => { e.stopPropagation(); onMoveDay(idx, idx + 1); }}
                            className={`p-1 rounded-full transition-all ${idx === days.length - 1 ? 'opacity-20 cursor-not-allowed text-slate-500' : 'text-slate-300 hover:text-sky-300 hover:bg-white/15 active:scale-90'}`}
                            title="Sposta giorno a destra"
                          >
                            <ChevronRight className="w-3 h-3" />
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Azioni destra: Calendario + Matita + Cestino / Conferma */}
                    {isEditing ? (
                      <button
                        type="button"
                        onClick={(e) => { e.stopPropagation(); saveEdit(day.id); }}
                        className="p-1 rounded-full bg-emerald-500 text-white hover:bg-emerald-600 shadow-sm shrink-0"
                        title="Conferma modifica"
                      >
                        <Check className="w-3.5 h-3.5" />
                      </button>
                    ) : isScheduling ? (
                      <button
                        type="button"
                        onClick={(e) => { e.stopPropagation(); setSchedulingDayId(null); }}
                        className="p-1.5 rounded-full bg-white/10 text-slate-300 hover:bg-white/20 transition-colors shrink-0"
                        title="Chiudi pianificazione"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    ) : (
                      <div className="flex items-center gap-0.5 shrink-0">
                        {/* Tasto Calendario — apre il selettore giorni */}
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            if (isCompact) setIsCompact(false);
                            setSchedulingDayId(day.id);
                          }}
                          className={`p-1.5 rounded-full transition-colors ${
                            scheduledDays.length > 0
                              ? 'text-emerald-400 hover:bg-emerald-500/15'
                              : 'text-slate-400 hover:text-white hover:bg-white/10'
                          }`}
                          title="Pianifica giorni della settimana"
                        >
                          <CalendarDays className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={(e) => startEditing(day, e)}
                          className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
                          title="Rinomina giorno"
                        >
                          <Pencil className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={(e) => { e.stopPropagation(); onDeleteDay(day.id); }}
                          className="p-1.5 rounded-full text-slate-400 hover:text-rose-400 hover:bg-rose-500/20 transition-colors"
                          title="Elimina giorno"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}
                  </div>

                  {/* SELETTORE GIORNI SETTIMANA — appare solo quando isScheduling */}
                  <AnimatePresence>
                    {isScheduling && (
                      <motion.div
                        initial={{ opacity: 0, scaleY: 0 }}
                        animate={{ opacity: 1, scaleY: 1 }}
                        exit={{ opacity: 0, scaleY: 0 }}
                        transition={MOTION_PRESETS.snappySpring}
                        className="mb-2.5 relative z-10 origin-top"
                      >
                        <p className="text-[9px] uppercase tracking-widest text-slate-500 mb-1.5">
                          Giorni programmati
                        </p>
                        <div className="flex gap-1">
                          {DAY_ORDER.map((dow) => {
                            const isActive = scheduledDays.includes(dow);
                            const isUsedByOther = days.some(
                              (d) => d.id !== day.id && (d.scheduledDays ?? []).includes(dow)
                            );
                            return (
                              <button
                                key={dow}
                                type="button"
                                onClick={(e) => toggleDayOfWeek(day, dow, e)}
                                title={`${DAY_LABELS_FULL[dow]}${isUsedByOther ? ' (già assegnato)' : ''}`}
                                className={`flex-1 py-1.5 text-[10px] font-extrabold rounded-lg transition-all relative ${
                                  isActive
                                    ? 'bg-emerald-500 text-white border border-emerald-400/40 shadow-sm'
                                    : isUsedByOther
                                    ? 'bg-white/[0.03] text-slate-600 border border-white/5 cursor-default'
                                    : 'bg-white/[0.06] text-slate-400 border border-white/10 hover:bg-white/15 hover:text-white'
                                }`}
                              >
                                {DAY_LABELS[dow]}
                                {dow === todayDow && (
                                  <span className="absolute bottom-0.5 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-emerald-400" />
                                )}
                              </button>
                            );
                          })}
                        </div>
                        {scheduledDays.length > 0 && (
                          <p className="text-[9px] text-emerald-400 mt-1.5 font-bold">
                            {scheduledDays
                              .sort((a, b) => DAY_ORDER.indexOf(a) - DAY_ORDER.indexOf(b))
                              .map((d) => DAY_LABELS_FULL[d])
                              .join(', ')}
                          </p>
                        )}
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Day Title (Editable or Display) */}
                  <div className="mb-2.5 relative z-10">
                    {isEditing ? (
                      <input
                        type="text"
                        dir="ltr"
                        value={editNameValue}
                        placeholder="Nome auto se vuoto..."
                        onChange={(e) => setEditNameValue(e.target.value)}
                        onBlur={() => saveEdit(day.id)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') saveEdit(day.id);
                          if (e.key === 'Escape') setEditingDayId(null);
                        }}
                        ref={(el) => {
                          if (el && document.activeElement !== el) {
                            el.focus();
                            el.setSelectionRange(el.value.length, el.value.length);
                          }
                        }}
                        className="w-full bg-black/50 border border-sky-400 rounded-xl px-2 py-1 text-xs text-white font-bold focus:outline-none placeholder:text-slate-500"
                      />
                    ) : (
                      <h3
                        className={`text-sm font-bold transition-colors break-words line-clamp-2 leading-snug min-h-[2.5rem] flex items-center ${
                          isSelected || isToday ? 'text-white' : 'text-slate-200'
                        }`}
                        title={day.name}
                      >
                        {day.name}
                      </h3>
                    )}
                  </div>

                  {/* Muscle Chips & Stats */}
                  <div className="space-y-2 relative z-10">
                    {/* Focus muscles chips */}
                    <div className="flex flex-wrap gap-1">
                      {day.focusMuscles.map((muscle) => (
                        <span
                          key={muscle}
                          className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold backdrop-blur-md ${
                            isToday
                              ? 'bg-emerald-500/20 text-emerald-200 border border-emerald-400/30'
                              : isSelected
                              ? 'bg-sky-500/25 text-sky-200 border border-sky-400/40'
                              : 'bg-white/5 text-slate-400 border border-white/5'
                          }`}
                        >
                          {MUSCLE_LABELS[muscle]}
                        </span>
                      ))}
                    </div>

                    {/* Exercise Count & Time */}
                    <div className="flex items-center justify-between text-[11px] text-slate-300/90 px-3 py-1.5 rounded-2xl bg-white/[0.04] border border-white/[0.08] backdrop-blur-sm">
                      <div className="flex items-center gap-1.5">
                        <Dumbbell className="w-3 h-3 text-sky-400" />
                        <span>
                          {day.exercises.length} {day.exercises.length === 1 ? 'esercizio' : 'esercizi'}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Clock className="w-3 h-3 text-amber-400" />
                        <span>{formatDayDuration(day)}</span>
                      </div>
                    </div>

                    {/* Progress Bar Completamento Serie */}
                    {totalSets > 0 && (
                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-[10px]">
                          <span className={isDayDone ? 'text-emerald-400 font-extrabold' : 'text-slate-400'}>
                            {isDayDone ? 'Completato' : `${completedSets}/${totalSets} serie`}
                          </span>
                          <span className={`font-mono font-bold ${isDayDone ? 'text-emerald-400' : 'text-slate-400'}`}>
                            {completionPct}%
                          </span>
                        </div>
                        <div className="h-1 rounded-full bg-white/10 overflow-hidden">
                          <motion.div
                            className="h-full rounded-full"
                            initial={{ width: 0 }}
                            animate={{ width: `${completionPct}%` }}
                            transition={{ duration: 0.5, ease: 'easeOut' }}
                            style={{
                              backgroundColor: isDayDone ? '#10b981' : isToday ? '#34d399' : '#38bdf8',
                              boxShadow: isDayDone
                                ? '0 0 8px rgba(16,185,129,0.6)'
                                : '0 0 6px rgba(56,189,248,0.4)',
                            }}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                </>
              )}
            </motion.div>
          );
        })}

        {/* Add Day Button */}
        <motion.button
          key="add-day-button"
          layout
          type="button"
          onClick={onAddDay}
          whileHover={MOTION_PRESETS.cardHover}
          whileTap={MOTION_PRESETS.buttonTap}
          transition={MOTION_PRESETS.gentleSpring}
          className={`flex-shrink-0 flex items-center justify-center transition-all backdrop-blur-xl group outline-none focus:outline-none bg-white/[0.03] hover:bg-white/[0.08] border border-dashed border-white/20 text-slate-400 hover:text-white select-none ${
            isCompact
              ? `${UI_RADII.control} px-3 py-2 min-w-[100px] w-[110px] sm:w-[130px] flex-row gap-1.5 self-stretch`
              : `flex-col p-4 sm:p-5 ${UI_RADII.card} w-[38vw] min-w-[110px] sm:w-[140px] sm:min-w-[140px] self-stretch min-h-[148px]`
          }`}
        >
          {isCompact ? (
            <>
              <div className="w-5 h-5 rounded-lg bg-white/10 group-hover:bg-sky-500 text-slate-300 group-hover:text-white flex items-center justify-center transition-all shrink-0">
                <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
              </div>
              <span className="text-[11px] font-bold truncate">Aggiungi</span>
            </>
          ) : (
            <>
              <div className="w-10 h-10 rounded-2xl bg-white/10 group-hover:bg-sky-500 text-slate-300 group-hover:text-white flex items-center justify-center mb-2 transition-all shadow-sm">
                <Plus className="w-5 h-5 stroke-[2.5]" />
              </div>
              <span className="text-xs font-bold">Aggiungi Giorno</span>
            </>
          )}
        </motion.button>
      </div>
    </div>
  );
});
