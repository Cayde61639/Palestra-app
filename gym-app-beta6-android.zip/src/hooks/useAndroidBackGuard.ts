import { useEffect, useRef } from 'react';

/**
 * Intercetta l'evento 'popstate' (generato dal tasto Indietro fisico/gesture su Android)
 * per chiudere il modale attivo invece di uscire dall'applicazione o navigare indietro.
 */
export function useAndroidBackGuard(isAnyModalOpen: boolean, closeTopModal: () => void) {
  const guardPushedRef = useRef(false);

  useEffect(() => {
    if (isAnyModalOpen && !guardPushedRef.current) {
      history.pushState({ modalGuard: true }, '');
      guardPushedRef.current = true;
    }
    if (!isAnyModalOpen) {
      guardPushedRef.current = false;
    }
  }, [isAnyModalOpen]);

  useEffect(() => {
    const handlePopState = () => {
      if (isAnyModalOpen) {
        closeTopModal();
      }
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [isAnyModalOpen, closeTopModal]);
}
