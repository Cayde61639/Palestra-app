import { useEffect } from 'react';

/**
 * Blocca lo scorrimento del body quando un modale è aperto.
 * Previene lo spiacevole effetto in cui scorrendo sul modale si muove la pagina dietro.
 */
export const useScrollLock = (isLocked: boolean) => {
  useEffect(() => {
    if (!isLocked) return;

    // Salva lo stile originale
    const originalOverflow = document.body.style.overflow;
    
    // Blocca lo scroll
    document.body.style.overflow = 'hidden';

    return () => {
      // Ripristina alla chiusura
      document.body.style.overflow = originalOverflow;
    };
  }, [isLocked]);
};
