import { useState, useEffect, useRef, type RefObject } from 'react';

interface ScrollDirectionOptions {
  threshold?: number;
  topOffset?: number;
  scrollRef?: RefObject<HTMLElement | null>;
  watchKey?: string | number;
}

/**
 * Hook per rilevare la direzione di scorrimento della window o di un elemento scrollabile.
 * Restituisce true se l'utente sta scorrendo verso il basso oltre la soglia e oltre il topOffset,
 * false se sta scorrendo verso l'alto o si trova in cima alla pagina.
 */
export function useScrollDirection({
  threshold = 12,
  topOffset = 50,
  scrollRef,
  watchKey,
}: ScrollDirectionOptions = {}) {
  const [isHidden, setIsHidden] = useState(false);
  const lastScrollYRef = useRef(0);
  const tickingRef = useRef(false);

  useEffect(() => {
    const target: HTMLElement | Window = scrollRef?.current ?? window;
    const getScrollY = () =>
      target === window ? window.scrollY : (target as HTMLElement).scrollTop;

    lastScrollYRef.current = getScrollY();
    if (lastScrollYRef.current <= topOffset) {
      setIsHidden(false);
    }

    const handleScroll = () => {
      if (tickingRef.current) return;
      tickingRef.current = true;
      window.requestAnimationFrame(() => {
        const currentScrollY = getScrollY();
        if (currentScrollY <= topOffset) {
          setIsHidden(false);
        } else {
          const diff = currentScrollY - lastScrollYRef.current;
          if (Math.abs(diff) > threshold) {
            setIsHidden(diff > 0);
          }
        }
        lastScrollYRef.current = currentScrollY;
        tickingRef.current = false;
      });
    };

    target.addEventListener('scroll', handleScroll, { passive: true });
    return () => target.removeEventListener('scroll', handleScroll);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [threshold, topOffset, watchKey]);

  return isHidden;
}
