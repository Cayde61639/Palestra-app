import { ExerciseDefinition } from '../types';

/**
 * Esercizi completi al MULTIPOWER (Smith Machine) con PANCA INCLINATA / regolabile
 * suddivisi per ogni gruppo muscolare:
 * - Petto (Chest)
 * - Spalle & Deltoidi (Shoulders)
 * - Tricipiti (Triceps)
 * - Bicipiti (Biceps)
 * - Dorsali (Lats)
 * - Dorso Alto & Trapezi (Upper Back)
 * - Quadricipiti (Quads)
 * - Femorali (Hamstrings)
 * - Glutei (Glutes)
 * - Polpacci (Calves)
 * - Addome & Core (Abs)
 */
export const SMITH_INCLINE_EXERCISES: ExerciseDefinition[] = [
  // ==========================================
  // 1. PETTO (CHEST)
  // ==========================================
  {
    id: 'smith-incline-press-30',
    name: 'Smith Machine 30° Incline Bench Press',
    italianName: 'Panca Inclinata 30° al Multipower (Petto Alto)',
    muscle: 'chest',
    secondaryMuscles: ['triceps', 'shoulders'],
    defaultWeightMode: 'total',
    defaultRestSec: 120,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 35, silver: 55, gold: 80, platinum: 105, diamond: 130 },
    tips: [
      'Imposta lo schienale a 30° per massimizzare il reclutamento del fascio clavicolare minimizzando il carico sulle spalle anteriori.',
      'Posiziona la panca in modo che la barra scenda sfiorando la parte alta dello sterno, appena sotto le clavicole.',
      'Mantieni le scapole retratte e depresse per tutta la serie per spingere esclusivamente con il petto.',
    ],
    commonMistakes: [
      'Inclinare troppo la panca (oltre 45°) scaricando il lavoro quasi per intero sui deltoidi anteriori.',
      'Allontanare le scapole dallo schienale in chiusura perdendo la tensione sul gran pettorale.',
    ],
  },
  {
    id: 'smith-incline-press-45',
    name: 'Smith Machine 45° Incline Bench Press',
    italianName: 'Panca Inclinata 45° al Multipower (Fascio Clavicolare)',
    muscle: 'chest',
    secondaryMuscles: ['shoulders', 'triceps'],
    defaultWeightMode: 'total',
    defaultRestSec: 120,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 30, silver: 50, gold: 75, platinum: 95, diamond: 120 },
    tips: [
      'A 45° concentrati sulla massima contrazione della porzione alta del petto e sulla stabilità della colonna.',
      'Gomiti a circa 60° rispetto al tronco, senza allargarli eccessivamente all’esterno.',
    ],
    commonMistakes: [
      'Lasciare rimbalzare il bilanciere guidato sul petto per sfruttare l’inerzia.',
      'Inarcare eccessivamente la zona lombare per trasformare la spinta in una panca piana.',
    ],
  },
  {
    id: 'smith-incline-close-grip-press',
    name: 'Smith Machine Incline Close-Grip Press',
    italianName: 'Panca Inclinata Presa Stretta al Multipower',
    muscle: 'chest',
    secondaryMuscles: ['triceps', 'shoulders'],
    defaultWeightMode: 'total',
    defaultRestSec: 90,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 30, silver: 48, gold: 70, platinum: 90, diamond: 115 },
    tips: [
      'Panca inclinata a 30° con presa larga circa quanto la larghezza delle spalle.',
      'Scendi controllando la traiettoria con i gomiti vicini ai fianchi per stimolare petto centrale e tricipiti.',
    ],
    commonMistakes: [
      'Presa eccessivamente stretta (meno della larghezza delle spalle) che sovraccarica polsi e gomiti.',
      'Staccare la testa o le spalle dalla panca durante la risalita.',
    ],
  },
  {
    id: 'smith-incline-wide-stretch-press',
    name: 'Smith Machine Incline Wide Press',
    italianName: 'Panca Inclinata Presa Larga al Multipower (Massimo Stretch)',
    muscle: 'chest',
    secondaryMuscles: ['shoulders'],
    defaultWeightMode: 'total',
    defaultRestSec: 120,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 28, silver: 45, gold: 65, platinum: 85, diamond: 105 },
    tips: [
      'Panca a 30° con presa ampia: fermati a 2 cm dal petto per 1 secondo di fermo isometrico in massimo allungamento.',
      'La traiettoria rigida del Multipower protegge le capsule articolari rispetto ai pesi liberi.',
    ],
    commonMistakes: [
      'Scendere troppo velocemente senza controllare la fase di eccentrica.',
      'Sollevare i gomiti verso l’alto allineandoli al collo.',
    ],
  },

  // ==========================================
  // 2. SPALLE & DELTOIDI (SHOULDERS)
  // ==========================================
  {
    id: 'smith-incline-shoulder-press-75',
    name: 'Smith Machine 75° High-Incline Shoulder Press',
    italianName: 'Lento con Panca Inclinata 75° al Multipower',
    muscle: 'shoulders',
    secondaryMuscles: ['triceps', 'chest'],
    defaultWeightMode: 'total',
    defaultRestSec: 120,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 25, silver: 42, gold: 62, platinum: 82, diamond: 102 },
    tips: [
      'L’inclinazione a 75° (anziché 90°) protegge le articolazioni gleno-omerali fornendo un appoggio dorsale perfetto.',
      'Fai scendere la sbarra appena sopra il mento, poi spingi verso l’alto senza bloccare i gomiti in estensione.',
    ],
    commonMistakes: [
      'Scivolare in avanti con il bacino sulla seduta trasformando l’esercizio in una panca inclinata per il petto.',
      'Gomiti retratti dietro la linea della sbarra.',
    ],
  },
  {
    id: 'smith-incline-prone-front-raise',
    name: 'Smith Machine Prone Incline Front Press',
    italianName: 'Spinte su Panca Inclinata Prona al Multipower (Deltoidi)',
    muscle: 'shoulders',
    secondaryMuscles: ['upper_back'],
    defaultWeightMode: 'total',
    defaultRestSec: 90,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 18, silver: 30, gold: 45, platinum: 60, diamond: 78 },
    tips: [
      'Posiziona il petto contro lo schienale inclinato a 60°, afferra la barra e spingi verso l’alto lungo le guide.',
      'Il supporto toracico elimina qualsiasi slancio corporeo concentrando il carico sui deltoidi.',
    ],
    commonMistakes: [
      'Sollevare il petto dalla panca durante la spinta per darsi slancio.',
      'Iperestendere il collo all’indietro.',
    ],
  },
  {
    id: 'smith-incline-chest-supported-shrug',
    name: 'Smith Machine Incline Chest-Supported Shrug',
    italianName: 'Scrollate su Panca Inclinata al Multipower (Trapezi & Spalle)',
    muscle: 'shoulders',
    secondaryMuscles: ['upper_back'],
    defaultWeightMode: 'total',
    defaultRestSec: 75,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 35, silver: 58, gold: 85, platinum: 115, diamond: 145 },
    tips: [
      'Pancia e sterno appoggiati su panca inclinata a 60°, braccia tese verso il basso.',
      'Solleva le spalle verso le orecchie e leggermente indietro seguendo la linea delle guide del Multipower.',
    ],
    commonMistakes: [
      'Flettere i gomiti tirando di bicipiti invece di elevare e addurre le scapole.',
      'Movimento rapido a scatti senza trattenere la contrazione di picco.',
    ],
  },

  // ==========================================
  // 3. TRICIPITI (TRICEPS)
  // ==========================================
  {
    id: 'smith-incline-jm-press',
    name: 'Smith Machine Incline JM Press',
    italianName: 'JM Press su Panca Inclinata al Multipower',
    muscle: 'triceps',
    secondaryMuscles: ['chest', 'shoulders'],
    defaultWeightMode: 'total',
    defaultRestSec: 90,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 22, silver: 38, gold: 56, platinum: 75, diamond: 95 },
    tips: [
      'Panca inclinata a 30°, porta la sbarra guidata all’altezza tra clavicole e mento piegando i gomiti in avanti e in basso.',
      'Estendi i tricipiti con forza mantenendo l’angolo del braccio stabile: la traiettoria guidata garantisce massima sicurezza.',
    ],
    commonMistakes: [
      'Trasformarlo in un comune bench press allargando i gomiti.',
      'Far cadere la barra sulla gola per mancanza di controllo eccentrico.',
    ],
  },
  {
    id: 'smith-incline-skull-crusher',
    name: 'Smith Machine Incline Skull Crusher',
    italianName: 'French Press su Panca Inclinata al Multipower',
    muscle: 'triceps',
    secondaryMuscles: ['shoulders'],
    defaultWeightMode: 'total',
    defaultRestSec: 75,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 18, silver: 30, gold: 46, platinum: 62, diamond: 80 },
    tips: [
      'Panca a 30°-45°, porta la sbarra dietro la nuca mantenendo i gomiti fermi e puntati verso il soffitto.',
      'L’inclinazione della panca pone il capo lungo del tricipite in massimo allungamento rispetto alla panca piana.',
    ],
    commonMistakes: [
      'Aprire i gomiti all’esterno durante la fase concentrica.',
      'Muovere le spalle avanti e indietro invece di flettere solo l’articolazione del gomito.',
    ],
  },
  {
    id: 'smith-incline-reverse-grip-press',
    name: 'Smith Machine Incline Reverse-Grip Press',
    italianName: 'Panca Inclinata Presa Supina al Multipower (Tricipiti & Petto)',
    muscle: 'triceps',
    secondaryMuscles: ['chest', 'shoulders'],
    defaultWeightMode: 'total',
    defaultRestSec: 90,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 22, silver: 38, gold: 55, platinum: 74, diamond: 94 },
    tips: [
      'Afferra la sbarra guidata con palmi rivolti verso di te (presa inversa/supina) su panca inclinata a 30°.',
      'Scendi con i gomiti serrati verso i fianchi: grande attivazione dei tricipiti e del fascio clavicolare.',
    ],
    commonMistakes: [
      'Caricare troppo peso perdendo la stabilità dei polsi.',
      'Perdere il contatto scapolare con lo schienale.',
    ],
  },

  // ==========================================
  // 4. DORSALI (LATS)
  // ==========================================
  {
    id: 'smith-incline-chest-supported-lat-row',
    name: 'Smith Machine Incline Chest-Supported Lat Row',
    italianName: 'Rematore su Panca Inclinata al Multipower (Focus Gran Dorsale)',
    muscle: 'lats',
    secondaryMuscles: ['biceps', 'upper_back'],
    defaultWeightMode: 'total',
    defaultRestSec: 90,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 28, silver: 46, gold: 68, platinum: 90, diamond: 114 },
    tips: [
      'Panca inclinata a 30°-45° con il petto in appoggio. Presa neutra o prona a larghezza spalle.',
      'Tira la barra guidata verso l’ombelico mantenendo i gomiti aderenti al busto per convogliare la tensione sul gran dorsale.',
    ],
    commonMistakes: [
      'Tirare la sbarra verso il petto alto (sposta il focus su trapezi e deltoidi posteriori anziché sui dorsali).',
      'Staccare il petto dallo schienale con uno scatto lombare.',
    ],
  },
  {
    id: 'smith-incline-pullover',
    name: 'Smith Machine Incline Pullover (Prone/Supine on Bench)',
    italianName: 'Pullover Guidato su Panca Inclinata al Multipower',
    muscle: 'lats',
    secondaryMuscles: ['chest', 'triceps'],
    defaultWeightMode: 'total',
    defaultRestSec: 75,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 18, silver: 30, gold: 46, platinum: 62, diamond: 80 },
    tips: [
      'Sdraiato supino su panca inclinata a 30°, afferra la sbarra guidata sopra la testa con braccia semi-tese.',
      'Tira facendo perno solo sulle spalle fino a portare la barra sopra lo sterno, contraendo i gran dorsali.',
    ],
    commonMistakes: [
      'Piegare eccessivamente i gomiti trasformando il pullover in una french press.',
      'Inarcare pericolosamente la schiena staccando la zona lombare dalla panca.',
    ],
  },
  {
    id: 'smith-incline-single-arm-row',
    name: 'Smith Machine Incline Single-Arm Row',
    italianName: 'Rematore Singolo su Panca Inclinata al Multipower',
    muscle: 'lats',
    secondaryMuscles: ['biceps', 'upper_back'],
    defaultWeightMode: 'total',
    defaultRestSec: 75,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 15, silver: 26, gold: 38, platinum: 52, diamond: 66 },
    tips: [
      'Posiziona un lato del petto contro lo schienale inclinato a 45°, afferra la sbarra al centro con una mano.',
      'Tira verso l’anca concentrandoti sull’accorciamento completo del dorsale con stabilità assoluta.',
    ],
    commonMistakes: [
      'Ruotare il busto per compensare il carico anziché mantenere il torace saldo sulla panca.',
      'Presa troppo lontana che sbilancia il baricentro sul carrello guidato.',
    ],
  },

  // ==========================================
  // 5. DORSO ALTO & TRAPEZI (UPPER BACK)
  // ==========================================
  {
    id: 'smith-incline-seal-row-upper-back',
    name: 'Smith Machine Incline High Row / Seal Row',
    italianName: 'Rematore Alto su Panca Inclinata al Multipower (Dorso Alto)',
    muscle: 'upper_back',
    secondaryMuscles: ['lats', 'biceps', 'shoulders'],
    defaultWeightMode: 'total',
    defaultRestSec: 90,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 30, silver: 50, gold: 72, platinum: 96, diamond: 120 },
    tips: [
      'Petto appoggiato su panca inclinata a 45°, presa larga e gomiti aperti a 70°-80° rispetto al busto.',
      'Tira la barra verso il petto superiore stringendo con forza le scapole (adduzione scapolare completa).',
    ],
    commonMistakes: [
      'Chiudere i gomiti lungo i fianchi (lavorerebbero i dorsali invece del dorso alto e romboidi).',
      'Alzare il mento e iperestendere le vertebre cervicali.',
    ],
  },
  {
    id: 'smith-incline-face-pull',
    name: 'Smith Machine Incline High Face Pull',
    italianName: 'Tirate al Viso su Panca Inclinata al Multipower',
    muscle: 'upper_back',
    secondaryMuscles: ['shoulders'],
    defaultWeightMode: 'total',
    defaultRestSec: 75,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 16, silver: 28, gold: 42, platinum: 58, diamond: 74 },
    tips: [
      'Prono su panca a 45°, afferra la barra con presa prona media.',
      'Tira la sbarra guidata verso l’altezza degli occhi/fronte allargando i gomiti all’esterno per deltoidi posteriori e trapezi medi.',
    ],
    commonMistakes: [
      'Tirare verso il mento o il collo basso riducendo l’isolamento dei deltoidi posteriori.',
      'Perdere l’allineamento scapolare in fase eccentrica.',
    ],
  },
  {
    id: 'smith-incline-prone-scapular-shrug',
    name: 'Smith Machine Prone Incline Scapular Retraction',
    italianName: 'Scrollate Inverse su Panca Inclinata al Multipower (Romboidi)',
    muscle: 'upper_back',
    secondaryMuscles: ['shoulders'],
    defaultWeightMode: 'total',
    defaultRestSec: 60,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 25, silver: 42, gold: 62, platinum: 84, diamond: 106 },
    tips: [
      'Pancia contro la panca a 30°-45°, braccia tese verso il basso reggendo la sbarra.',
      'Senza piegare le braccia, adduci le scapole tra loro sollevando la barra di pochi centimetri solo con il dorso.',
    ],
    commonMistakes: [
      'Piegare i gomiti credendo di remare invece di effettuare una pura retrazione scapolare.',
      'Sollevare il busto dalla panca.',
    ],
  },

  // ==========================================
  // 6. BICIPITI (BICEPS)
  // ==========================================
  {
    id: 'smith-incline-spider-curl',
    name: 'Smith Machine Incline Spider Curl',
    italianName: 'Spider Curl su Panca Inclinata al Multipower',
    muscle: 'biceps',
    secondaryMuscles: ['shoulders'],
    defaultWeightMode: 'total',
    defaultRestSec: 75,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 15, silver: 25, gold: 38, platinum: 52, diamond: 66 },
    tips: [
      'Petto appoggiato sulla sommità della panca inclinata a 45°-60°, braccia perpendicolari al pavimento.',
      'Afferra la sbarra guidata con presa supina e fletti i gomiti portando la barra verso il mento per un picco di contrazione micidiale.',
    ],
    commonMistakes: [
      'Oscillare indietro con le spalle usando l’inerzia del corpo.',
      'Allargare i gomiti verso l’esterno perdendo l’asse del bicipite brachiale.',
    ],
  },
  {
    id: 'smith-incline-drag-curl',
    name: 'Smith Machine Incline Bench Drag Curl',
    italianName: 'Drag Curl Guidato con Supporto Panca Inclinata al Multipower',
    muscle: 'biceps',
    secondaryMuscles: ['shoulders'],
    defaultWeightMode: 'total',
    defaultRestSec: 75,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 16, silver: 28, gold: 42, platinum: 56, diamond: 72 },
    tips: [
      'In piedi o seduto con la schiena appoggiata a panca inclinata a 75° posizionata dietro di te.',
      'Tira indietro i gomiti facendo salire la sbarra guidata a contatto col busto: isolamento puro del bicipite senza carico sul deltoide anteriore.',
    ],
    commonMistakes: [
      'Portare i gomiti in avanti trasformando l’esercizio in un curl standard.',
      'Inarcare la schiena lombare per sollevare il carico.',
    ],
  },
  {
    id: 'smith-incline-reverse-curl',
    name: 'Smith Machine Incline Reverse Bicep Curl',
    italianName: 'Curl Presa Inversa su Panca Inclinata al Multipower (Brachiale)',
    muscle: 'biceps',
    secondaryMuscles: ['shoulders'],
    defaultWeightMode: 'total',
    defaultRestSec: 60,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 14, silver: 22, gold: 34, platinum: 46, diamond: 60 },
    tips: [
      'Petto contro panca inclinata a 45°, presa prona (nocche verso l’alto) sulla sbarra guidata.',
      'Fletti le braccia mantenendo i polsi saldi in linea con gli avambracci per stimolare brachiale e brachioradiale.',
    ],
    commonMistakes: [
      'Piegare i polsi a scatto scaricando la tensione dai muscoli dell’avambraccio.',
      'Staccare il petto dallo schienale.',
    ],
  },

  // ==========================================
  // 7. QUADRICIPITI (QUADS)
  // ==========================================
  {
    id: 'smith-incline-hack-squat',
    name: 'Smith Machine Incline Bench Hack Squat',
    italianName: 'Hack Squat con Panca Inclinata al Multipower',
    muscle: 'quads',
    secondaryMuscles: ['glutes', 'calves'],
    defaultWeightMode: 'total',
    defaultRestSec: 120,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 50, silver: 80, gold: 115, platinum: 155, diamond: 195 },
    tips: [
      'Posiziona una panca inclinata a 45°-60° dietro la sbarra guidata per appoggiare la schiena e simulare un Hack Squat perfetto.',
      'Piedi leggermente avanzati e ginocchia che avanzano liberamente per caricare il massimo allungamento sui quadricipiti.',
    ],
    commonMistakes: [
      'Posizionare i piedi troppo indietro sollevando i talloni da terra.',
      'Staccare il bacino dallo schienale durante la discesa in buca.',
    ],
  },
  {
    id: 'smith-incline-bench-step-up',
    name: 'Smith Machine Incline Bench Step-Up',
    italianName: 'Step-Up su Panca Inclinata/Regolabile al Multipower',
    muscle: 'quads',
    secondaryMuscles: ['glutes', 'hamstrings'],
    defaultWeightMode: 'total',
    defaultRestSec: 90,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 30, silver: 50, gold: 75, platinum: 100, diamond: 125 },
    tips: [
      'Panca regolata a gradino solido sotto la barra del Multipower.',
      'Sali spingendo interamente sul tallone della gamba anteriore posta sulla panca, senza darti spinta con la gamba a terra.',
    ],
    commonMistakes: [
      'Spingere con la punta del piede a terra togliendo lavoro alla gamba d’appoggio.',
      'Cedere con il ginocchio verso l’interno (valgo) durante la risalita.',
    ],
  },
  {
    id: 'smith-incline-bench-sissy-squat',
    name: 'Smith Machine Sissy Squat with Incline Bench Guide',
    italianName: 'Sissy Squat con Supporto Panca al Multipower (Focus Retto Femorale)',
    muscle: 'quads',
    secondaryMuscles: ['calves', 'abs'],
    defaultWeightMode: 'total',
    defaultRestSec: 90,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 25, silver: 45, gold: 68, platinum: 92, diamond: 118 },
    tips: [
      'Usa la panca inclinata come riferimento posteriore e la sbarra guidata per calibrare l’equilibrio.',
      'Proietta le ginocchia in avanti mantenendo busto e cosce allineati per uno stiramento isolato del retto femorale.',
    ],
    commonMistakes: [
      'Piegare il busto in avanti perdendo la tensione sul quadricipite.',
      'Scendere senza controllo dell’articolazione del ginocchio.',
    ],
  },

  // ==========================================
  // 8. FEMORALI (HAMSTRINGS)
  // ==========================================
  {
    id: 'smith-incline-bench-rdl',
    name: 'Smith Machine Romanian Deadlift with Incline Bench Stop',
    italianName: 'Stacco Rumeno al Multipower con Riferimento Panca Inclinata',
    muscle: 'hamstrings',
    secondaryMuscles: ['glutes', 'upper_back'],
    defaultWeightMode: 'total',
    defaultRestSec: 120,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 45, silver: 75, gold: 110, platinum: 145, diamond: 180 },
    tips: [
      'Posizionati di fronte alla panca inclinata, piedi a larghezza spalle e ginocchia morbide.',
      'Spingi il bacino indietro finché i glutei non sfiorano la panca, sentendo la massima tensione nei femorali prima di risalire.',
    ],
    commonMistakes: [
      'Flettere la schiena a livello lombare per scendere di più invece di arretrare il bacino (hip hinge).',
      'Piegare troppo le ginocchia trasformando lo stacco in uno squat.',
    ],
  },
  {
    id: 'smith-incline-single-leg-rdl',
    name: 'Smith Machine Single-Leg RDL on Incline Bench Support',
    italianName: 'Stacco Rumeno Monopodalico con Panca al Multipower',
    muscle: 'hamstrings',
    secondaryMuscles: ['glutes'],
    defaultWeightMode: 'total',
    defaultRestSec: 90,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 20, silver: 35, gold: 52, platinum: 70, diamond: 90 },
    tips: [
      'Piede posteriore appoggiato sulla base o sullo schienale basso della panca inclinata per stabilità totale.',
      'Fletti il bacino indietro con la barra guidata che scende lungo la tibia della gamba portante.',
    ],
    commonMistakes: [
      'Ruotare il bacino verso l’esterno anziché mantenerlo parallelo al suolo.',
      'Scendere a scatti perdendo l’equilibrio sul carrello.',
    ],
  },

  // ==========================================
  // 9. GLUTEI (GLUTES)
  // ==========================================
  {
    id: 'smith-incline-kas-glute-bridge',
    name: 'Smith Machine Kas Glute Bridge on Bench',
    italianName: 'Kas Glute Bridge con Panca al Multipower (Focus Glutei)',
    muscle: 'glutes',
    secondaryMuscles: ['hamstrings', 'quads'],
    defaultWeightMode: 'total',
    defaultRestSec: 105,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 50, silver: 85, gold: 125, platinum: 170, diamond: 215 },
    tips: [
      'Dorso appoggiato saldamente al cuscinetto della panca inclinata/regolata, barra imbottita all’altezza del bacino.',
      'ROM compatto: scendi solo fino a metà corsa e spingi su strizzando i glutei per 2 secondi di fermo in massima contrazione.',
    ],
    commonMistakes: [
      'Iperestendere la zona lombare in alto invece di compiere una pura retroversione del bacino.',
      'Posizionare i piedi troppo avanti togliendo contrazione al gluteo.',
    ],
  },
  {
    id: 'smith-incline-bulgarian-split-squat',
    name: 'Smith Machine Bulgarian Split Squat (Bench Support)',
    italianName: 'Squat Bulgaro al Multipower con Piede su Panca Inclinata',
    muscle: 'glutes',
    secondaryMuscles: ['quads', 'hamstrings'],
    defaultWeightMode: 'total',
    defaultRestSec: 90,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 25, silver: 45, gold: 70, platinum: 95, diamond: 120 },
    tips: [
      'Piede posteriore poggiato sulla panca inclinata regolata bassa, bilanciere guidato sulle spalle (o trapezio).',
      'Busto leggermente inclinato in avanti a 15° per caricare al 100% il grande gluteo della gamba avanzata.',
    ],
    commonMistakes: [
      'Busto troppo verticale che sposta il lavoro unicamente sul quadricipite.',
      'Distanza errata dalla panca che fa sollevare il tallone anteriore da terra.',
    ],
  },
  {
    id: 'smith-incline-bench-hip-thrust',
    name: 'Smith Machine Incline Bench Hip Thrust',
    italianName: 'Hip Thrust con Schienale Panca Inclinato al Multipower',
    muscle: 'glutes',
    secondaryMuscles: ['hamstrings'],
    defaultWeightMode: 'total',
    defaultRestSec: 120,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 55, silver: 90, gold: 135, platinum: 185, diamond: 235 },
    tips: [
      'Schienale della panca regolato con leggera inclinazione a cuneo per impedire alla panca di scivolare.',
      'Spingi forte attraverso i talloni portando tibia perpendicolare al suolo nel punto di massima estensione dell’anca.',
    ],
    commonMistakes: [
      'Sguardo verso l’alto che induce iperestensione della colonna (mantieni mento al petto e sguardo alle ginocchia).',
      'Rimbalzare a fine corsa inferiore.',
    ],
  },

  // ==========================================
  // 10. POLPACCI (CALVES)
  // ==========================================
  {
    id: 'smith-incline-seated-calf-raise',
    name: 'Smith Machine Incline Seated Calf Raise',
    italianName: 'Calf Raise Seduto con Panca Inclinata al Multipower',
    muscle: 'calves',
    secondaryMuscles: [],
    defaultWeightMode: 'total',
    defaultRestSec: 60,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 30, silver: 55, gold: 80, platinum: 110, diamond: 140 },
    tips: [
      'Siediti sulla panca con lo schienale inclinato a supporto, posiziona gli avampiedi su un gradino e la barra con cuscinetto sopra le ginocchia.',
      'Esegui una dorsiflessione profonda per stirare il soleo, poi sali in flessione plantare con fermo di 2 secondi.',
    ],
    commonMistakes: [
      'Effettuare rimbalzi elastici veloci senza sfruttare il massimo allungamento articolare.',
      'Spostare la barra troppo vicino all’articolazione della rotula.',
    ],
  },
  {
    id: 'smith-incline-donkey-calf-raise',
    name: 'Smith Machine Donkey Calf Raise with Incline Bench',
    italianName: 'Donkey Calf Raise su Panca Inclinata al Multipower',
    muscle: 'calves',
    secondaryMuscles: ['hamstrings'],
    defaultWeightMode: 'total',
    defaultRestSec: 60,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 35, silver: 65, gold: 95, platinum: 130, diamond: 165 },
    tips: [
      'Busto flesso a 90° appoggiato con gli avambracci e il petto allo schienale della panca inclinata.',
      'Barra del Multipower posizionata sopra il bacino/sacro con imbottitura: allungamento eccezionale del gastrocnemio.',
    ],
    commonMistakes: [
      'Piegare le ginocchia durante la salita (le gambe devono restare quasi completamente tese).',
      'Non scendere abbastanza sotto il livello del gradino.',
    ],
  },

  // ==========================================
  // 11. ADDOME & CORE (ABS)
  // ==========================================
  {
    id: 'smith-incline-weighted-crunch',
    name: 'Smith Machine Incline Bench Weighted Crunch',
    italianName: 'Crunch Zavorrato su Panca Inclinata al Multipower',
    muscle: 'abs',
    secondaryMuscles: [],
    defaultWeightMode: 'total',
    defaultRestSec: 60,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 15, silver: 25, gold: 40, platinum: 55, diamond: 70 },
    tips: [
      'Sdraiato su panca inclinata o declinata, braccia tese che sorreggono la sbarra del Multipower perpendicolare al soffitto.',
      'Arrotola il torace verso il bacino spingendo la sbarra verso l’alto solo con la contrazione dei retti addominali.',
    ],
    commonMistakes: [
      'Tirare con le braccia o spingere di spalle invece di flettere la colonna vertebrale.',
      'Staccare l’intera schiena come in un sit-up sforzando i flessori dell’anca.',
    ],
  },
  {
    id: 'smith-incline-bench-reverse-crunch',
    name: 'Smith Machine Incline Reverse Crunch (Bar Anchor)',
    italianName: 'Reverse Crunch su Panca Inclinata con Presa al Bilanciere Multipower',
    muscle: 'abs',
    secondaryMuscles: [],
    defaultWeightMode: 'bodyweight',
    defaultRestSec: 60,
    equipment: 'machine',
    bodyweightPercentage: 45,
    standard1RMBenchmarkKg: { bronze: 0, silver: 10, gold: 20, platinum: 30, diamond: 40 },
    tips: [
      'Schiena sulla panca inclinata con la testa verso l’alto, afferra saldamente la sbarra bloccata del Multipower dietro di te come punto fermo.',
      'Solleva il bacino arrotolandolo verso il petto in espirazione completa.',
    ],
    commonMistakes: [
      'Slanciare le gambe sfruttando l’oscillazione invece di contrarre gli addominali bassi.',
      'Far cadere la schiena sulla panca senza frenare la discesa.',
    ],
  },
  {
    id: 'smith-incline-torso-rotation',
    name: 'Smith Machine Incline Seated Torso Rotation',
    italianName: 'Torsioni del Busto su Panca Inclinata al Multipower (Obliqui)',
    muscle: 'abs',
    secondaryMuscles: [],
    defaultWeightMode: 'total',
    defaultRestSec: 60,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 10, silver: 18, gold: 28, platinum: 40, diamond: 52 },
    tips: [
      'Seduto a cavalcioni sulla panca inclinata con schienale a 60°, afferra la sbarra guidata all’altezza delle spalle.',
      'Esegui una rotazione controllata del tronco contro la resistenza calibrata per attivare obliqui interni ed esterni.',
    ],
    commonMistakes: [
      'Rotazioni violente o a scatti che rischiano di infiammare il tratto toraco-lombare.',
      'Muovere solo le braccia senza ruotare la cassa toracica.',
    ],
  },
];
