import { ExerciseDefinition } from '../types';

/**
 * Esercizi per il dorso completo basati specificamente sull'ELENCO ATTREZZI della palestra:
 * - 5: MULTI POWER
 * - 8: CASTELLO CAVI
 * - 21: LAT MACHINE / PULLEY BASSO
 * - 27 / 29: POLIERCOLINA
 * - 28: PULLEY BASSO
 * - 40: STRUTTURA MULTIFUNZIONALE
 * - 44: SPALLIERA
 */
export const GYM_BACK_EXERCISES: ExerciseDefinition[] = [
  // 1. MULTI POWER — Rematore al Bilanciere Guidato (Spessore, Dorso Alto & Romboidi)
  {
    id: 'smith-machine-bent-over-row',
    name: 'Smith Machine Bent-Over Row',
    italianName: 'Rematore al Multipower (Busto a 45°)',
    muscle: 'upper_back',
    secondaryMuscles: ['lats', 'biceps'],
    defaultWeightMode: 'total',
    defaultRestSec: 90,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 30, silver: 50, gold: 72, platinum: 95, diamond: 120 },
    tips: [
      'Usa la traiettoria vincolata del Multipower per concentrarti solo sul movimento scapolare.',
      'Tira la barra guidata verso l’ombelico stringendo i gomiti verso i fianchi.'
    ],
    commonMistakes: [
      'Inarcare eccessivamente la zona lombare o scattare verso l’alto con la schiena.',
      'Tirare solo con le braccia senza retrarre attivamente le scapole.'
    ],
  },

  // 2. MULTI POWER — Rematore Inverso a Corpo Libero (Upper Back & Core)
  {
    id: 'smith-machine-inverted-row',
    name: 'Smith Machine Inverted Row',
    italianName: 'Rematore Inverso al Multipower (Inverted Row)',
    muscle: 'upper_back',
    secondaryMuscles: ['lats', 'biceps', 'abs'],
    defaultWeightMode: 'bodyweight',
    defaultRestSec: 75,
    equipment: 'bodyweight',
    bodyweightPercentage: 65,
    standard1RMBenchmarkKg: { bronze: 35, silver: 52, gold: 70, platinum: 90, diamond: 110 },
    tips: [
      'Regola la barra del Multipower all’altezza delle anche, posizionati sotto con i talloni a terra e il corpo rigido.',
      'Tira il petto a contatto con la barra mantenendo addome e glutei serrati.'
    ],
    commonMistakes: [
      'Lasciar cadere il bacino spezzando l’allineamento tronco-gambe.',
      'Arrivare a toccare la barra con il mento invece che con la parte centrale del petto.'
    ],
  },

  // 3. MULTI POWER — Scrollate per Trapezi Superiori (Trapezi & Dorso Alto)
  {
    id: 'smith-machine-shrug',
    name: 'Smith Machine Shrug',
    italianName: 'Scrollate al Multipower (Shrug)',
    muscle: 'upper_back',
    secondaryMuscles: [],
    defaultWeightMode: 'total',
    defaultRestSec: 75,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 45, silver: 75, gold: 105, platinum: 135, diamond: 170 },
    tips: [
      'In piedi eretto con la barra del Multipower alle cosce, solleva le spalle verso le orecchie.',
      'Mantieni una contrazione di picco di 1 secondo in cima prima di scendere in modo controllato.'
    ],
    commonMistakes: [
      'Ruotare le spalle in avanti o indietro (il movimento deve essere puramente verticale).',
      'Piegare i gomiti tirando con i bicipiti anziché isolare il trapezio.'
    ],
  },

  // 4. PULLEY BASSO — Rematore con Triangolo (Gran Dorsale & Spessore)
  {
    id: 'cable-seated-row-v-bar',
    name: 'Seated V-Bar Cable Row',
    italianName: 'Pulley Basso con Triangolo (Presa Stretta Neutra)',
    muscle: 'lats',
    secondaryMuscles: ['upper_back', 'biceps'],
    defaultWeightMode: 'total',
    defaultRestSec: 90,
    equipment: 'cable',
    standard1RMBenchmarkKg: { bronze: 28, silver: 45, gold: 65, platinum: 85, diamond: 110 },
    tips: [
      'Petto in fuori, gomiti vicini al tronco per canalizzare la contrazione sui fasci inferiori del gran dorsale.',
      'Allunga completamente le braccia in fase eccentrica senza piegare eccessivamente la schiena in avanti.'
    ],
    commonMistakes: [
      'Oscillare col busto avanti e indietro per sfruttare l’inerzia del carico.',
      'Alzare le spalle verso l’alto comprimendo il collo.'
    ],
  },

  // 5. PULLEY BASSO / POLIERCOLINA — Rematore Unilaterale con Maniglia (Isolamento Gran Dorsale)
  {
    id: 'single-arm-seated-cable-row',
    name: 'Single-Arm Seated Cable Row',
    italianName: 'Pulley Basso a un Braccio con Maniglia Singola',
    muscle: 'lats',
    secondaryMuscles: ['biceps', 'upper_back'],
    defaultWeightMode: 'per_side',
    defaultRestSec: 60,
    equipment: 'cable',
    standard1RMBenchmarkKg: { bronze: 14, silver: 24, gold: 34, platinum: 45, diamond: 58 },
    tips: [
      'Permette un raggio di movimento e uno stretch profondo senza vincoli bilaterali.',
      'Guida il gomito aderente al fianco portandolo leggermente oltre la linea del tronco.'
    ],
    commonMistakes: [
      'Ruotare eccessivamente il busto per compensare una carenza di forza.',
      'Strattonare con il bicipite all’inizio del movimento.'
    ],
  },

  // 6. LAT MACHINE — Presa Inversa Supina (Ampiezza Dorsale & Braccia)
  {
    id: 'reverse-grip-lat-pulldown',
    name: 'Reverse-Grip Lat Pulldown',
    italianName: 'Lat Machine Presa Inversa (Presa Supina)',
    muscle: 'lats',
    secondaryMuscles: ['biceps', 'upper_back'],
    defaultWeightMode: 'total',
    defaultRestSec: 90,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 28, silver: 48, gold: 68, platinum: 88, diamond: 112 },
    tips: [
      'Impugna la sbarra alla larghezza delle spalle con il palmo verso il viso.',
      'Favorisce una traiettoria dei gomiti più chiusa, enfatizzando il gran dorsale nei punti di inserzione bassi.'
    ],
    commonMistakes: [
      'Inclinarsi all’indietro oltre 20-30° trasformando la tirata verticale in un rematore.',
      'Schiacciare i polsi in iperflessione.'
    ],
  },

  // 7. LAT MACHINE — Dietro la Nuca (Dorso Alto, Romboidi & Deltoidi Posteriori)
  {
    id: 'behind-the-neck-lat-pulldown',
    name: 'Behind-the-Neck Lat Pulldown',
    italianName: 'Lat Machine Dietro la Nuca',
    muscle: 'upper_back',
    secondaryMuscles: ['lats', 'shoulders'],
    defaultWeightMode: 'total',
    defaultRestSec: 90,
    equipment: 'machine',
    standard1RMBenchmarkKg: { bronze: 22, silver: 38, gold: 55, platinum: 72, diamond: 92 },
    tips: [
      'Consigliato solo per chi possiede una buona mobilità di spalla; esegui con carichi controllati.',
      'Porta la barra verso la base del collo mantenendo la testa eretta.'
    ],
    commonMistakes: [
      'Spingere bruscamente la testa in avanti per far passare la barra.',
      'Utilizzare carichi troppo pesanti che mettono a rischio l’articolazione gleno-omerale.'
    ],
  },

  // 8. POLIERCOLINA / CASTELLO CAVI — Pulldown a Braccia Tese Monolaterale (Isolamento Ampiezza)
  {
    id: 'single-arm-cable-straight-arm-pulldown',
    name: 'Single-Arm Cable Straight-Arm Pulldown',
    italianName: 'Pulldown a Braccia Tese alla Poliercolina (Singolo Braccio)',
    muscle: 'lats',
    secondaryMuscles: ['triceps'],
    defaultWeightMode: 'per_side',
    defaultRestSec: 60,
    equipment: 'cable',
    standard1RMBenchmarkKg: { bronze: 8, silver: 14, gold: 20, platinum: 28, diamond: 38 },
    tips: [
      'Regola il cavo in alto alla poliercolina, mantieni il gomito quasi esteso con una microflessione bloccata.',
      'Porta la maniglia verso la coscia contraendo volontariamente il gran dorsale senza piegare il gomito.'
    ],
    commonMistakes: [
      'Piegare il gomito trasformando l’esercizio in un pushdown per tricipiti.',
      'Dondolare con il tronco per avviare la discesa.'
    ],
  },

  // 9. CASTELLO CAVI / POLIERCOLINA — Face Pull con Corda (Trapezio Medio, Romboidi & Postura)
  {
    id: 'cable-face-pull',
    name: 'Cable Face Pull',
    italianName: 'Face Pull al Cavo con Corda (Castello Cavi / Poliercolina)',
    muscle: 'upper_back',
    secondaryMuscles: ['shoulders'],
    defaultWeightMode: 'total',
    defaultRestSec: 60,
    equipment: 'cable',
    standard1RMBenchmarkKg: { bronze: 14, silver: 22, gold: 32, platinum: 44, diamond: 56 },
    tips: [
      'Posiziona la puleggia all’altezza degli occhi o leggermente più in alto.',
      'Tira la corda verso gli occhi/fronte allargando le mani e ruotando esternamente gli omeri.'
    ],
    commonMistakes: [
      'Tirare verso il mento con i gomiti bassi invece che alti e aperti.',
      'Usare troppo peso perdendo l’extra-rotazione finale.'
    ],
  },

  // 10. CASTELLO CAVI — Rematore Alto ai Cavi Incrociati (Spessore Alto & Deltoidi Posteriori)
  {
    id: 'high-cable-rear-delt-row',
    name: 'Cross Cable High Row',
    italianName: 'Rematore Alto ai Cavi Incrociati (Castello Cavi)',
    muscle: 'upper_back',
    secondaryMuscles: ['shoulders', 'biceps'],
    defaultWeightMode: 'total',
    defaultRestSec: 75,
    equipment: 'cable',
    standard1RMBenchmarkKg: { bronze: 18, silver: 30, gold: 44, platinum: 58, diamond: 74 },
    tips: [
      'Incrocia i cavi alti del castello (cavo destro in mano sinistra e viceversa).',
      'Tira indietro i gomiti all’altezza delle spalle enfatizzando la retrazione e adduzione delle scapole.'
    ],
    commonMistakes: [
      'Alzare le spalle vicino alle orecchie (tieni i trapezi inferiori attivi).',
      'Portare i gomiti troppo bassi vicino ai fianchi.'
    ],
  },

  // 11. SPALLIERA / STRUTTURA MULTIFUNZIONALE — Trazioni Sospese con Piedi a Terra / Sospensione
  {
    id: 'spalliera-pull-up-hang',
    name: 'Wall Bars Pull-Up / Suspended Hang',
    italianName: 'Trazioni & Trazione Sospesa alla Spalliera',
    muscle: 'lats',
    secondaryMuscles: ['biceps', 'abs'],
    defaultWeightMode: 'bodyweight',
    defaultRestSec: 90,
    equipment: 'bodyweight',
    bodyweightPercentage: 70,
    standard1RMBenchmarkKg: { bronze: 40, silver: 58, gold: 76, platinum: 96, diamond: 118 },
    tips: [
      'Aggrappati ai pioli alti della spalliera; puoi modulare il carico appoggiando i piedi sui pioli intermedi per una progressione perfetta.',
      'Concentrati sulla depressione scapolare prima di piegare le braccia.'
    ],
    commonMistakes: [
      'Oscillare con le ginocchia per darsi lo slancio.',
      'Non estendere completamente le braccia in discesa.'
    ],
  },

  // 12. SPALLIERA / PANCA — Iperestensioni Lombari / Erettori Spinali
  {
    id: 'spalliera-erector-spine-extension',
    name: 'Spalliera Spinal Hyperextension',
    italianName: 'Estensioni Lombari alla Spalliera (Erettori Spinali)',
    muscle: 'upper_back',
    secondaryMuscles: ['glutes', 'hamstrings'],
    defaultWeightMode: 'bodyweight',
    defaultRestSec: 60,
    equipment: 'bodyweight',
    bodyweightPercentage: 45,
    standard1RMBenchmarkKg: { bronze: 16, silver: 26, gold: 38, platinum: 50, diamond: 65 },
    tips: [
      'Piedi bloccati sotto il piolo basso della spalliera, bacino su un supporto o fitball.',
      'Solleva il tronco fino alla linea retta attivando gli erettori della colonna lombare e toracica.'
    ],
    commonMistakes: [
      'Iperestendere eccessivamente all’indietro comprimendo le vertebre lombari.',
      'Muoversi a scatti veloci senza controllo.'
    ],
  },
];
